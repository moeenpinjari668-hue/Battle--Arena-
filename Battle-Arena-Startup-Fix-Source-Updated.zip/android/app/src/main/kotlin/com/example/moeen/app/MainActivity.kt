package com.example.moeen.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
