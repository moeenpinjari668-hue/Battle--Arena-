// ============================================================================
// BATTLE ARENA - ULTRA PREMIUM ESPORTS PLATFORM (FINAL PART 1)
// ============================================================================

import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

final GlobalKey<NavigatorState> appNavigatorKey = GlobalKey<NavigatorState>();

const FirebaseOptions kWebFirebaseOptions = FirebaseOptions(
  apiKey: 'AIzaSyAx-SBwbOQR8NPnnC2cbc38gMeiTIIhvc4',
  authDomain: 'moeen-3fe9f.firebaseapp.com',
  projectId: 'moeen-3fe9f',
  storageBucket: 'moeen-3fe9f.firebasestorage.app',
  messagingSenderId: '198243494689',
  appId: '1:198243494689:web:9dea2e08c60d13506cec60',
);

const FirebaseOptions kAndroidFirebaseOptions = FirebaseOptions(
  apiKey: 'AIzaSyBvnUk_7zB-Y6qUEHNf0fjayUPoA71GC7I',
  projectId: 'moeen-3fe9f',
  storageBucket: 'moeen-3fe9f.firebasestorage.app',
  messagingSenderId: '198243494689',
  appId: '1:198243494689:android:eb8e989255c573e76cec60',
);

FirebaseOptions get kFirebaseOptions =>
    kIsWeb ? kWebFirebaseOptions : kAndroidFirebaseOptions;

class AppConfig {
  static const String appName = 'Battle Arena';
  static const String websiteUrl = 'https://battle-arena-official.netlify.app';
  static const String upiNumber = '218853273';
  static const String upiId = '9763151620@ybl';
  static const String supportEmail = 'herebattlearenasupport@gmail.com';
  static const String adminEmail = 'adminpanel95841620@gmail.com';
  
  static const int minDeposit = 11;
  static const int maxDeposit = 1000;
  static const int minWithdraw = 11;
  static const int maxWithdraw = 1000;

  static const String depositAdminPassword = 'gt_pss_tysr6148';
  static const String withdrawAdminPassword = 'wdrwl_pss_tysr_8416';
  static const String adminPanelPassword = 'in-to-go_admpnldpspetc.1tozero';

  static const String youtubeUrl = 'https://youtube.com/@battlearena_official?si=w17ezZUog3ZBEiMc';
  static const String telegramUrl = 'https://t.me/the_battlearena_official';
  static const String instagramUrl = 'https://www.instagram.com/official_battlearena/';
  static const String discordUrl = 'https://discord.gg/yBaY6ktH';
  static const String whatsappChannelUrl = 'https://whatsapp.com/channel/0029Vb9knPRKmCPU8qw6Av1S';
}

class AppColors {
  static const Color background = Color(0xFF0B0E17);
  static const Color surface = Color(0xFF131B2E);
  static const Color surfaceLight = Color(0xFF1E293B);
  static const Color cardBorder = Color(0xFF2E3D5C);
  static const Color cyan = Color(0xFF00F0FF);
  static const Color green = Color(0xFF10B981);
  static const Color gold = Color(0xFFFACC15);
  static const Color orange = Color(0xFFF59E0B);
  static const Color red = Color(0xFFEF4444);
  static const Color textPrimary = Color(0xFFF8FAFC);
  static const Color textSecondary = Color(0xFF94A3B8);
  static const Color textMuted = Color(0xFF64748B);
}

Future<void> openExternalUrl(BuildContext context, String urlString) async {
  final trimmed = urlString.trim();
  if (trimmed.isEmpty) return;
  final Uri? uri = Uri.tryParse(trimmed);
  if (uri == null) return;
  try {
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  } catch (e) {
    await Clipboard.setData(ClipboardData(text: trimmed));
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Link copied: $trimmed')));
    }
  }
}

Widget buildAppLogo({double size = 64, double radius = 16, bool showGlow = true}) {
  return Container(
    width: size,
    height: size,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: AppColors.cyan.withOpacity(0.75), width: 1.5),
      boxShadow: showGlow ? [BoxShadow(color: AppColors.cyan.withOpacity(0.35), blurRadius: 16, spreadRadius: 2)] : null,
    ),
    child: ClipRRect(
      borderRadius: BorderRadius.circular(radius - 1.5),
      child: Image.asset(
        'assets/app_logo.png',
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(
          decoration: const BoxDecoration(gradient: LinearGradient(colors: [AppColors.cyan, Color(0xFF6366F1)])),
          child: Center(child: Icon(Icons.sports_esports, size: size * 0.55, color: Colors.black)),
        ),
      ),
    ),
  );
}

void showCustomDialog({required BuildContext context, required String title, required String message, required IconData icon, required Color color, String btnText = 'CONFIRM', VoidCallback? onBtnPressed}) {
  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (ctx) => Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color.withOpacity(0.8), width: 1.5),
          boxShadow: [BoxShadow(color: color.withOpacity(0.25), blurRadius: 25, spreadRadius: 2)],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: color.withOpacity(0.15), shape: BoxShape.circle, border: Border.all(color: color)), child: Icon(icon, color: color, size: 36)),
            const SizedBox(height: 16),
            Text(title, textAlign: TextAlign.center, style: GoogleFonts.orbitron(fontSize: 16, fontWeight: FontWeight.w900, color: color, letterSpacing: 1)),
            const SizedBox(height: 10),
            Text(message, textAlign: TextAlign.center, style: const TextStyle(fontSize: 13, color: AppColors.textPrimary, height: 1.4)),
            const SizedBox(height: 20),
            SizedBox(width: double.infinity, height: 46, child: ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: color, foregroundColor: Colors.black, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))), onPressed: onBtnPressed ?? () => Navigator.pop(ctx), child: Text(btnText, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 1)))),
          ],
        ),
      ),
    ),
  );
}

class GameModeItem {
  final String title, banner, subtitle, tag;
  const GameModeItem({required this.title, required this.banner, required this.subtitle, required this.tag});
}

class TournamentMatch {
  final String id, title, mode, map, version, banner;
  int prizePool, perKill, entryFee, totalSlots, filledSlots;
  String matchTime, status, roomId, roomPassword;
  String? winner;
  String? rejectReason;
  bool isRoomRevealed;
  String? resultTime;

  TournamentMatch({
    required this.id,
    required this.title,
    required this.mode,
    required this.map,
    required this.version,
    required this.banner,
    required this.prizePool,
    required this.perKill,
    required this.entryFee,
    required this.totalSlots,
    required this.filledSlots,
    required this.matchTime,
    required this.status,
    required this.roomId,
    required this.roomPassword,
    this.winner,
    this.rejectReason,
    this.isRoomRevealed = false,
    this.resultTime,
  });

  TournamentMatch copyWith({
    String? title,
    String? mode,
    String? map,
    String? version,
    String? banner,
    int? prizePool,
    int? perKill,
    int? entryFee,
    int? totalSlots,
    int? filledSlots,
    String? matchTime,
    String? status,
    String? winner,
    String? roomId,
    String? roomPassword,
    String? rejectReason,
    bool? isRoomRevealed,
    String? resultTime,
  }) {
    return TournamentMatch(
      id: id,
      title: title ?? this.title,
      mode: mode ?? this.mode,
      map: map ?? this.map,
      version: version ?? this.version,
      banner: banner ?? this.banner,
      prizePool: prizePool ?? this.prizePool,
      perKill: perKill ?? this.perKill,
      entryFee: entryFee ?? this.entryFee,
      totalSlots: totalSlots ?? this.totalSlots,
      filledSlots: filledSlots ?? this.filledSlots,
      matchTime: matchTime ?? this.matchTime,
      status: status ?? this.status,
      winner: winner ?? this.winner,
      roomId: roomId ?? this.roomId,
      roomPassword: roomPassword ?? this.roomPassword,
      rejectReason: rejectReason ?? this.rejectReason,
      isRoomRevealed: isRoomRevealed ?? this.isRoomRevealed,
      resultTime: resultTime ?? this.resultTime,
    );
  }
}

TournamentMatch applyMatchOverrides(TournamentMatch base, Map<String, dynamic>? data) {
  if (data == null) return base;
  return base.copyWith(
    title: (data['title'] as String?) ?? base.title,
    mode: (data['mode'] as String?) ?? base.mode,
    map: (data['map'] as String?) ?? base.map,
    version: (data['version'] as String?) ?? base.version,
    banner: (data['banner'] as String?) ?? base.banner,
    prizePool: (data['prizePool'] as num?)?.toInt() ?? base.prizePool,
    perKill: (data['perKill'] as num?)?.toInt() ?? base.perKill,
    entryFee: (data['entryFee'] as num?)?.toInt() ?? base.entryFee,
    totalSlots: (data['totalSlots'] as num?)?.toInt() ?? base.totalSlots,
    filledSlots: (data['filledSlots'] as num?)?.toInt() ?? base.filledSlots,
    matchTime: (data['matchTime'] as String?) ?? base.matchTime,
    status: (data['status'] as String?) ?? base.status,
    winner: (data['winner'] as String?) ?? base.winner,
    roomId: (data['roomId'] as String?) ?? base.roomId,
    roomPassword: (data['roomPassword'] as String?) ?? base.roomPassword,
    rejectReason: (data['rejectReason'] as String?) ?? base.rejectReason,
    isRoomRevealed: (data['isRoomRevealed'] as bool?) ?? base.isRoomRevealed,
    resultTime: (data['resultTime'] as String?) ?? base.resultTime,
  );
}

class LeaderboardEntry {
  final int rank, kills, won;
  final String name, avatar;
  const LeaderboardEntry({required this.rank, required this.name, required this.kills, required this.won, required this.avatar});
}

final List<GameModeItem> kGameModes = [
  const GameModeItem(title: 'Solo Survival Bermuda', banner: 'assets/banner_01.png', subtitle: '48 Players • Bermuda', tag: 'SURVIVAL'),
  const GameModeItem(title: 'Solo Survival BR Purgatory', banner: 'assets/banner_02.png', subtitle: '48 Players • Purgatory', tag: 'HOT'),
  const GameModeItem(title: 'CS 2v2 One Tap', banner: 'assets/banner_03.png', subtitle: '4 Players • Best of 7', tag: 'FAST'),
  const GameModeItem(title: '1v1 Clash Squad', banner: 'assets/banner_04.png', subtitle: '2 Players • 1v1 Duel', tag: 'SOLO'),
  const GameModeItem(title: 'Duo Bermuda Full Map', banner: 'assets/banner_05.png', subtitle: '48 Players • 24 Teams', tag: 'DUO'),
  const GameModeItem(title: '4v4 Clash Squad', banner: 'assets/banner_06.png', subtitle: '8 Players • 4v4 Ranked', tag: 'TRENDING'),
  const GameModeItem(title: '1v1 Lone Wolf Headshot', banner: 'assets/banner_07.png', subtitle: '2 Players • Headshot Only', tag: 'PRO'),
  const GameModeItem(title: 'Free Giveaway', banner: 'assets/banner_08.png', subtitle: '48 Players • Free Entry', tag: 'FREE'),
  const GameModeItem(title: 'Solo High Entry Match', banner: 'assets/banner_09.png', subtitle: '48 Players • Mega Pool', tag: 'BIG PRIZE'),
  const GameModeItem(title: 'Only UMP Challenge Mode', banner: 'assets/banner_10.png', subtitle: '8 Players • UMP Only', tag: 'SPECIAL'),
  const GameModeItem(title: 'Lose to Win', banner: 'assets/banner_11.png', subtitle: '48 Players • Reverse Bounty', tag: 'UNIQUE'),
  const GameModeItem(title: 'CS 1v1 OneTap Tournament', banner: 'assets/banner_12.png', subtitle: '2 Players • Desert Eagle', tag: 'HARDCORE'),
  const GameModeItem(title: '2v2 Lone Wolf Tournament', banner: 'assets/banner_13.png', subtitle: '4 Players • Duo Lone Wolf', tag: 'INTENSE'),
  const GameModeItem(title: '1v1 Lone Wolf Tournament', banner: 'assets/banner_14.png', subtitle: '2 Players • Wolf Arena', tag: 'CUP'),
  const GameModeItem(title: '2v2 Clash Squad Tournament', banner: 'assets/banner_15.png', subtitle: '4 Players • CS Finals', tag: 'MAJOR'),
  const GameModeItem(title: 'Bermuda Squad 4v4', banner: 'assets/banner_16.png', subtitle: '12 Squads × 4 = 48 Players', tag: 'SQUAD'),
];

final List<TournamentMatch> kMatches = [
  TournamentMatch(id: 'BA-101', title: 'Solo Survival Bermuda #101', mode: 'SOLO SURVIVAL', map: 'Bermuda Full Map', version: 'FF MAX', banner: 'assets/banner_01.png', prizePool: 800, perKill: 20, entryFee: 20, totalSlots: 48, filledSlots: 0, matchTime: 'Today, 08:00 PM', status: 'UPCOMING', roomId: '8839210', roomPassword: '777'),
  TournamentMatch(id: 'BA-102', title: 'Solo Survival BR Purgatory #102', mode: 'SOLO SURVIVAL', map: 'Purgatory Full Map', version: 'FF MAX', banner: 'assets/banner_02.png', prizePool: 800, perKill: 20, entryFee: 20, totalSlots: 48, filledSlots: 0, matchTime: 'Today, 08:30 PM', status: 'UPCOMING', roomId: '5592183', roomPassword: '444'),
  TournamentMatch(id: 'BA-103', title: 'CS 2v2 One Tap #103', mode: 'CS 2V2', map: 'CS Bermuda', version: 'FF MAX', banner: 'assets/banner_03.png', prizePool: 200, perKill: 15, entryFee: 30, totalSlots: 4, filledSlots: 0, matchTime: 'Today, 08:45 PM', status: 'UPCOMING', roomId: '4410291', roomPassword: '123'),
  TournamentMatch(id: 'BA-104', title: '1v1 Clash Squad #104', mode: '1V1 CLASH SQUAD', map: 'CS Iron Cage', version: 'FF MAX', banner: 'assets/banner_04.png', prizePool: 100, perKill: 25, entryFee: 40, totalSlots: 2, filledSlots: 0, matchTime: 'Today, 09:00 PM', status: 'UPCOMING', roomId: '3319028', roomPassword: '999'),
  TournamentMatch(id: 'BA-105', title: 'Duo Bermuda Full Map #105', mode: 'DUO BERMUDA', map: 'Bermuda Full Map', version: 'FF MAX', banner: 'assets/banner_05.png', prizePool: 1000, perKill: 25, entryFee: 30, totalSlots: 48, filledSlots: 0, matchTime: 'Today, 09:15 PM', status: 'UPCOMING', roomId: '7729104', roomPassword: '555'),
  TournamentMatch(id: 'BA-106', title: '4v4 Clash Squad #106', mode: '4V4 CLASH SQUAD', map: 'CS Bermuda', version: 'FF MAX', banner: 'assets/banner_06.png', prizePool: 500, perKill: 20, entryFee: 35, totalSlots: 8, filledSlots: 0, matchTime: 'Today, 09:30 PM', status: 'UPCOMING', roomId: '6610294', roomPassword: '321'),
  TournamentMatch(id: 'BA-107', title: '1v1 Lone Wolf Headshot #107', mode: '1V1 LONE WOLF', map: 'Iron Cage', version: 'FF MAX', banner: 'assets/banner_07.png', prizePool: 150, perKill: 30, entryFee: 50, totalSlots: 2, filledSlots: 0, matchTime: 'Today, 09:45 PM', status: 'UPCOMING', roomId: '9918237', roomPassword: '888'),
  TournamentMatch(id: 'BA-108', title: 'Free Giveaway #108', mode: 'FREE GIVEAWAY', map: 'Bermuda Full Map', version: 'FF MAX', banner: 'assets/banner_08.png', prizePool: 200, perKill: 5, entryFee: 0, totalSlots: 48, filledSlots: 0, matchTime: 'Today, 10:00 PM', status: 'UPCOMING', roomId: '1102938', roomPassword: '111'),
  TournamentMatch(id: 'BA-109', title: 'Solo High Entry Match #109', mode: 'SOLO HIGH ENTRY', map: 'Bermuda Full Map', version: 'FF MAX', banner: 'assets/banner_09.png', prizePool: 2500, perKill: 60, entryFee: 100, totalSlots: 48, filledSlots: 0, matchTime: 'Today, 10:15 PM', status: 'UPCOMING', roomId: '2201928', roomPassword: '222'),
  TournamentMatch(id: 'BA-110', title: 'Only UMP Challenge Mode #110', mode: 'CS 4V4 UMP', map: 'CS Kalahari', version: 'FF MAX', banner: 'assets/banner_10.png', prizePool: 600, perKill: 20, entryFee: 45, totalSlots: 8, filledSlots: 0, matchTime: 'Today, 10:30 PM', status: 'UPCOMING', roomId: '3301928', roomPassword: '333'),
  TournamentMatch(id: 'BA-111', title: 'Lose to Win #111', mode: 'LOSE TO WIN', map: 'Bermuda Full Map', version: 'FF MAX', banner: 'assets/banner_11.png', prizePool: 1200, perKill: 30, entryFee: 35, totalSlots: 48, filledSlots: 0, matchTime: 'Today, 10:45 PM', status: 'UPCOMING', roomId: '4401928', roomPassword: '444'),
  TournamentMatch(id: 'BA-112', title: 'CS 1v1 OneTap Tournament #112', mode: 'CS 1V1 ONE TAP', map: 'CS Bermuda', version: 'FF MAX', banner: 'assets/banner_12.png', prizePool: 120, perKill: 30, entryFee: 40, totalSlots: 2, filledSlots: 0, matchTime: 'Today, 11:00 PM', status: 'UPCOMING', roomId: '5501928', roomPassword: '555'),
  TournamentMatch(id: 'BA-113', title: '2v2 Lone Wolf Tournament #113', mode: '2V2 LONE WOLF', map: 'Iron Cage', version: 'FF MAX', banner: 'assets/banner_13.png', prizePool: 250, perKill: 20, entryFee: 35, totalSlots: 4, filledSlots: 0, matchTime: 'Today, 11:15 PM', status: 'UPCOMING', roomId: '6601928', roomPassword: '666'),
  TournamentMatch(id: 'BA-114', title: '1v1 Lone Wolf Tournament #114', mode: '1V1 LONE WOLF', map: 'Iron Cage', version: 'FF MAX', banner: 'assets/banner_14.png', prizePool: 120, perKill: 30, entryFee: 40, totalSlots: 2, filledSlots: 0, matchTime: 'Today, 11:30 PM', status: 'UPCOMING', roomId: '7701928', roomPassword: '777'),
  TournamentMatch(id: 'BA-115', title: '2v2 Clash Squad Tournament #115', mode: '2V2 CLASH SQUAD', map: 'CS Kalahari', version: 'FF MAX', banner: 'assets/banner_15.png', prizePool: 300, perKill: 25, entryFee: 40, totalSlots: 4, filledSlots: 0, matchTime: 'Today, 11:45 PM', status: 'UPCOMING', roomId: '8801928', roomPassword: '888'),
  TournamentMatch(id: 'BA-116', title: 'Bermuda Squad 4v4 #116', mode: 'BERMUDA SQUAD 4V4', map: 'Bermuda Full Map', version: 'FF MAX', banner: 'assets/banner_16.png', prizePool: 2000, perKill: 40, entryFee: 50, totalSlots: 48, filledSlots: 0, matchTime: 'Tonight, 12:00 AM', status: 'UPCOMING', roomId: '9901928', roomPassword: '999'),
];

class MatchSlotManager {
  static final Map<String, Map<int, String>> _slotBookings = {};
  static Map<int, String> getSlotsForMatch(TournamentMatch match) {
    if (!_slotBookings.containsKey(match.id)) _slotBookings[match.id] = <int, String>{};
    return _slotBookings[match.id]!;
  }
  static void bookSlot(TournamentMatch match, int slotNumber, String ign) {
    final slots = getSlotsForMatch(match);
    slots[slotNumber] = ign;
    if (slots.length > match.filledSlots) match.filledSlots = slots.length;
  }
}

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  ErrorWidget.builder = (FlutterErrorDetails details) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: AppColors.background,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              buildAppLogo(size: 90, radius: 22),
              const SizedBox(height: 24),
              const Text('BATTLE ARENA - SCREEN ERROR', style: TextStyle(color: AppColors.cyan, fontWeight: FontWeight.bold, letterSpacing: 2, fontSize: 12)),
              const SizedBox(height: 14),
              Padding(
                padding: const EdgeInsets.all(20),
                child: SelectableText(details.exceptionAsString(), textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 12)),
              ),
            ],
          ),
        ),
      ),
    );
  };

  try { SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(statusBarColor: Colors.transparent, statusBarIconBrightness: Brightness.light)); } catch (_) {}
  String? startupError;
  try {
    await Firebase.initializeApp(options: kFirebaseOptions);
  } catch (e, stack) {
    startupError = 'Firebase initialization failed: $e';
    debugPrint('$startupError\\n$stack');
  }
  try { tz.initializeTimeZones(); } catch (e) { debugPrint('Timezone init: $e'); }

  try {
    const AndroidInitializationSettings initializationSettingsAndroid = AndroidInitializationSettings('@mipmap/ic_launcher');
    const InitializationSettings initializationSettings = InitializationSettings(android: initializationSettingsAndroid);
    await flutterLocalNotificationsPlugin.initialize(initializationSettings);
  } catch (e) { debugPrint('Local Notif init: $e'); }

  try {
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
    await FirebaseMessaging.instance.requestPermission(alert: true, badge: true, sound: true);
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      if (message.notification != null) {
        flutterLocalNotificationsPlugin.show(
          message.notification.hashCode, message.notification!.title, message.notification!.body,
          const NotificationDetails(android: AndroidNotificationDetails('high_importance_channel', 'High Importance Notifications', importance: Importance.high, priority: Priority.high, icon: '@mipmap/ic_launcher')),
        );
      }
    });
  } catch (e) { debugPrint('FCM init: $e'); }

  runApp(BattleArenaApp(startupError: startupError));
}

@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp(options: kFirebaseOptions);
}

class BattleArenaApp extends StatelessWidget {
  final String? startupError;
  const BattleArenaApp({super.key, this.startupError});
  @override
  Widget build(BuildContext context) {
    if (startupError != null) {
      return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          backgroundColor: const Color(0xFF080D18),
          body: SafeArea(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: SelectableText(
                  'BATTLE ARENA STARTUP ERROR\\n\\n$startupError',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white, fontSize: 15),
                ),
              ),
            ),
          ),
        ),
      );
    }
    return MaterialApp(
      title: AppConfig.appName,
      debugShowCheckedModeBanner: false,
      navigatorKey: appNavigatorKey,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColors.background,
        primaryColor: AppColors.cyan,
        textTheme: GoogleFonts.rajdhaniTextTheme(ThemeData.dark().textTheme).apply(bodyColor: AppColors.textPrimary, displayColor: AppColors.textPrimary),
      ),
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late AnimationController _animCtrl;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1100))..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.94, end: 1.06).animate(CurvedAnimation(parent: _animCtrl, curve: Curves.easeInOut));
    Timer(const Duration(milliseconds: 2200), () {
      if (mounted) Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const AuthGate()));
    });
  }

  @override
  void dispose() { _animCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ScaleTransition(scale: _pulseAnim, child: buildAppLogo(size: 110, radius: 26, showGlow: true)),
            const SizedBox(height: 26),
            Text('BATTLE ARENA', style: GoogleFonts.orbitron(fontSize: 28, fontWeight: FontWeight.w900, color: AppColors.textPrimary, letterSpacing: 4)),
            const SizedBox(height: 8),
            Text('ULTIMATE ESPORTS BATTLEGROUND', style: GoogleFonts.rajdhani(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.cyan, letterSpacing: 2)),
            const SizedBox(height: 36),
            SizedBox(width: 140, child: ClipRRect(borderRadius: BorderRadius.circular(10), child: const LinearProgressIndicator(minHeight: 4, backgroundColor: AppColors.surfaceLight, valueColor: AlwaysStoppedAnimation<Color>(AppColors.cyan)))),
          ],
        ),
      ),
    );
  }
}

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});
  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  bool _navigated = false;

  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 4), () {
      if (!mounted || _navigated) return;
      _navigated = true;
      try {
        final user = FirebaseAuth.instance.currentUser;
        if (user != null) appNavigatorKey.currentState?.pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const MainShell()), (route) => false);
        else appNavigatorKey.currentState?.pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginScreen()), (route) => false);
      } catch (_) {
        appNavigatorKey.currentState?.pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginScreen()), (route) => false);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    try {
      if (Firebase.apps.isEmpty) return const LoginScreen();
      return StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges().timeout(const Duration(seconds: 6), onTimeout: (sink) => sink.add(null)),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Scaffold(
              backgroundColor: AppColors.background,
              body: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    buildAppLogo(size: 90, radius: 22),
                    const SizedBox(height: 24),
                    const CircularProgressIndicator(color: AppColors.cyan),
                    const SizedBox(height: 14),
                    const Text('LOADING ARENA...', style: TextStyle(color: AppColors.cyan, fontWeight: FontWeight.bold, letterSpacing: 2, fontSize: 12)),
                  ],
                ),
              ),
            );
          }
          if (snapshot.hasError) return const LoginScreen();
          if (snapshot.hasData && snapshot.data != null) {
            if (!_navigated) {
              _navigated = true;
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (mounted) appNavigatorKey.currentState?.pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const MainShell()), (route) => false);
              });
            }
            return const Scaffold(backgroundColor: AppColors.background, body: Center(child: CircularProgressIndicator(color: AppColors.cyan)));
          }
          return const LoginScreen();
        },
      );
    } catch (e) {
      return const LoginScreen();
    }
  }
}
// ============================================================================
// PART 2 of 4: AUTH SCREENS (LOGIN, FORGOT PASSWORD & CELEBRATION)
// ============================================================================

class CelebrationDialog extends StatefulWidget {
  final bool isSignUp;
  final String title;
  final String message;
  
  const CelebrationDialog({
    super.key,
    this.isSignUp = false,
    this.title = 'WELCOME TO BATTLE ARENA! 🎉',
    this.message = 'Login Successful! Prepare for Battle Glory!',
  });

  static Future<void> show(
    BuildContext context, {
    bool isSignUp = false,
    String? title,
    String? message,
  }) {
    return showDialog<void>(
      context: context,
      barrierDismissible: true,
      builder: (_) => CelebrationDialog(
        isSignUp: isSignUp,
        title: title ?? (isSignUp ? 'ACCOUNT CREATED! 🎉' : 'WELCOME BACK WARRIOR! 🎉'),
        message: message ??
            (isSignUp
                ? 'Your battle ID is active. Join contests & win cash prizes!'
                : 'Login Successful! The arena is primed for victory!'),
      ),
    );
  }

  @override
  State<CelebrationDialog> createState() => _CelebrationDialogState();
}

class _CelebrationDialogState extends State<CelebrationDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController _animCtrl;
  
  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3200),
    )..forward();
    
    Timer(const Duration(milliseconds: 3000), () {
      if (mounted) Navigator.of(context, rootNavigator: true).pop();
    });
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF162036), Color(0xFF0C101B)],
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: AppColors.cyan.withOpacity(0.8), width: 2),
          boxShadow: [
            BoxShadow(
              color: AppColors.cyan.withOpacity(0.35),
              blurRadius: 30,
              spreadRadius: 4,
            )
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            buildAppLogo(size: 72, radius: 18),
            const SizedBox(height: 14),
            Text(
              widget.title,
              textAlign: TextAlign.center,
              style: GoogleFonts.orbitron(
                fontSize: 18,
                fontWeight: FontWeight.w900,
                color: AppColors.cyan,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              widget.message,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: AppColors.textPrimary,
                fontSize: 13,
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.cyan,
                  foregroundColor: Colors.black,
                ),
                onPressed: () => Navigator.of(context, rootNavigator: true).pop(),
                child: const Text(
                  'ENTER ARENA ⚔️',
                  style: TextStyle(fontWeight: FontWeight.w900),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});
  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final _emailCtrl = TextEditingController();
  bool _isLoading = false;

  Future<void> _sendRecovery() async {
    final email = _emailCtrl.text.trim();
    if (email.isEmpty || !email.contains('@')) {
      showCustomDialog(
        context: context,
        title: 'INVALID EMAIL',
        message: 'Please enter a valid registered email address.',
        icon: Icons.error_outline,
        color: AppColors.red,
      );
      return;
    }
    
    setState(() => _isLoading = true);
    
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email);
      if (mounted) {
        showCustomDialog(
          context: context,
          title: 'RESET LINK DISPATCHED',
          message: 'Password recovery email sent to $email.',
          icon: Icons.mark_email_read,
          color: AppColors.green,
          btnText: 'BACK TO LOGIN',
          onBtnPressed: () {
            Navigator.pop(context); // Closes dialog
            Navigator.pop(context); // Closes Forgot Password Screen
          },
        );
      }
    } catch (e) {
      if (mounted) {
        showCustomDialog(
          context: context,
          title: 'ERROR',
          message: e.toString(),
          icon: Icons.warning,
          color: AppColors.red,
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        children: [
          Positioned(
            top: -100,
            left: -100,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.cyan.withOpacity(0.1),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.cyan.withOpacity(0.2),
                    blurRadius: 100,
                    spreadRadius: 50,
                  )
                ],
              ),
            ),
          ),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: AppColors.surface.withOpacity(0.8),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: AppColors.cyan.withOpacity(0.3)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.5),
                        blurRadius: 20,
                      )
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Center(child: buildAppLogo(size: 80, radius: 20, showGlow: true)),
                      const SizedBox(height: 20),
                      Text(
                        'RECOVER ACCESS',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.orbitron(
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          color: AppColors.cyan,
                          letterSpacing: 2,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Enter your registered email to receive a secure reset link.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
                      ),
                      const SizedBox(height: 30),
                      TextField(
                        controller: _emailCtrl,
                        keyboardType: TextInputType.emailAddress,
                        style: const TextStyle(color: AppColors.textPrimary),
                        decoration: InputDecoration(
                          hintText: 'Registered Email',
                          prefixIcon: const Icon(Icons.email, color: AppColors.cyan),
                          filled: true,
                          fillColor: AppColors.surfaceLight.withOpacity(0.5),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide.none,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide.none,
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: const BorderSide(color: AppColors.cyan, width: 1.5),
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'Note: If you don\'t receive the email within 2 minutes, please check your Spam/Junk folder.',
                        style: TextStyle(
                          color: AppColors.orange,
                          fontSize: 11,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                      const SizedBox(height: 24),
                      SizedBox(
                        height: 50,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.cyan,
                            foregroundColor: Colors.black,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          onPressed: _isLoading ? null : _sendRecovery,
                          child: _isLoading
                              ? const CircularProgressIndicator(color: Colors.black)
                              : const Text(
                                  'SEND RESET LINK',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1,
                                  ),
                                ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text(
                          'BACK TO LOGIN',
                          style: TextStyle(
                            color: AppColors.textSecondary,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _isSignUp = false, _isLoading = false, _obscure = true, _acceptTerms = false;
  final _email = TextEditingController(),
      _pass = TextEditingController(),
      _name = TextEditingController(),
      _phone = TextEditingController(),
      _referral = TextEditingController();

  Future<void> _submit() async {
    if (_isSignUp && !_acceptTerms) {
      showCustomDialog(
        context: context,
        title: 'TERMS REQUIRED',
        message: 'Please agree to the Terms & Conditions.',
        icon: Icons.warning,
        color: AppColors.orange,
      );
      return;
    }
    
    final email = _email.text.trim(), password = _pass.text.trim();
    if (email.isEmpty || password.isEmpty) {
      showCustomDialog(
        context: context,
        title: 'FIELDS REQUIRED',
        message: 'Please fill email and password.',
        icon: Icons.warning,
        color: AppColors.orange,
      );
      return;
    }
    
    if (_isSignUp) {
      final passwordRegex = RegExp(r'^(?=.*[0-9]).{6,12}$');
      if (!passwordRegex.hasMatch(password)) {
        showCustomDialog(
          context: context,
          title: 'WEAK PASSWORD',
          message: 'Password must be 6-12 characters long and contain at least one number.',
          icon: Icons.security,
          color: AppColors.orange,
        );
        return;
      }
    }

    setState(() => _isLoading = true);
    
    try {
      if (_isSignUp) {
        final phone = _phone.text.trim();
        if (phone.length < 10) {
          showCustomDialog(
            context: context,
            title: 'INVALID PHONE',
            message: 'Provide a valid 10-digit mobile number.',
            icon: Icons.phone_android,
            color: AppColors.orange,
          );
          setState(() => _isLoading = false);
          return;
        }

        try {
          final phoneQuery = await FirebaseFirestore.instance
              .collection('users')
              .where('phone', isEqualTo: phone)
              .get();
          if (phoneQuery.docs.isNotEmpty) {
            showCustomDialog(
              context: context,
              title: 'MOBILE IN USE',
              message: 'This mobile number is already registered.',
              icon: Icons.phone_android,
              color: AppColors.red,
            );
            setState(() => _isLoading = false);
            return;
          }
        } catch (e) {
          debugPrint('Phone check bypassed due to permission');
        }

        final cred = await FirebaseAuth.instance
            .createUserWithEmailAndPassword(email: email, password: password);
        final user = cred.user;
        
        if (user != null) {
          final isAdmin = email.toLowerCase() == AppConfig.adminEmail.toLowerCase();
          final rawName = _name.text.trim().isEmpty ? 'WARRIOR' : _name.text.trim();
          final cleanName = rawName.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');
          final generatedReferral = cleanName.isEmpty
              ? 'ARENA${DateTime.now().millisecondsSinceEpoch.toString().substring(8)}'
              : (cleanName.length > 10 ? cleanName.substring(0, 10) : cleanName);

          await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
            'uid': user.uid,
            'name': rawName,
            'email': email,
            'phone': phone,
            'myReferralCode': generatedReferral,
            'depositBalance': 0.0,
            'winningBalance': 0.0,
            'systemBalance': 0.0,
            'totalBalance': 0.0,
            'totalMatches': 0,
            'totalWins': 0,
            'totalKills': 0,
            'joinedMatches': <String>[],
            'role': isAdmin ? 'admin' : 'player',
            'isAdmin': isAdmin,
            'isBlocked': false,
            'hasSeenTutorial': false,
            'lastBonusDate': '',
            'createdAt': FieldValue.serverTimestamp(),
          });

          final refCode = _referral.text.trim().toUpperCase();
          if (refCode.isNotEmpty) {
            try {
              final referrerQuery = await FirebaseFirestore.instance
                  .collection('users')
                  .where('myReferralCode', isEqualTo: refCode)
                  .get();
              if (referrerQuery.docs.isNotEmpty) {
                await referrerQuery.docs.first.reference.update({
                  'winningBalance': FieldValue.increment(5),
                  'totalBalance': FieldValue.increment(5),
                });
                await FirebaseFirestore.instance.collection('passbook').add({
                  'userId': referrerQuery.docs.first.id,
                  'type': 'REFERRAL_BONUS',
                  'amount': 5.0,
                  'title': 'Referral Bonus from $rawName',
                  'createdAt': FieldValue.serverTimestamp(),
                });
                await FirebaseFirestore.instance.collection('notifications').add({
                  'userId': referrerQuery.docs.first.id,
                  'title': 'Referral Bonus! 🎁',
                  'desc': 'You earned 5 Coins because $rawName joined using your code.',
                  'cat': 'WALLET',
                  'color': 'green',
                  'createdAt': FieldValue.serverTimestamp(),
                });
              }
            } catch (e) {
              debugPrint('Referral error: $e');
            }
          }
        }
      } else {
        await FirebaseAuth.instance
            .signInWithEmailAndPassword(email: email, password: password);
      }
      
      if (mounted) {
        appNavigatorKey.currentState?.pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const MainShell()),
          (route) => false,
        );
      }
    } on FirebaseAuthException catch (e) {
      if (mounted) {
        String msg = e.message ?? 'Auth Error';
        if (e.code == 'email-already-in-use') msg = 'This email is already registered.';
        if (e.code == 'wrong-password' || e.code == 'user-not-found') {
          msg = 'Invalid email or password.';
        }
        showCustomDialog(
          context: context,
          title: 'AUTH ERROR',
          message: msg,
          icon: Icons.security,
          color: AppColors.red,
        );
      }
    } catch (e) {
      if (mounted) {
        showCustomDialog(
          context: context,
          title: 'SYSTEM ERROR',
          message: e.toString(),
          icon: Icons.error,
          color: AppColors.red,
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        children: [
          Positioned(
            top: -100,
            right: -100,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.cyan.withOpacity(0.1),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.cyan.withOpacity(0.2),
                    blurRadius: 100,
                    spreadRadius: 50,
                  )
                ],
              ),
            ),
          ),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: AppColors.surface.withOpacity(0.85),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: AppColors.cyan.withOpacity(0.3)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.5),
                        blurRadius: 20,
                      )
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Center(child: buildAppLogo(size: 90, radius: 22, showGlow: true)),
                      const SizedBox(height: 16),
                      Text(
                        _isSignUp ? 'CREATE ACCOUNT' : 'WELCOME BACK',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.orbitron(
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                          color: _isSignUp ? AppColors.gold : AppColors.cyan,
                          letterSpacing: 2,
                        ),
                      ),
                      const SizedBox(height: 24),
                      if (_isSignUp) ...[
                        _buildPremiumField(_name, 'In-Game Name', Icons.person),
                        const SizedBox(height: 16),
                        _buildPremiumField(_phone, 'Mobile Number', Icons.phone, keyboardType: TextInputType.phone),
                        const SizedBox(height: 16),
                      ],
                      _buildPremiumField(_email, 'Email Address', Icons.email, keyboardType: TextInputType.emailAddress),
                      const SizedBox(height: 16),
                      _buildPremiumField(
                        _pass,
                        'Password',
                        Icons.lock,
                        obscure: _obscure,
                        suffix: IconButton(
                          icon: Icon(_obscure ? Icons.visibility_off : Icons.visibility, color: AppColors.cyan),
                          onPressed: () => setState(() => _obscure = !_obscure),
                        ),
                      ),
                      if (_isSignUp) ...[
                        const SizedBox(height: 16),
                        _buildPremiumField(_referral, 'Referral Code (Optional)', Icons.card_giftcard),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Checkbox(
                              value: _acceptTerms,
                              onChanged: (v) => setState(() => _acceptTerms = v!),
                              activeColor: AppColors.green,
                            ),
                            const Expanded(
                              child: Text(
                                'I agree to Terms & Conditions',
                                style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
                              ),
                            ),
                          ],
                        ),
                      ],
                      const SizedBox(height: 20),
                      SizedBox(
                        height: 52,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _isSignUp ? AppColors.gold : AppColors.cyan,
                            foregroundColor: Colors.black,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          onPressed: _isLoading ? null : _submit,
                          child: _isLoading
                              ? const CircularProgressIndicator(color: Colors.black)
                              : Text(
                                  _isSignUp ? 'REGISTER NOW' : 'ENTER ARENA',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w900,
                                    fontSize: 16,
                                    letterSpacing: 1,
                                  ),
                                ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextButton(
                        onPressed: () => setState(() => _isSignUp = !_isSignUp),
                        child: Text(
                          _isSignUp ? 'Already have an account? Login' : "Don't have an account? Register",
                          style: TextStyle(
                            color: _isSignUp ? AppColors.cyan : AppColors.gold,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      
                      // 🔥 FORGOT PASSWORD BUTTON - PROPERLY PLACED
                      if (!_isSignUp)
                        TextButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const ForgotPasswordScreen(),
                              ),
                            );
                          },
                          child: const Text(
                            'Forgot Password?',
                            style: TextStyle(color: AppColors.cyan, fontSize: 13),
                          ),
                        ),
                      
                    ], // Closing Column children
                  ), // Closing Column
                ), // Closing Container
              ), // Closing SingleChildScrollView
            ), // Closing Center
          ), // Closing SafeArea
        ], // Closing Stack children
      ), // Closing Stack
    ); // Closing Scaffold
  }

  Widget _buildPremiumField(
    TextEditingController ctrl,
    String hint,
    IconData icon, {
    bool obscure = false,
    Widget? suffix,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return TextField(
      controller: ctrl,
      obscureText: obscure,
      keyboardType: keyboardType,
      style: const TextStyle(color: AppColors.textPrimary),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: AppColors.textMuted),
        prefixIcon: Icon(icon, color: AppColors.cyan),
        suffixIcon: suffix,
        filled: true,
        fillColor: AppColors.surfaceLight.withOpacity(0.5),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.cyan, width: 1.5),
        ),
      ),
    );
  }
}
// ============================================================================
// PART 3 of 4: MAIN SHELL, HOME SCREEN & MATCH CARDS
// ============================================================================

// ============================================================================
// MAIN SHELL (App Control Center)
// ============================================================================

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _currentIndex = 2;
  final List<Widget> _pages = const [
    EarnScreen(),
    LeaderboardScreen(),
    HomeScreen(),
    MenuScreen()
  ];
  
  String _sessionId = DateTime.now().millisecondsSinceEpoch.toString();
  bool _alertShown = false;
  bool _welcomeShown = false;
  bool _updateShown = false;
  bool _tutorialShown = false;
  DateTime? _lastBackPress;

  @override
  void initState() {
    super.initState();
    _initApp();
    _checkSingleDeviceLogin();
    _showWhatsAppPopup();
    // _checkDailyBonus(); //
  }

  void _showWhatsAppPopup() async {
    if (mounted) {
      Future.delayed(const Duration(milliseconds: 1500), () {
        if (mounted) {
          showDialog(
            context: context,
            barrierDismissible: true,
            builder: (ctx) => Dialog(
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: Stack(
                children: [
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Image.asset(
                        'assets/home_screen_banner_06.png',
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          height: 150,
                          color: Colors.green,
                          child: const Center(
                            child: Icon(Icons.chat, color: Colors.white, size: 60),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            const Text(
                              'WHATSAPP CHANNEL ✅',
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.w900,
                                fontSize: 16,
                              ),
                            ),
                            const SizedBox(height: 8),
                            const Text(
                              'Get daily updates, free match IDs and passwords, and exciting giveaways. Follow our channel!',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.black87, fontSize: 12),
                            ),
                            const SizedBox(height: 16),
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: const Color(0xFF25D366),
                                  foregroundColor: Colors.white,
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                ),
                                onPressed: () {
                                  Navigator.pop(ctx);
                                  openExternalUrl(context, AppConfig.whatsappChannelUrl);
                                },
                                child: const Text(
                                  'FOLLOW NOW',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  Positioned(
                    top: 8,
                    right: 8,
                    child: InkWell(
                      onTap: () => Navigator.pop(ctx),
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(
                          color: Colors.blueAccent,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.close, color: Colors.white, size: 16),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        }
      });
    }
  }

  void _initApp() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    FirebaseMessaging.instance.getToken().then((token) async {
      if (token != null) {
        await FirebaseFirestore.instance.collection('users').doc(user.uid).update({
          'fcmToken': token
        });
      }
    });

    final doc = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
    if (!doc.exists) {
      final isAdmin = user.email?.toLowerCase() == AppConfig.adminEmail.toLowerCase();
      final rawName = user.email?.split('@').first ?? 'Warrior';
      final cleanName = rawName.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');
      final fbReferral = cleanName.isEmpty ? 'ARENA2026' : (cleanName.length > 10 ? cleanName.substring(0, 10) : cleanName);

      await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
        'uid': user.uid,
        'name': rawName,
        'email': user.email,
        'phone': 'Not Provided',
        'myReferralCode': fbReferral,
        'depositBalance': 0.0,
        'winningBalance': 0.0,
        'systemBalance': 0.0,
        'joinedMatches': <String>[],
        'role': isAdmin ? 'admin' : 'player',
        'isAdmin': isAdmin,
        'isBlocked': false,
        'hasSeenTutorial': false,
        'lastBonusDate': '',
      });
      _showTutorial();
    } else {
      final data = doc.data() as Map<String, dynamic>;
      if (data['hasSeenTutorial'] == false) _showTutorial();
    }

    bool isAdmin = user.email?.toLowerCase() == AppConfig.adminEmail.toLowerCase();
    if (isAdmin && !_welcomeShown && mounted) {
      _welcomeShown = true;
      Future.delayed(const Duration(milliseconds: 500), () {
        if (mounted) {
          showDialog(
            context: context,
            barrierDismissible: false,
            builder: (ctx) => Dialog(
              backgroundColor: Colors.transparent,
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF2E1065), Color(0xFF1E1B4B)],
                  ),
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: AppColors.gold, width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.gold.withOpacity(0.3),
                      blurRadius: 30,
                      spreadRadius: 5,
                    )
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.admin_panel_settings, size: 80, color: AppColors.gold),
                    const SizedBox(height: 16),
                    Text(
                      'ADMIN ACCESS GRANTED',
                      style: GoogleFonts.orbitron(
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        color: AppColors.gold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Welcome Commander! You have full control of the Arena.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white70, fontSize: 13),
                    ),
                    const SizedBox(height: 24),
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.gold,
                          foregroundColor: Colors.black,
                        ),
                        onPressed: () => Navigator.pop(ctx),
                        child: const Text(
                          'ENTER CONTROL PANEL 👑',
                          style: TextStyle(fontWeight: FontWeight.w900),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }
      });
    }
  }

  void _showTutorial() async {
    if (_tutorialShown) return;
    _tutorialShown = true;
    final prefs = await SharedPreferences.getInstance();
    bool seen = prefs.getBool('seenTutorial') ?? false;

    if (!seen && mounted) {
      Future.delayed(const Duration(milliseconds: 800), () {
        if (!mounted) return;
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (ctx) => Dialog(
            backgroundColor: AppColors.surface,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.sports_esports, size: 60, color: AppColors.cyan),
                  const SizedBox(height: 16),
                  Text(
                    'WELCOME TO BATTLE ARENA',
                    textAlign: TextAlign.center,
                    style: GoogleFonts.orbitron(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      color: AppColors.cyan,
                    ),
                  ),
                  const SizedBox(height: 16),
                  _buildTutorialStep('1', 'Add Coins', 'Go to Wallet and add coins using UPI.'),
                  _buildTutorialStep('2', 'Join Match', 'Select a match, pick your slot, and enter your IGN.'),
                  _buildTutorialStep('3', 'Play & Win', 'Room ID & Pass unlock 5-10 mins before match. Play and win coins!'),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 46,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.cyan,
                        foregroundColor: Colors.black,
                      ),
                      onPressed: () async {
                        await prefs.setBool('seenTutorial', true);
                        final user = FirebaseAuth.instance.currentUser;
                        if (user != null) {
                          await FirebaseFirestore.instance.collection('users').doc(user.uid).update({
                            'hasSeenTutorial': true
                          });
                        }
                        if (ctx.mounted) Navigator.pop(ctx);
                      },
                      child: const Text(
                        'GOT IT, LET\'S PLAY',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      });
    }
  }

  Widget _buildTutorialStep(String step, String title, String desc) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            radius: 12,
            backgroundColor: AppColors.cyan,
            child: Text(
              step,
              style: const TextStyle(
                color: Colors.black,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                Text(desc, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _checkSingleDeviceLogin() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || user.email?.toLowerCase() == AppConfig.adminEmail.toLowerCase()) return;

    final userRef = FirebaseFirestore.instance.collection('users').doc(user.uid);
    await userRef.update({'activeSessionId': _sessionId});

    userRef.snapshots().listen((snap) {
      if (snap.exists) {
        final data = snap.data()!;
        if (data['activeSessionId'] != null && data['activeSessionId'] != _sessionId && !_alertShown) {
          _alertShown = true;
          if (mounted) {
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (ctx) => PopScope(
                canPop: false,
                child: AlertDialog(
                  backgroundColor: AppColors.surface,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                    side: const BorderSide(color: AppColors.red, width: 2),
                  ),
                  title: const Row(
                    children: [
                      Icon(Icons.security, color: AppColors.red, size: 28),
                      SizedBox(width: 8),
                      Text(
                        'SECURITY ALERT 🔒',
                        style: TextStyle(
                          color: AppColors.red,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                    ],
                  ),
                  content: const Text(
                    'Your account has been logged in from another device. You have been logged out automatically to protect your account.',
                    style: TextStyle(color: AppColors.textPrimary),
                  ),
                  actions: [
                    SizedBox(
                      width: double.infinity,
                      height: 46,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.red,
                          foregroundColor: Colors.white,
                        ),
                        onPressed: () {
                          Navigator.pop(ctx);
                          FirebaseAuth.instance.signOut();
                        },
                        child: const Text(
                          'OK, UNDERSTOOD',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          }
        }
      }
    });
  }

  Future<void> _checkForceUpdate() async {
    if (_updateShown) return;
    try {
      final appSettings = await FirebaseFirestore.instance.collection('settings').doc('app').get();
      if (appSettings.exists) {
        final minVersion = appSettings.data()?['minVersion'];
        if (minVersion != null) {
          final packageInfo = await PackageInfo.fromPlatform();
          if (packageInfo.version != minVersion) {
            _updateShown = true;
            if (mounted) {
              showDialog(
                context: context,
                barrierDismissible: false,
                builder: (ctx) => PopScope(
                  canPop: false,
                  child: AlertDialog(
                    backgroundColor: AppColors.surface,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                      side: const BorderSide(color: AppColors.cyan, width: 2),
                    ),
                    title: const Row(
                      children: [
                        Icon(Icons.system_update, color: AppColors.cyan, size: 28),
                        SizedBox(width: 8),
                        Text(
                          'UPDATE REQUIRED',
                          style: TextStyle(
                            color: AppColors.cyan,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                    content: const Text(
                      'A new version of Battle Arena is available. Please update the app to continue playing.',
                      style: TextStyle(color: AppColors.textPrimary),
                    ),
                    actions: [
                      SizedBox(
                        width: double.infinity,
                        height: 46,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.cyan,
                            foregroundColor: Colors.black,
                          ),
                          onPressed: () {},
                          child: const Text(
                            'DOWNLOAD UPDATE',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }
          }
        }
      }
    } catch (e) {
      debugPrint("Update Check Error: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<ConnectivityResult>>(
      stream: Connectivity().onConnectivityChanged,
      builder: (context, connectivitySnapshot) {
        bool isOffline = connectivitySnapshot.hasData &&
            connectivitySnapshot.data!.contains(ConnectivityResult.none);
        if (isOffline) {
          return Scaffold(
            backgroundColor: AppColors.background,
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.wifi_off, size: 80, color: AppColors.red),
                  const SizedBox(height: 20),
                  Text(
                    'NO INTERNET CONNECTION',
                    style: GoogleFonts.orbitron(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: AppColors.red,
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'Please check your network and try again.',
                    style: TextStyle(color: AppColors.textSecondary),
                  ),
                ],
              ),
            ),
          );
        }

        final user = FirebaseAuth.instance.currentUser;

        return StreamBuilder<DocumentSnapshot>(
          stream: FirebaseFirestore.instance.collection('settings').doc('app').snapshots(),
          builder: (context, snap) {
            bool isMaintenance = false;
            int maintenanceEndTime = 0;

            if (snap.hasData && snap.data!.exists) {
              final data = snap.data!.data() as Map;
              isMaintenance = data['isMaintenance'] ?? false;
              maintenanceEndTime = (data['maintenanceEndTime'] as num?)?.toInt() ?? 0;
            }

            bool isAdmin = user?.email?.toLowerCase() == AppConfig.adminEmail.toLowerCase();

            if (isMaintenance && !isAdmin) {
              return MaintenanceScreen(endTime: maintenanceEndTime);
            }

            return StreamBuilder<DocumentSnapshot>(
              stream: user == null ? null : FirebaseFirestore.instance.collection('users').doc(user.uid).snapshots(),
              builder: (context, userSnap) {
                bool isBlocked = false;
                String blockReason = 'Suspicious activity detected.';
                if (userSnap.hasData && userSnap.data!.exists) {
                  final uData = userSnap.data!.data() as Map;
                  isBlocked = uData['isBlocked'] ?? false;
                  blockReason = uData['blockReason'] ?? 'Suspicious activity detected.';
                }

                if (isBlocked) {
                  return Scaffold(
                    backgroundColor: AppColors.background,
                    body: Center(
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.block, size: 80, color: AppColors.red),
                            const SizedBox(height: 20),
                            Text(
                              'ACCOUNT SUSPENDED',
                              style: GoogleFonts.orbitron(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: AppColors.red,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Text(
                              'Reason: $blockReason',
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                color: AppColors.orange,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 20),
                            const Text(
                              'If you think this is a mistake, contact support.',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: AppColors.textSecondary),
                            ),
                            const SizedBox(height: 30),
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.red,
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 14),
                              ),
                              onPressed: () => FirebaseAuth.instance.signOut(),
                              child: const Text(
                                'LOGOUT',
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                }

                WidgetsBinding.instance.addPostFrameCallback((_) => _checkForceUpdate());

                return PopScope(
                  canPop: false,
                  onPopInvokedWithResult: (didPop, result) {
                    if (didPop) return;
                    final now = DateTime.now();
                    if (_lastBackPress == null ||
                        now.difference(_lastBackPress!) > const Duration(seconds: 2)) {
                      _lastBackPress = now;
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Press back again to exit'),
                          duration: Duration(seconds: 2),
                        ),
                      );
                      return;
                    }
                    SystemNavigator.pop();
                  },
                  child: Scaffold(
                    body: IndexedStack(index: _currentIndex, children: _pages),
                    bottomNavigationBar: BottomNavigationBar(
                      currentIndex: _currentIndex,
                      onTap: (index) => setState(() => _currentIndex = index),
                      backgroundColor: AppColors.surface,
                      selectedItemColor: AppColors.cyan,
                      unselectedItemColor: AppColors.textMuted,
                      type: BottomNavigationBarType.fixed,
                      items: const [
                        BottomNavigationBarItem(
                          icon: Icon(Icons.monetization_on),
                          label: 'Earn',
                        ),
                        BottomNavigationBarItem(
                          icon: Icon(Icons.emoji_events),
                          label: 'Leaderboard',
                        ),
                        BottomNavigationBarItem(
                          icon: Icon(Icons.sports_esports),
                          label: 'Home',
                        ),
                        BottomNavigationBarItem(
                          icon: Icon(Icons.grid_view),
                          label: 'Menu',
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        );
      },
    );
  }
}

class MaintenanceScreen extends StatefulWidget {
  final int endTime;
  const MaintenanceScreen({super.key, required this.endTime});
  @override
  State<MaintenanceScreen> createState() => _MaintenanceScreenState();
}

class _MaintenanceScreenState extends State<MaintenanceScreen> {
  Timer? _timer;
  Duration _timeLeft = Duration.zero;

  @override
  void initState() {
    super.initState();
    if (widget.endTime > 0) {
      _startTimer();
    }
  }

  void _startTimer() {
    _calculateTimeLeft();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted) setState(() => _calculateTimeLeft());
    });
  }

  void _calculateTimeLeft() {
    final now = DateTime.now().millisecondsSinceEpoch;
    final diff = widget.endTime - now;
    setState(() {
      _timeLeft = diff > 0 ? Duration(milliseconds: diff) : Duration.zero;
    });
    if (_timeLeft == Duration.zero && _timer != null) {
      _timer?.cancel();
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    String hours = twoDigits(_timeLeft.inHours);
    String minutes = twoDigits(_timeLeft.inMinutes.remainder(60));
    String seconds = twoDigits(_timeLeft.inSeconds.remainder(60));

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.construction, size: 80, color: AppColors.gold),
              const SizedBox(height: 20),
              Text(
                'APP UNDER MAINTENANCE',
                style: GoogleFonts.orbitron(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: AppColors.gold,
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                'We are upgrading the arena. Please check back soon!',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.textSecondary),
              ),
              const SizedBox(height: 30),
              if (widget.endTime > 0 && _timeLeft != Duration.zero) ...[
                const Text(
                  'Back in:',
                  style: TextStyle(fontSize: 16, color: Colors.white70),
                ),
                const SizedBox(height: 8),
                Text(
                  '$hours:$minutes:$seconds',
                  style: GoogleFonts.orbitron(
                    fontSize: 36,
                    fontWeight: FontWeight.bold,
                    color: AppColors.cyan,
                  ),
                ),
              ]
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================================
// GLOBAL TIME PARSER & ROOM TIMING HELPERS (STRICT)
// ============================================================================
DateTime? _parseMatchTime(String timeStr) {
  try {
    final now = DateTime.now();
    final lowerStr = timeStr.toLowerCase();
    final timeMatch = RegExp(r'(\d{1,2})[:.](\d{2})\s*([aApP][mM])?').firstMatch(timeStr);
    
    if (timeMatch == null) return null;
    
    int hour = int.parse(timeMatch.group(1)!);
    int minute = int.parse(timeMatch.group(2)!);
    String? period = timeMatch.group(3)?.toUpperCase();
    
    if (period == 'PM' && hour != 12) hour += 12;
    if (period == 'AM' && hour == 12) hour = 0;
    
    int daysToAdd = 0;
    
    if (lowerStr.contains('today') || lowerStr.contains('tonight')) {
      daysToAdd = 0;
    } else if (lowerStr.contains('tomorrow')) {
      daysToAdd = 1;
    } else {
      final days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
      for (int i = 0; i < days.length; i++) {
        if (lowerStr.contains(days[i])) {
          int targetDay = i + 1;
          int currentDay = now.weekday;
          daysToAdd = targetDay - currentDay;
          
          if (daysToAdd < 0) {
            daysToAdd += 7;
          } else if (daysToAdd == 0) {
            if (DateTime(now.year, now.month, now.day, hour, minute).isBefore(now)) {
              daysToAdd = 7;
            }
          }
          break;
        }
      }
    }
    
    final matchDate = now.add(Duration(days: daysToAdd));
    return DateTime(matchDate.year, matchDate.month, matchDate.day, hour, minute);
  } catch (e) {
    return null;
  }
}

bool _isMatchStarted(TournamentMatch match) {
  final matchTime = _parseMatchTime(match.matchTime);
  if (matchTime == null) return false;
  // Agar current time, match time se aage nikal gaya hai, toh match start ho chuka hai
  return DateTime.now().isAfter(matchTime);
}

bool _checkRoomTiming(TournamentMatch match) {
  if (match.status == 'ONGOING' || match.status == 'RESULTED' || match.status == 'CANCELLED') return true;
  if (match.status != 'UPCOMING') return false;
  
  final matchTime = _parseMatchTime(match.matchTime);
  if (matchTime == null) return false;
  
  final now = DateTime.now();
  // 🔥 Exact Seconds mein check (5 minute = 300 seconds)
  final diffInSeconds = matchTime.difference(now).inSeconds;
  
  // Sirf tabhi khulega jab time 300 seconds ya usse kam bacha ho
  return diffInSeconds <= 300 && diffInSeconds >= 0; 
}

class MatchCountdownTimer extends StatefulWidget {
  final TournamentMatch match;
  const MatchCountdownTimer({super.key, required this.match});
  @override
  State<MatchCountdownTimer> createState() => _MatchCountdownTimerState();
}

class _MatchCountdownTimerState extends State<MatchCountdownTimer> {
  Timer? _timer;
  Duration _timeLeft = Duration.zero;
  bool _isInvalidTime = false;

  @override
  void initState() {
    super.initState();
    _calculateTimeLeft();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted) setState(() => _calculateTimeLeft());
    });
  }

  @override
  void didUpdateWidget(covariant MatchCountdownTimer oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.match.matchTime != widget.match.matchTime) {
      _calculateTimeLeft();
    }
  }

  void _calculateTimeLeft() {
    final matchTime = _parseMatchTime(widget.match.matchTime);
    if (matchTime == null) {
      setState(() => _isInvalidTime = true);
      return;
    }
    final diff = matchTime.difference(DateTime.now());
    setState(() {
      _isInvalidTime = false;
      _timeLeft = diff.isNegative ? Duration.zero : diff;
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isInvalidTime) {
      return const Text(
        'Invalid Time',
        style: TextStyle(color: AppColors.red, fontSize: 12),
      );
    }
    if (_timeLeft == Duration.zero) {
      return const Text(
        'STARTING SOON',
        style: TextStyle(
          color: AppColors.orange,
          fontWeight: FontWeight.bold,
          fontSize: 12,
        ),
      );
    }
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    return Text(
      'Starts: ${_timeLeft.inDays > 0 ? '${_timeLeft.inDays}d ' : ''}${twoDigits(_timeLeft.inHours.remainder(24))}h ${twoDigits(_timeLeft.inMinutes.remainder(60))}m ${twoDigits(_timeLeft.inSeconds.remainder(60))}s',
      style: const TextStyle(
        color: AppColors.gold,
        fontWeight: FontWeight.bold,
        fontSize: 12,
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final PageController _carouselController = PageController();
  int _currentCarouselIndex = 0;
  Timer? _autoSlideTimer;
  bool _showOnlyFree = false;

  final List<Map<String, String?>> _homeBanners = const [
    {'image': 'assets/home_screen_banner_01.png', 'link': null},
    {'image': 'assets/home_screen_banner_02.png', 'link': null},
    {'image': 'assets/home_screen_banner_03.png', 'link': null},
    {'image': 'assets/home_screen_banner_04.png', 'link': 'https://youtube.com/@battlearena_official?si=w17ezZUog3ZBEiMc'},
    {'image': 'assets/home_screen_banner_05.png', 'link': 'https://discord.gg/yBaY6ktH'},
    {'image': 'assets/home_screen_banner_06.png', 'link': AppConfig.whatsappChannelUrl},
    {'image': 'assets/home_screen_banner_07.png', 'link': 'https://www.instagram.com/official_battlearena/'},
    {'image': 'assets/home_screen_banner_08.png', 'link': 'https://t.me/the_battlearena_official'},
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this, initialIndex: 1);
    
    _autoSlideTimer = Timer.periodic(const Duration(seconds: 4), (timer) {
      if (!_carouselController.hasClients) return;
      final nextPage = _currentCarouselIndex + 1;
      if (nextPage >= _homeBanners.length) {
        _carouselController.jumpToPage(0);
      } else {
        _carouselController.animateToPage(
          nextPage,
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeInOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _autoSlideTimer?.cancel();
    _tabController.dispose();
    _carouselController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('matches').snapshots(),
      builder: (context, matchSnapshots) {
        final List<TournamentMatch> dynamicMatches = [];

        if (matchSnapshots.hasData) {
          for (var doc in matchSnapshots.data!.docs) {
            final data = doc.data() as Map<String, dynamic>;
            
            if (data['isDeleted'] == true && data['status'] != 'RESULTED') continue;

            String currentStatus = data['status'] ?? 'UPCOMING';
            final matchTime = _parseMatchTime(data['matchTime'] ?? '');
            if (matchTime != null && DateTime.now().isAfter(matchTime) && currentStatus == 'UPCOMING') {
              currentStatus = 'ONGOING';
              doc.reference.update({'status': 'ONGOING'});
            }

            final modeData = kGameModes.firstWhere(
              (m) => m.title == data['mode'],
              orElse: () => kGameModes.first,
            );

            dynamicMatches.add(TournamentMatch(
              id: doc.id,
              title: data['title'] ?? 'New Match',
              mode: data['mode'] ?? 'SOLO',
              map: data['map'] ?? 'Bermuda',
              version: data['version'] ?? 'FF MAX',
              banner: data['banner'] ?? modeData.banner,
              prizePool: (data['prizePool'] as num?)?.toInt() ?? 100,
              perKill: (data['perKill'] as num?)?.toInt() ?? 10,
              entryFee: (data['entryFee'] as num?)?.toInt() ?? 20,
              totalSlots: (data['totalSlots'] as num?)?.toInt() ?? 48,
              filledSlots: (data['filledSlots'] as num?)?.toInt() ?? 0,
              matchTime: data['matchTime'] ?? 'Today, 10:00 PM',
              status: currentStatus,
              roomId: data['roomId'] ?? 'TBD',
              roomPassword: data['roomPassword'] ?? 'TBD',
              isRoomRevealed: data['isRoomRevealed'] ?? false,
            ));
          }
        }

        dynamicMatches.sort((a, b) {
          final tA = _parseMatchTime(a.matchTime);
          final tB = _parseMatchTime(b.matchTime);
          if (tA == null) return 1;
          if (tB == null) return -1;
          return tA.compareTo(tB);
        });

        return Scaffold(
          backgroundColor: AppColors.background,
          appBar: AppBar(
            backgroundColor: AppColors.surface,
            elevation: 0,
            titleSpacing: 10,
            title: Row(
              children: [
                buildAppLogo(size: 32, radius: 8, showGlow: false),
                const SizedBox(width: 6),
                const Expanded(
                  child: Text(
                    'BATTLE ARENA',
                    style: TextStyle(
                      fontFamily: 'Orbitron',
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                      color: AppColors.cyan,
                      letterSpacing: 1,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.language, color: AppColors.cyan),
                onPressed: () => openExternalUrl(context, AppConfig.websiteUrl),
                tooltip: 'Website',
              ),
              if (user != null)
                StreamBuilder<DocumentSnapshot>(
                  stream: FirebaseFirestore.instance.collection('users').doc(user.uid).snapshots(),
                  builder: (context, snapshot) {
                    double total = 0.0;
                    if (snapshot.hasData && snapshot.data!.exists) {
                      final data = snapshot.data!.data() as Map<String, dynamic>;
                      total = (((data['depositBalance'] ?? 0) as num) +
                              ((data['winningBalance'] ?? 0) as num) +
                              ((data['systemBalance'] ?? 0) as num))
                          .toDouble();
                    }
                    return InkWell(
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const WalletScreen()),
                      ),
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppColors.surfaceLight,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: AppColors.gold.withOpacity(0.5)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.monetization_on, color: AppColors.gold, size: 16),
                            const SizedBox(width: 4),
                            ConstrainedBox(
                              constraints: const BoxConstraints(maxWidth: 65),
                              child: FittedBox(
                                fit: BoxFit.scaleDown,
                                child: Text(
                                  '${total.toStringAsFixed(0)} C',
                                  style: const TextStyle(
                                    color: AppColors.gold,
                                    fontWeight: FontWeight.w900,
                                    fontSize: 13,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 4),
                            const Icon(Icons.add_circle, color: AppColors.cyan, size: 14),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              IconButton(
                icon: const Icon(Icons.notifications_active_outlined, color: AppColors.textPrimary),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const NotificationsScreen()),
                ),
              ),
            ],
          ),
          body: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  color: AppColors.surfaceLight.withOpacity(0.5),
                  child: const Row(
                    children: [
                      Icon(Icons.campaign, color: AppColors.gold, size: 20),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Welcome to Battle Arena! Room ID & Password shared 5-10m before match. No emulators allowed!',
                          style: TextStyle(
                            fontSize: 12,
                            color: AppColors.textSecondary,
                            fontWeight: FontWeight.w600,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),

                SizedBox(
                  height: 180,
                  child: PageView.builder(
                    controller: _carouselController,
                    onPageChanged: (i) => setState(() => _currentCarouselIndex = i),
                    itemCount: _homeBanners.length,
                    itemBuilder: (context, index) {
                      final banner = _homeBanners[index];
                      return GestureDetector(
                        onTap: () {
                          if (banner['link'] != null && banner['link']!.isNotEmpty) {
                            openExternalUrl(context, banner['link']!);
                          }
                        },
                        child: Container(
                          margin: const EdgeInsets.symmetric(horizontal: 16),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: AppColors.cardBorder),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(14),
                            child: AspectRatio(
                              aspectRatio: 16 / 9,
                              child: Image.asset(
                                banner['image']!,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Container(
                                  decoration: const BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [Color(0xFF1E293B), Color(0xFF0F172A)],
                                    ),
                                  ),
                                  child: const Center(
                                    child: Icon(Icons.sports_esports, size: 48, color: AppColors.cyan),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 6),
                Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(
                      _homeBanners.length,
                      (index) => Container(
                        margin: const EdgeInsets.symmetric(horizontal: 3),
                        width: _currentCarouselIndex == index ? 16 : 6,
                        height: 5,
                        decoration: BoxDecoration(
                          color: _currentCarouselIndex == index
                              ? AppColors.cyan
                              : AppColors.cardBorder,
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(width: 4, height: 18, color: AppColors.cyan),
                          const SizedBox(width: 8),
                          const Text(
                            'FEATURED GAME MODES',
                            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: 1.2),
                          ),
                        ],
                      ),
                      Text(
                        '${kGameModes.length} Modes',
                        style: const TextStyle(color: AppColors.textMuted, fontSize: 12),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: kGameModes.length,
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 16 / 11,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                    ),
                    itemBuilder: (context, index) {
                      final mode = kGameModes[index];
                      return Container(
                        decoration: BoxDecoration(
                          color: AppColors.surface,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: AppColors.cardBorder),
                        ),
                        child: Material(
                          color: Colors.transparent,
                          child: InkWell(
                            borderRadius: BorderRadius.circular(12),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (_) => ModeContestsScreen(mode: mode)),
                              );
                            },
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  Expanded(
                                    child: Stack(
                                      fit: StackFit.expand,
                                      children: [
                                        Image.asset(
                                          mode.banner,
                                          fit: BoxFit.cover,
                                          errorBuilder: (_, __, ___) => Container(
                                            color: AppColors.surfaceLight,
                                            child: const Center(
                                              child: Icon(Icons.gamepad, color: AppColors.cyan, size: 28),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          decoration: BoxDecoration(
                                            gradient: LinearGradient(
                                              begin: Alignment.topCenter,
                                              end: Alignment.bottomCenter,
                                              colors: [Colors.transparent, Colors.black.withOpacity(0.7)],
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          top: 6,
                                          right: 6,
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                            decoration: BoxDecoration(
                                              color: AppColors.cyan,
                                              borderRadius: BorderRadius.circular(4),
                                            ),
                                            child: Text(
                                              mode.tag,
                                              style: const TextStyle(
                                                color: Colors.black,
                                                fontWeight: FontWeight.w900,
                                                fontSize: 9,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          mode.title,
                                          style: const TextStyle(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w900,
                                            color: AppColors.textPrimary,
                                          ),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        Text(
                                          mode.subtitle,
                                          style: const TextStyle(
                                            fontSize: 10,
                                            color: AppColors.textMuted,
                                          ),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 24),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      Container(width: 4, height: 18, color: AppColors.gold),
                      const SizedBox(width: 8),
                      const Text(
                        'TOURNAMENT ARENA',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: 1.2),
                      ),
                    ],
                  ),
                ),
                
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      const Text(
                        'Only Free Matches',
                        style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(width: 6),
                      SizedBox(
                        height: 24,
                        width: 40,
                        child: Switch(
                          value: _showOnlyFree,
                          activeColor: AppColors.cyan,
                          onChanged: (v) => setState(() => _showOnlyFree = v),
                        ),
                      ),
                    ],
                  ),
                ),

                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppColors.cardBorder),
                  ),
                  child: TabBar(
                    controller: _tabController,
                    indicator: BoxDecoration(
                      color: AppColors.cyan,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    labelColor: Colors.black,
                    unselectedLabelColor: AppColors.textSecondary,
                    labelStyle: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12),
                    tabs: const [
                      Tab(text: '🔴 LIVE'),
                      Tab(text: '⏳ UPCOMING'),
                      Tab(text: '🏆 RESULTED'),
                    ],
                  ),
                ),
                const SizedBox(height: 14),

                AnimatedBuilder(
                  animation: _tabController,
                  builder: (context, _) {
                    String filter = 'UPCOMING';
                    if (_tabController.index == 0) filter = 'ONGOING';
                    if (_tabController.index == 2) filter = 'RESULTED';

                    var matches = dynamicMatches.where((m) => m.status == filter).toList();
                    if (_showOnlyFree) {
                      matches = matches.where((m) => m.entryFee == 0).toList();
                    }

                    if (matches.isEmpty) {
                      return const Padding(
                        padding: EdgeInsets.all(40),
                        child: Center(
                          child: Text(
                            'No matches in this category right now',
                            style: TextStyle(color: AppColors.textMuted),
                          ),
                        ),
                      );
                    }

                    return ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: matches.length,
                      itemBuilder: (context, index) => TournamentMatchCard(match: matches[index]),
                    );
                  },
                ),
                const SizedBox(height: 30),
              ],
            ),
          ),
        );
      },
    );
  }
}

class ModeContestsScreen extends StatelessWidget {
  final GameModeItem mode;
  const ModeContestsScreen({super.key, required this.mode});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: AppColors.background,
        appBar: AppBar(
          title: Text(
            mode.title.toUpperCase(),
            style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2, fontSize: 16),
          ),
          backgroundColor: AppColors.surface,
          bottom: const TabBar(
            indicatorColor: AppColors.cyan,
            labelColor: AppColors.cyan,
            unselectedLabelColor: AppColors.textSecondary,
            tabs: [
              Tab(text: 'ONGOING'),
              Tab(text: 'UPCOMING'),
              Tab(text: 'RESULTED'),
            ],
          ),
        ),
        body: StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance.collection('matches').snapshots(),
          builder: (context, matchSnapshots) {
            final List<TournamentMatch> allDynamicMatches = [];

            if (matchSnapshots.hasData) {
              for (var doc in matchSnapshots.data!.docs) {
                final data = doc.data() as Map<String, dynamic>;
                if (data['isDeleted'] == true && data['status'] != 'RESULTED') continue;

                final mData = kGameModes.firstWhere(
                  (g) => g.title == data['mode'],
                  orElse: () => kGameModes.first,
                );

                allDynamicMatches.add(TournamentMatch(
                  id: doc.id,
                  title: data['title'] ?? 'New Match',
                  mode: data['mode'] ?? 'SOLO',
                  map: data['map'] ?? 'Bermuda',
                  version: 'FF MAX',
                  banner: data['banner'] ?? mData.banner,
                  prizePool: (data['prizePool'] as num?)?.toInt() ?? 100,
                  perKill: (data['perKill'] as num?)?.toInt() ?? 10,
                  entryFee: (data['entryFee'] as num?)?.toInt() ?? 20,
                  totalSlots: (data['totalSlots'] as num?)?.toInt() ?? 48,
                  filledSlots: (data['filledSlots'] as num?)?.toInt() ?? 0,
                  matchTime: data['matchTime'] ?? 'Today, 10:00 PM',
                  status: data['status'] ?? 'UPCOMING',
                  roomId: data['roomId'] ?? 'TBD',
                  roomPassword: data['roomPassword'] ?? 'TBD',
                  isRoomRevealed: data['isRoomRevealed'] ?? false,
                ));
              }
            }

            final myModeMatches = allDynamicMatches.where((m) =>
                m.banner == mode.banner ||
                m.mode.toUpperCase() == mode.title.toUpperCase() ||
                m.title.toLowerCase().contains(mode.title.toLowerCase())).toList();

            myModeMatches.sort((a, b) {
              final tA = _parseMatchTime(a.matchTime);
              final tB = _parseMatchTime(b.matchTime);
              if (tA == null) return 1;
              if (tB == null) return -1;
              return tA.compareTo(tB);
            });

            final ongoing = myModeMatches.where((m) => m.status == 'ONGOING').toList();
            final upcoming = myModeMatches.where((m) => m.status == 'UPCOMING').toList();
            final resulted = myModeMatches.where((m) => m.status == 'RESULTED').toList();

            return TabBarView(
              children: [
                _buildMatchList(ongoing, 'No ongoing matches for this mode.'),
                _buildMatchList(upcoming, 'No upcoming matches for this mode.'),
                _buildMatchList(resulted, 'No resulted matches for this mode.'),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildMatchList(List<TournamentMatch> matches, String emptyMsg) {
    if (matches.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Text(
            emptyMsg,
            style: const TextStyle(color: AppColors.textSecondary, fontSize: 14),
          ),
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: matches.length,
      itemBuilder: (ctx, i) => TournamentMatchCard(match: matches[i]),
    );
  }
}

class TournamentMatchCard extends StatelessWidget {
  final TournamentMatch match;
  const TournamentMatchCard({super.key, required this.match});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final progress = match.totalSlots > 0 ? (match.filledSlots / match.totalSlots) : 0.0;
    final isRoomVisible = _checkRoomTiming(match);
    final int slotsLeft = match.totalSlots - match.filledSlots;
    final bool isResulted = match.status == 'RESULTED';
    final bool isCancelled = match.status == 'CANCELLED';
    final bool isStarted = _isMatchStarted(match); // 🔥 Entry Lock Check

    Color progressColor = AppColors.green;
    if (progress >= 0.8) {
      progressColor = AppColors.red;
    } else if (progress >= 0.5) {
      progressColor = AppColors.orange;
    }

    return StreamBuilder<DocumentSnapshot>(
      stream: user == null ? null : FirebaseFirestore.instance.collection('users').doc(user.uid).snapshots(),
      builder: (context, userSnap) {
        bool isJoined = false;
        if (userSnap.hasData && userSnap.data!.exists) {
          isJoined = List.from((userSnap.data!.data() as Map)['joinedMatches'] ?? []).contains(match.id);
        }

        return Container(
          margin: const EdgeInsets.only(bottom: 16),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppColors.cardBorder),
          ),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => (isResulted || isCancelled)
                      ? MatchResultDetailScreen(match: match)
                      : MatchDetailScreen(match: match),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
                    child: AspectRatio(
                      aspectRatio: 16 / 9,
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          Image.asset(
                            match.banner,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                              decoration: const BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [Color(0xFF1E293B), Color(0xFF0F172A)],
                                ),
                              ),
                              child: const Center(
                                child: Icon(Icons.sports_esports, size: 40, color: AppColors.cyan),
                              ),
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [Colors.transparent, Colors.black.withOpacity(0.85)],
                              ),
                            ),
                          ),
                          Positioned(
                            top: 10,
                            left: 10,
                            child: Row(
                              children: [
                                _buildBadge(match.mode, AppColors.cyan),
                                const SizedBox(width: 6),
                                _buildBadge(match.map, AppColors.surfaceLight, textColor: AppColors.textPrimary),
                              ],
                            ),
                          ),
                          Positioned(
                            top: 10,
                            right: 10,
                            child: _buildBadge(
                              isCancelled ? 'CANCELLED' : (isResulted ? 'COMPLETED' : match.matchTime),
                              isCancelled ? AppColors.red : (isResulted ? AppColors.green : AppColors.gold),
                            ),
                          ),
                          Positioned(
                            bottom: 10,
                            left: 12,
                            right: 12,
                            child: Text(
                              match.title,
                              style: GoogleFonts.rajdhani(
                                fontSize: 16,
                                fontWeight: FontWeight.w900,
                                color: AppColors.textPrimary,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            _buildStatPill('PRIZE POOL', '${match.prizePool} Coins', AppColors.gold),
                            _buildStatPill('PER KILL', '${match.perKill} Coins', AppColors.cyan),
                            _buildStatPill('ENTRY FEE', '${match.entryFee} Coins', AppColors.green),
                          ],
                        ),
                        const SizedBox(height: 12),

                        if (!isResulted && !isCancelled) ...[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            child: LinearProgressIndicator(
                              value: progress.clamp(0.0, 1.0),
                              minHeight: 6,
                              backgroundColor: AppColors.surfaceLight,
                              valueColor: AlwaysStoppedAnimation<Color>(progressColor),
                            ),
                          ),
                          const SizedBox(height: 4),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Spots: ${match.filledSlots}/${match.totalSlots}',
                                style: const TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.textSecondary,
                                ),
                              ),
                              Text(
                                slotsLeft > 0 ? 'Only $slotsLeft Spots Left' : 'Only 0 Spots Left',
                                style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                  color: progressColor,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: AppColors.surfaceLight,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: (isJoined && isRoomVisible) ? AppColors.green : AppColors.orange,
                              ),
                            ),
                            child: Column(
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Start: ${match.matchTime}',
                                      style: const TextStyle(
                                        fontSize: 12,
                                        color: AppColors.textSecondary,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    if (match.status == 'UPCOMING') MatchCountdownTimer(match: match),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                const Divider(color: AppColors.cardBorder, height: 1),
                                const SizedBox(height: 8),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      !isJoined
                                          ? 'ID: Join to view'
                                          : (isRoomVisible ? 'ID: ${match.roomId}' : 'ID: Locked 🔒'),
                                      style: TextStyle(
                                        color: (!isJoined || !isRoomVisible) ? AppColors.orange : AppColors.cyan,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 12,
                                      ),
                                    ),
                                    Text(
                                      !isJoined
                                          ? 'Pass: Join to view'
                                          : (isRoomVisible ? 'Pass: ${match.roomPassword}' : 'Pass: Locked 🔒'),
                                      style: TextStyle(
                                        color: (!isJoined || !isRoomVisible) ? AppColors.orange : AppColors.cyan,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 12,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],

                        const SizedBox(height: 12),

                        if (isCancelled)
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: AppColors.red.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: AppColors.red),
                            ),
                            child: const Row(
                              children: [
                                Icon(Icons.cancel, color: AppColors.red, size: 20),
                                SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    'Match Cancelled. Coins Refunded.',
                                    style: TextStyle(color: AppColors.red, fontWeight: FontWeight.bold, fontSize: 13),
                                  ),
                                ),
                              ],
                            ),
                          ),

                        if (isResulted)
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: AppColors.surfaceLight,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: AppColors.gold.withOpacity(0.4)),
                            ),
                            child: Row(
                              children: [
                                const Icon(Icons.emoji_events, color: AppColors.gold, size: 20),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    'Winner: ${match.winner ?? 'Announced'}',
                                    style: const TextStyle(
                                      color: AppColors.gold,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),

                        if (!isResulted && !isCancelled)
                          Row(
                            children: [
                              Expanded(
                                child: OutlinedButton(
                                  style: OutlinedButton.styleFrom(
                                    side: const BorderSide(color: AppColors.cardBorder),
                                    foregroundColor: AppColors.textPrimary,
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                  ),
                                  onPressed: () => Navigator.push(
                                    context,
                                    MaterialPageRoute(builder: (_) => MatchDetailScreen(match: match)),
                                  ),
                                  child: const Text('MATCH RULES'),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: (slotsLeft <= 0 || isStarted) ? Colors.grey : AppColors.cyan,
                                    foregroundColor: Colors.black,
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                  ),
                                  onPressed: (slotsLeft <= 0 || isStarted)
                                      ? null
                                      : () => Navigator.push(
                                            context,
                                            MaterialPageRoute(builder: (_) => SelectPositionScreen(match: match)),
                                          ),
                                  child: Text(
                                    slotsLeft <= 0 
                                        ? 'JOINING FULL' 
                                        : (isStarted ? 'ENTRY CLOSED' : 'JOIN MATCH'),
                                    style: const TextStyle(fontWeight: FontWeight.w900),
                                  ),
                                ),
                              ),
                            ],
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildBadge(String text, Color bg, {Color textColor = Colors.black}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        text,
        style: TextStyle(color: textColor, fontWeight: FontWeight.w900, fontSize: 10),
      ),
    );
  }

  Widget _buildStatPill(String title, String val, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(fontSize: 10, color: AppColors.textMuted, fontWeight: FontWeight.bold)),
        Text(val, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: color)),
      ],
    );
  }
}

// ============================================================================
// PART 4 of 5: MATCH DETAIL, SLOT SELECTION, WALLET & ADMIN PANEL
// ============================================================================

class MatchDetailScreen extends StatelessWidget {
  final TournamentMatch match;
  const MatchDetailScreen({super.key, required this.match});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final isRoomVisible = _checkRoomTiming(match);
    final int slotsLeft = match.totalSlots - match.filledSlots;
    final bool isStarted = _isMatchStarted(match); // 🔥 Entry Lock Check

    return StreamBuilder<DocumentSnapshot>(
      stream: FirebaseFirestore.instance.collection('matches').doc(match.id).snapshots(),
      builder: (context, matchSnap) {
        final currentMatch = (matchSnap.hasData && matchSnap.data!.exists)
            ? applyMatchOverrides(match, matchSnap.data!.data() as Map<String, dynamic>)
            : match;

        return Scaffold(
          backgroundColor: AppColors.background,
          appBar: AppBar(title: Text(currentMatch.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)), backgroundColor: AppColors.surface),
          body: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                AspectRatio(
                  aspectRatio: 16 / 9,
                  child: Stack(fit: StackFit.expand, children: [
                    Image.asset(currentMatch.banner, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: AppColors.surfaceLight)),
                    Container(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Colors.black.withOpacity(0.8)]))),
                    Positioned(bottom: 12, left: 16, child: Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: AppColors.red, borderRadius: BorderRadius.circular(6)), child: Text('STARTS: ${currentMatch.matchTime}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 11)))),
                  ]),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(currentMatch.title, style: GoogleFonts.orbitron(fontSize: 18, fontWeight: FontWeight.w900, color: AppColors.cyan)),
                      const SizedBox(height: 6),
                      Text('Map: ${currentMatch.map} • Mode: ${currentMatch.mode} • Version: ${currentMatch.version}', style: const TextStyle(color: AppColors.textSecondary)),
                      const SizedBox(height: 16),
                      Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.cardBorder)), child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [_buildCol('Prize Pool', '${currentMatch.prizePool} Coins', AppColors.gold), _buildCol('Per Kill', '${currentMatch.perKill} Coins', AppColors.cyan), _buildCol('Entry Fee', '${currentMatch.entryFee} Coins', AppColors.green)])),
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.cardBorder)),
                        child: StreamBuilder<DocumentSnapshot>(
                          stream: user == null ? null : FirebaseFirestore.instance.collection('users').doc(user.uid).snapshots(),
                          builder: (ctx, snap) {
                            bool isJoined = false;
                            if (snap.hasData && snap.data!.exists) { isJoined = List.from((snap.data!.data() as Map)['joinedMatches'] ?? []).contains(currentMatch.id); }
                            bool showCredentials = isJoined && isRoomVisible;

                            return Column(
                              children: [
                                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Match Start: ${currentMatch.matchTime}', style: const TextStyle(fontWeight: FontWeight.bold)), if (currentMatch.status == 'UPCOMING') MatchCountdownTimer(match: currentMatch)]),
                                const Divider(color: AppColors.cardBorder),
                                Row(children: [Icon(showCredentials ? Icons.vpn_key : Icons.lock, color: showCredentials ? AppColors.cyan : AppColors.orange, size: 20), const SizedBox(width: 8), Text(showCredentials ? 'CUSTOM ROOM CREDENTIALS' : 'ROOM DETAILS LOCKED', style: TextStyle(color: showCredentials ? AppColors.cyan : AppColors.orange, fontWeight: FontWeight.w900, fontSize: 13))]),
                                const SizedBox(height: 10),
                                if (!isJoined) const Text('You have not joined this match yet. Join to view room details.', style: TextStyle(color: AppColors.orange, fontSize: 12))
                                else if (!isRoomVisible) const Text('Room ID & Password will be unlocked 5 minutes before match start time.', style: TextStyle(color: AppColors.orange, fontSize: 12))
                                else Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                                  Text('ID: ${currentMatch.roomId}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.cyan)),
                                  Text('Pass: ${currentMatch.roomPassword}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.cyan)),
                                  IconButton(icon: const Icon(Icons.copy, color: AppColors.cyan), onPressed: () { Clipboard.setData(ClipboardData(text: 'Room ID: ${currentMatch.roomId} Password: ${currentMatch.roomPassword}')); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Copied!'))); }),
                                ]),
                              ],
                            );
                          },
                        ),
                      ),
                      const SizedBox(height: 16),
                      SizedBox(width: double.infinity, height: 46, child: OutlinedButton.icon(style: OutlinedButton.styleFrom(side: const BorderSide(color: AppColors.cyan), foregroundColor: AppColors.cyan, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))), icon: const Icon(Icons.group, size: 20), label: const Text('VIEW ALL JOININGS / PARTICIPANTS', style: TextStyle(fontWeight: FontWeight.bold)), onPressed: () => _showAllJoinings(context, currentMatch))),
                      const SizedBox(height: 20),
                      const Text('ABOUT THIS MATCH & OFFICIAL RULES', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 1.2, color: AppColors.cyan)),
                      const SizedBox(height: 12),
                      _buildRuleCard('ELIGIBILITY & REQUIREMENTS', Icons.verified_user, AppColors.cyan, ['• 5G+ or stable 4G network connection recommended.', '• Level Requirement: Only players with Level 40+ IDs are eligible.', '• Device Requirements: Mobile only. Emulators are strictly prohibited.']),
                      const SizedBox(height: 12),
                      _buildRuleCard('PROHIBITED BEHAVIOR', Icons.gavel, AppColors.red, ['• Using Unauthorized Tools (Aimbots, no-recoil, scripts).', '• Teaming Up with Opponents in Solo matches.', '• Multiple accounts on one device are prohibited.']),
                      const SizedBox(height: 12),
                      _buildRuleCard('MANDATORY SCREEN RECORDING', Icons.videocam, AppColors.gold, ['• Mandatory Gameplay Recording from lobby until Booyah.', '• Submit proof within 15 mins if asked by admin.']),
                      const SizedBox(height: 12),
                      _buildRuleCard('RESULTS & POLICIES', Icons.policy, AppColors.green, ['• Result generated within 1 to 1.5 hours after match.', '• Missed matches are non-refundable.', '• Server crashes are 100% refunded.']),
                      const SizedBox(height: 24),
                      
                      StreamBuilder<DocumentSnapshot>(
                        stream: user == null ? null : FirebaseFirestore.instance.collection('users').doc(user.uid).snapshots(),
                        builder: (ctx, snapshot) {
                          bool isJoined = false;
                          if (snapshot.hasData && snapshot.data!.exists) {
                            final data = snapshot.data!.data() as Map<String, dynamic>;
                            final list = List<String>.from(data['joinedMatches'] ?? []);
                            isJoined = list.contains(currentMatch.id);
                          }
                          if (currentMatch.status == 'RESULTED' || currentMatch.status == 'CANCELLED') {
                            return Container(width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 14), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.gold)), child: const Center(child: Text('MATCH COMPLETED / CANCELLED', style: TextStyle(color: AppColors.gold, fontWeight: FontWeight.bold, fontSize: 14))));
                          }
                          if (isJoined) return Container(width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 14), decoration: BoxDecoration(color: AppColors.green.withOpacity(0.15), borderRadius: BorderRadius.circular(10)), child: const Center(child: Text('ALREADY JOINED • READY FOR BATTLE', style: TextStyle(color: AppColors.green, fontWeight: FontWeight.bold, fontSize: 14))));
                          
                          // 🔥 ENTRY LOCK BUTTON
                          return SizedBox(
                            width: double.infinity, height: 50,
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(backgroundColor: (slotsLeft <= 0 || isStarted) ? Colors.grey : AppColors.cyan, foregroundColor: Colors.black, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                              onPressed: (slotsLeft <= 0 || isStarted) ? null : () => Navigator.push(context, MaterialPageRoute(builder: (_) => SelectPositionScreen(match: currentMatch))),
                              child: Text(slotsLeft <= 0 ? 'JOINING FULL' : (isStarted ? 'ENTRY CLOSED' : 'JOIN TOURNAMENT (${currentMatch.entryFee} Coins)'), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15, letterSpacing: 1)),
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildCol(String title, String val, Color c) { return Column(children: [Text(title, style: const TextStyle(color: AppColors.textMuted, fontSize: 11)), const SizedBox(height: 4), Text(val, style: TextStyle(color: c, fontSize: 16, fontWeight: FontWeight.w900))]); }

  Widget _buildRuleCard(String title, IconData icon, Color color, List<String> rules) {
    return Container(
      width: double.infinity, padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: color.withOpacity(0.5)), boxShadow: [BoxShadow(color: color.withOpacity(0.08), blurRadius: 10, spreadRadius: 1)]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Icon(icon, color: color, size: 20), const SizedBox(width: 8), Text(title, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 1))]),
        const SizedBox(height: 10),
        ...rules.map((r) => Padding(padding: const EdgeInsets.only(bottom: 6), child: Text(r, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12, height: 1.45)))),
      ]),
    );
  }
}

void _showAllJoinings(BuildContext context, TournamentMatch match) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: AppColors.surface,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (ctx) {
      return Container(
        height: MediaQuery.of(ctx).size.height * 0.75,
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'ALL PARTICIPANTS',
                      style: GoogleFonts.orbitron(
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                        color: AppColors.cyan,
                      ),
                    ),
                    Text(
                      '${match.title}',
                      style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                    ),
                  ],
                ),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.pop(ctx),
                ),
              ],
            ),
            const Divider(color: AppColors.cardBorder),
            const SizedBox(height: 8),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('match_entries')
                    .where('matchId', isEqualTo: match.id)
                    .snapshots(),
                builder: (context, snap) {
                  if (!snap.hasData) {
                    return const Center(child: CircularProgressIndicator(color: AppColors.cyan));
                  }
                  if (snap.data!.docs.isEmpty) {
                    return const Center(
                      child: Text(
                        'No players joined yet.',
                        style: TextStyle(color: AppColors.textSecondary),
                      ),
                    );
                  }
                  
                  final entries = snap.data!.docs
                      .map((d) => d.data() as Map<String, dynamic>)
                      .toList()
                    ..sort((a, b) => ((a['slot'] ?? 0) as int).compareTo((b['slot'] ?? 0) as int));

                  return ListView.builder(
                    itemCount: entries.length,
                    itemBuilder: (ctx, i) {
                      return Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: AppColors.surfaceLight,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: AppColors.cardBorder),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: AppColors.surface,
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text(
                                    'Slot ${entries[i]['slot']}',
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 11,
                                      color: AppColors.gold,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      entries[i]['ign'] ?? 'Unknown',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 13,
                                        color: AppColors.textPrimary,
                                      ),
                                    ),
                                    const Text(
                                      'Verified Player',
                                      style: TextStyle(fontSize: 10, color: AppColors.textSecondary),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: AppColors.green.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: const Text(
                                'CONFIRMED',
                                style: TextStyle(
                                  color: AppColors.green,
                                  fontWeight: FontWeight.w900,
                                  fontSize: 11,
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      );
    },
  );
}

class SelectPositionScreen extends StatefulWidget {
  final TournamentMatch match;
  const SelectPositionScreen({super.key, required this.match});
  @override
  State<SelectPositionScreen> createState() => _SelectPositionScreenState();
}

class _SelectPositionScreenState extends State<SelectPositionScreen> {
  bool _acceptRules = false;

  Future<void> _scheduleMatchNotifications(TournamentMatch match) async {
    try {
      final matchTime = _parseMatchTime(match.matchTime);
      if (matchTime == null) return;
      final now = DateTime.now();
      if (matchTime.isBefore(now)) return;
      
      final tenMinBefore = matchTime.subtract(const Duration(minutes: 10));
      final fiveMinBefore = matchTime.subtract(const Duration(minutes: 5));

      if (tenMinBefore.isAfter(now)) {
        await flutterLocalNotificationsPlugin.zonedSchedule(
          match.id.hashCode + 1,
          '🔥 Match Starting Soon!',
          '${match.title} starts in 10 minutes. Get ready!',
          tz.TZDateTime.from(tenMinBefore, tz.local),
          const NotificationDetails(
            android: AndroidNotificationDetails(
              'high_importance_channel',
              'High Importance Notifications',
              importance: Importance.max,
              priority: Priority.high,
            ),
          ),
          androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
          uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        );
      }
      if (fiveMinBefore.isAfter(now)) {
        await flutterLocalNotificationsPlugin.zonedSchedule(
          match.id.hashCode + 2,
          '🔑 Room Details Available!',
          'Room ID: ${match.roomId} | Pass: ${match.roomPassword}\nJoin now!',
          tz.TZDateTime.from(fiveMinBefore, tz.local),
          const NotificationDetails(
            android: AndroidNotificationDetails(
              'high_importance_channel',
              'High Importance Notifications',
              importance: Importance.max,
              priority: Priority.high,
            ),
          ),
          androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
          uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        );
      }
    } catch (e) {
      debugPrint("Notification Schedule Error: $e");
    }
  }

  void _joinPositionDialog(int slotNumber, String positionLabel) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      showCustomDialog(
        context: context,
        title: 'LOGIN REQUIRED',
        message: 'Please login or create a Battle Arena account to join matches.',
        icon: Icons.lock_clock,
        color: AppColors.cyan,
      );
      return;
    }

    final ignCtrl = TextEditingController();
    final uidCtrl = TextEditingController();
    _acceptRules = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setModalState) {
            return SingleChildScrollView(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 20,
                bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'LOCK POSITION',
                            style: GoogleFonts.orbitron(
                              fontSize: 16,
                              fontWeight: FontWeight.w900,
                              color: AppColors.cyan,
                            ),
                          ),
                          Text(
                            positionLabel,
                            style: const TextStyle(
                              fontSize: 13,
                              color: AppColors.gold,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () => Navigator.pop(ctx),
                      ),
                    ],
                  ),
                  const Divider(color: AppColors.cardBorder),
                  const SizedBox(height: 10),
                  Text(
                    'Tournament: ${widget.match.title}',
                    style: const TextStyle(
                      fontSize: 12,
                      color: AppColors.textSecondary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: ignCtrl,
                    style: const TextStyle(color: AppColors.textPrimary),
                    decoration: InputDecoration(
                      labelText: 'In-Game Nickname (Exact IGN)',
                      labelStyle: const TextStyle(color: AppColors.textMuted),
                      prefixIcon: const Icon(Icons.sports_esports, color: AppColors.cyan),
                      filled: true,
                      fillColor: AppColors.surfaceLight,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: uidCtrl,
                    keyboardType: TextInputType.number,
                    style: const TextStyle(color: AppColors.textPrimary),
                    decoration: InputDecoration(
                      labelText: 'Game UID (e.g. 192830491)',
                      labelStyle: const TextStyle(color: AppColors.textMuted),
                      prefixIcon: const Icon(Icons.fingerprint, color: AppColors.gold),
                      filled: true,
                      fillColor: AppColors.surfaceLight,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.surfaceLight,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppColors.cardBorder),
                    ),
                    child: Row(
                      children: [
                        Checkbox(
                          value: _acceptRules,
                          onChanged: (val) => setModalState(() => _acceptRules = val!),
                          activeColor: AppColors.green,
                        ),
                        const Expanded(
                          child: Text(
                            'I agree to record my screen and follow all Anti-Cheat & Fair Play rules.',
                            style: TextStyle(
                              fontSize: 11,
                              color: AppColors.textSecondary,
                              height: 1.3,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: AppColors.surfaceLight,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: AppColors.cardBorder),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Entry Fee to Deduct:',
                          style: TextStyle(color: AppColors.textSecondary),
                        ),
                        Text(
                          '${widget.match.entryFee} Coins',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            color: AppColors.gold,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  SizedBox(
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.cyan,
                        foregroundColor: Colors.black,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                      onPressed: () async {
                        final ign = ignCtrl.text.trim();
                        final uidVal = uidCtrl.text.trim();
                        
                        if (!_acceptRules) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              backgroundColor: AppColors.red,
                              content: Text('You must accept the Anti-Cheat rules to join.'),
                            ),
                          );
                          return;
                        }
                        if (ign.isEmpty || uidVal.isEmpty) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Please enter both IGN and Game UID')),
                          );
                          return;
                        }

                        try {
                          final userRef = FirebaseFirestore.instance.collection('users').doc(user.uid);
                          final userDoc = await userRef.get();

                          if (!userDoc.exists) {
                            await userRef.set({
                              'uid': user.uid,
                              'email': user.email,
                              'depositBalance': 0.0,
                              'winningBalance': 0.0,
                              'systemBalance': 0.0,
                              'joinedMatches': []
                            }, SetOptions(merge: true));
                            throw Exception('Profile was just initialized. Please try again.');
                          }

                          final data = userDoc.data()!;
                          double deposit = ((data['depositBalance'] ?? 0) as num).toDouble();
                          double winning = ((data['winningBalance'] ?? 0) as num).toDouble();
                          double system = ((data['systemBalance'] ?? 0) as num).toDouble();
                          double total = deposit + winning + system;

                          if (total < widget.match.entryFee) {
                            Navigator.pop(ctx);
                            showCustomDialog(
                              context: context,
                              title: 'INSUFFICIENT COINS',
                              message: 'You need ${(widget.match.entryFee - total).toStringAsFixed(0)} more Coins. Current Balance: ${total.toStringAsFixed(0)} Coins',
                              icon: Icons.account_balance_wallet,
                              color: AppColors.red,
                              btnText: 'ADD COINS',
                              onBtnPressed: () {
                                Navigator.pop(context);
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (_) => const WalletScreen()),
                                );
                              },
                            );
                            return;
                          }

                          double remaining = widget.match.entryFee.toDouble();
                          
                          if (system >= remaining) {
                            system -= remaining;
                            remaining = 0;
                          } else {
                            remaining -= system;
                            system = 0;
                          }
                          
                          if (remaining > 0) {
                            if (deposit >= remaining) {
                              deposit -= remaining;
                              remaining = 0;
                            } else {
                              remaining -= deposit;
                              deposit = 0;
                            }
                            
                            if (remaining > 0) {
                              winning -= remaining;
                            }
                          }

                          final int updatedMatches = ((data['totalMatches'] ?? 0) as num).toInt() + 1;
                          List<dynamic> joined = data['joinedMatches'] ?? [];
                          if (!joined.contains(widget.match.id)) joined.add(widget.match.id);

                          await userRef.update({
                            'depositBalance': deposit,
                            'winningBalance': winning,
                            'systemBalance': system,
                            'totalBalance': deposit + winning + system,
                            'totalMatches': updatedMatches,
                            'joinedMatches': joined,
                          });

                          await FirebaseFirestore.instance.collection('passbook').add({
                            'userId': user.uid,
                            'type': 'MATCH_ENTRY',
                            'amount': widget.match.entryFee,
                            'title': 'Entry Fee: ${widget.match.title}',
                            'createdAt': FieldValue.serverTimestamp(),
                          });

                          await FirebaseFirestore.instance.collection('match_entries').add({
                            'matchId': widget.match.id,
                            'userId': user.uid,
                            'userEmail': user.email,
                            'ign': ign,
                            'gameUid': uidVal,
                            'slot': slotNumber,
                            'position': positionLabel,
                            'joinedAt': FieldValue.serverTimestamp(),
                            'result': 'PENDING',
                            'kills': 0,
                            'rank': 0,
                            'prizeWon': 0,
                          });
                          
                          await FirebaseFirestore.instance.collection('matches').doc(widget.match.id).set({
                            'filledSlots': FieldValue.increment(1)
                          }, SetOptions(merge: true));

                          MatchSlotManager.bookSlot(widget.match, slotNumber, ign);
                          await _scheduleMatchNotifications(widget.match);

                          if (mounted) setState(() {});
                          if (mounted) Navigator.pop(ctx);
                          if (mounted) {
                            showCustomDialog(
                              context: context,
                              title: 'POSITION CONFIRMED! ⚔️',
                              message: 'Slot $positionLabel locked for $ign. Fee ${widget.match.entryFee} Coins deducted.',
                              icon: Icons.check_circle,
                              color: AppColors.green,
                            );
                          }
                        } catch (e) {
                          if (mounted) {
                            showCustomDialog(
                              context: context,
                              title: 'JOIN FAILED',
                              message: e.toString().replaceAll('Exception: ', ''),
                              icon: Icons.error,
                              color: AppColors.red,
                            );
                          }
                        }
                      },
                      child: const Text(
                        'CONFIRM & LOCK POSITION',
                        style: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 15,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final slotsMap = MatchSlotManager.getSlotsForMatch(widget.match);
    final isBermudaSquad = widget.match.banner.contains('banner_16') ||
        widget.match.title.toLowerCase().contains('bermuda squad') ||
        widget.match.mode == 'BERMUDA SQUAD 4V4';
    final isDuo = widget.match.banner.contains('banner_05') ||
        widget.match.title.toLowerCase().contains('duo') ||
        widget.match.mode.contains('DUO');
    final is4v4CS = widget.match.totalSlots == 8;
    final is2v2 = widget.match.totalSlots == 4;
    final is1v1 = widget.match.totalSlots == 2;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'SELECT MATCH POSITION',
              style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15, letterSpacing: 1.1),
            ),
            Text(
              '${widget.match.title} • ${widget.match.entryFee} Coins Fee',
              style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
            ),
          ],
        ),
        backgroundColor: AppColors.surface,
        actions: [
          StreamBuilder<DocumentSnapshot>(
            stream: user == null
                ? null
                : FirebaseFirestore.instance.collection('users').doc(user.uid).snapshots(),
            builder: (ctx, snap) {
              double total = 0.0;
              if (snap.hasData && snap.data!.exists) {
                final d = snap.data!.data() as Map<String, dynamic>;
                total = (((d['depositBalance'] ?? 0) as num) +
                        ((d['winningBalance'] ?? 0) as num) +
                        ((d['systemBalance'] ?? 0) as num))
                    .toDouble();
              }
              return Container(
                margin: const EdgeInsets.only(right: 14, top: 10, bottom: 10),
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.surfaceLight,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppColors.gold.withOpacity(0.6)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.monetization_on, color: AppColors.gold, size: 16),
                    const SizedBox(width: 4),
                    Text(
                      '${total.toStringAsFixed(0)} C',
                      style: const TextStyle(
                        fontWeight: FontWeight.w900,
                        color: AppColors.gold,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF1E293B), Color(0xFF0F172A)],
                ),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.cyan.withOpacity(0.5)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'AVAILABLE POSITIONS',
                        style: GoogleFonts.orbitron(
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          color: AppColors.cyan,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Filled: ${widget.match.filledSlots}/${widget.match.totalSlots} Slots',
                        style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      _buildLegendDot(AppColors.green, 'CONFIRMED'),
                      const SizedBox(width: 10),
                      _buildLegendDot(AppColors.cyan, 'EMPTY'),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            if (isBermudaSquad)
              ...List.generate(12, (squadIdx) {
                final squadNum = squadIdx + 1;
                final startSlot = squadIdx * 4 + 1;
                int squadBookedCount = 0;
                for (int p = 0; p < 4; p++) {
                  if (slotsMap.containsKey(startSlot + p)) squadBookedCount++;
                }
                final bool isSquadFull = squadBookedCount == 4;
                return Container(
                  margin: const EdgeInsets.only(bottom: 14),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: isSquadFull
                          ? AppColors.gold.withOpacity(0.5)
                          : AppColors.cardBorder,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                decoration: BoxDecoration(
                                  color: AppColors.cyan.withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(6),
                                  border: Border.all(color: AppColors.cyan),
                                ),
                                child: Text(
                                  'TEAM $squadNum',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w900,
                                    fontSize: 12,
                                    color: AppColors.cyan,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              const Text(
                                'SQUAD',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 12,
                                  color: AppColors.textSecondary,
                                ),
                              ),
                            ],
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: isSquadFull
                                  ? AppColors.gold.withOpacity(0.2)
                                  : AppColors.surfaceLight,
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              isSquadFull ? 'FULL (4/4)' : '$squadBookedCount/4 FILLED',
                              style: TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 11,
                                color: isSquadFull
                                    ? AppColors.gold
                                    : AppColors.textSecondary,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const Divider(color: AppColors.cardBorder, height: 18),
                      Column(
                        children: List.generate(4, (pIdx) {
                          final slotNum = startSlot + pIdx;
                          final playerNum = pIdx + 1;
                          final isBooked = slotsMap.containsKey(slotNum);
                          final ign = slotsMap[slotNum];
                          return _buildSlotRow(
                            slotNum,
                            'Team $squadNum • Player $playerNum',
                            isBooked,
                            ign,
                          );
                        }),
                      ),
                    ],
                  ),
                );
              })
            else if (isDuo)
              ...List.generate(24, (teamIdx) {
                final teamNum = teamIdx + 1;
                final startSlot = teamIdx * 2 + 1;
                int teamBookedCount = 0;
                for (int p = 0; p < 2; p++) {
                  if (slotsMap.containsKey(startSlot + p)) teamBookedCount++;
                }
                final bool isTeamFull = teamBookedCount == 2;
                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: isTeamFull
                          ? AppColors.gold.withOpacity(0.5)
                          : AppColors.cardBorder,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'TEAM $teamNum (DUO)',
                            style: const TextStyle(
                              fontWeight: FontWeight.w900,
                              fontSize: 13,
                              color: AppColors.cyan,
                            ),
                          ),
                          Text(
                            isTeamFull
                                ? 'TEAM FULL'
                                : '$teamBookedCount/2 FILLED',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 11,
                              color: isTeamFull
                                  ? AppColors.gold
                                  : AppColors.textSecondary,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      _buildSlotRow(
                        startSlot,
                        'Team $teamNum • Player 1',
                        slotsMap.containsKey(startSlot),
                        slotsMap[startSlot],
                      ),
                      _buildSlotRow(
                        startSlot + 1,
                        'Team $teamNum • Player 2',
                        slotsMap.containsKey(startSlot + 1),
                        slotsMap[startSlot + 1],
                      ),
                    ],
                  ),
                );
              })
            else if (is4v4CS) ...[
              _buildTeamBlock('TEAM ALPHA (4 PLAYERS)', 1, 4, slotsMap),
              const SizedBox(height: 14),
              _buildTeamBlock('TEAM BRAVO (4 PLAYERS)', 5, 8, slotsMap),
            ] else if (is2v2) ...[
              _buildTeamBlock('TEAM ALPHA (2 PLAYERS)', 1, 2, slotsMap),
              const SizedBox(height: 14),
              _buildTeamBlock('TEAM BRAVO (2 PLAYERS)', 3, 4, slotsMap),
            ] else if (is1v1) ...[
              _buildSlotRow(
                1,
                'PLAYER 1',
                slotsMap.containsKey(1),
                slotsMap[1],
              ),
              const SizedBox(height: 10),
              _buildSlotRow(
                2,
                'PLAYER 2',
                slotsMap.containsKey(2),
                slotsMap[2],
              ),
            ] else
              Column(
                children: List.generate(48, (i) {
                  final slotNum = i + 1;
                  final isBooked = slotsMap.containsKey(slotNum);
                  final ign = slotsMap[slotNum];
                  return _buildSlotRow(slotNum, 'Slot #$slotNum', isBooked, ign);
                }),
              ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _buildTeamBlock(String teamTitle, int startSlot, int endSlot, Map<int, String> slotsMap) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            teamTitle,
            style: const TextStyle(
              fontWeight: FontWeight.w900,
              fontSize: 13,
              color: AppColors.cyan,
            ),
          ),
          const Divider(color: AppColors.cardBorder, height: 18),
          ...List.generate(endSlot - startSlot + 1, (idx) {
            final slotNum = startSlot + idx;
            final isBooked = slotsMap.containsKey(slotNum);
            final ign = slotsMap[slotNum];
            return _buildSlotRow(
              slotNum,
              'Player ${idx + 1} (Slot #$slotNum)',
              isBooked,
              ign,
            );
          }),
        ],
      ),
    );
  }

  Widget _buildSlotRow(int slotNum, String label, bool isBooked, String? ign) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: isBooked ? AppColors.surfaceLight : AppColors.surface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: isBooked
              ? AppColors.green.withOpacity(0.5)
              : AppColors.cyan.withOpacity(0.3),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Icon(
                isBooked ? Icons.check_circle : Icons.radio_button_unchecked,
                color: isBooked ? AppColors.green : AppColors.cyan,
                size: 18,
              ),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  if (isBooked && ign != null)
                    Text(
                      'IGN: $ign',
                      style: const TextStyle(
                        fontSize: 11,
                        color: AppColors.green,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                ],
              ),
            ],
          ),
          if (isBooked)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: AppColors.green.withOpacity(0.18),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: AppColors.green),
              ),
              child: const Row(
                children: [
                  Icon(Icons.lock, size: 12, color: AppColors.green),
                  SizedBox(width: 4),
                  Text(
                    'CONFIRMED',
                    style: TextStyle(
                      color: AppColors.green,
                      fontWeight: FontWeight.w900,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            )
          else
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.cyan,
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                minimumSize: Size.zero,
                tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
              ),
              onPressed: () => _joinPositionDialog(slotNum, label),
              child: const Text(
                'EMPTY • JOIN',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 11),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildLegendDot(Color c, String text) {
    return Row(
      children: [
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(color: c, shape: BoxShape.circle),
        ),
        const SizedBox(width: 5),
        Text(
          text,
          style: TextStyle(color: c, fontSize: 11, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}
// ============================================================================
// PART 5 of 5: WALLET, ADMIN PANEL, PROFILE, HISTORY & STATIC PAGES
// ============================================================================

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});
  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  int _selectedAmount = 25;
  final _customAmountCtrl = TextEditingController(text: '25');
  final _utrCtrl = TextEditingController();
  final _withdrawUpiCtrl = TextEditingController();
  final _withdrawAmountCtrl = TextEditingController();
  bool _isSubmitting = false;
  Uint8List? _screenshotBytes;
  String? _screenshotBase64;
  String? _screenshotName;
  final List<int> _presets = [11, 25, 50, 100, 200, 500, 1000];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _customAmountCtrl.dispose();
    _utrCtrl.dispose();
    _withdrawUpiCtrl.dispose();
    _withdrawAmountCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickScreenshot() async {
    try {
      final picker = ImagePicker();
      final XFile? image = await picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 25,
        maxWidth: 720,
      );
      if (image != null) {
        final bytes = await image.readAsBytes();
        setState(() {
          _screenshotBytes = bytes;
          _screenshotBase64 = base64Encode(bytes);
          _screenshotName = image.name;
        });
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              backgroundColor: AppColors.green,
              content: Text('✅ Gallery photo selected: ${image.name}'),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: AppColors.red,
            content: Text('Gallery open error: $e'),
          ),
        );
      }
    }
  }

  void _downloadQrCode(String upiPayload, int amount) {
    final qrUrl =
        'https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${Uri.encodeComponent(upiPayload)}';
    showCustomDialog(
      context: context,
      title: 'SAVE QR CODE',
      message:
          'Click below to view the QR Code. You can long-press the image to save it to your gallery.',
      icon: Icons.qr_code_2,
      color: AppColors.cyan,
      btnText: 'OPEN QR IMAGE',
      onBtnPressed: () {
        Navigator.pop(context);
        openExternalUrl(context, qrUrl);
      },
    );
  }

  Future<void> _submitDeposit() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    final utr = _utrCtrl.text.trim();
    final amount = int.tryParse(_customAmountCtrl.text.trim()) ?? _selectedAmount;

    if (amount < 11 || amount > 1000) {
      showCustomDialog(
        context: context,
        title: 'INVALID AMOUNT',
        message: 'Deposit amount must be between 11 and 1,000 Coins only.',
        icon: Icons.error_outline,
        color: AppColors.red,
      );
      return;
    }
    if (utr.length < 10) {
      showCustomDialog(
        context: context,
        title: 'INVALID UTR NUMBER',
        message: 'Please enter valid 12-digit UPI Ref / UTR Number.',
        icon: Icons.receipt_long,
        color: AppColors.orange,
      );
      return;
    }
    if (_screenshotBase64 == null) {
      showCustomDialog(
        context: context,
        title: 'PROOF REQUIRED',
        message: 'Please attach your payment screenshot.',
        icon: Icons.add_photo_alternate,
        color: AppColors.orange,
      );
      return;
    }

    setState(() => _isSubmitting = true);

    try {
      final duplicateCheck = await FirebaseFirestore.instance
          .collection('deposit_requests')
          .where('userId', isEqualTo: user.uid)
          .where('status', isEqualTo: 'PENDING')
          .get();

      bool isDuplicate = false;
      for (var doc in duplicateCheck.docs) {
        if (doc['utr'] == utr) {
          isDuplicate = true;
          break;
        }
      }

      if (isDuplicate) {
        setState(() => _isSubmitting = false);
        showCustomDialog(
          context: context,
          title: 'DUPLICATE REQUEST',
          message:
              'This UTR number has already been submitted and is pending approval. Please wait or use a different transaction.',
          icon: Icons.warning_amber,
          color: AppColors.red,
        );
        return;
      }

      final twentyFourHoursAgo =
          DateTime.now().subtract(const Duration(hours: 24));
      final recentDeposits = await FirebaseFirestore.instance
          .collection('deposit_requests')
          .where('userId', isEqualTo: user.uid)
          .where('createdAt', isGreaterThan: Timestamp.fromDate(twentyFourHoursAgo))
          .get();

      if (recentDeposits.docs.length >= 8) {
        setState(() => _isSubmitting = false);
        showCustomDialog(
          context: context,
          title: 'DAILY LIMIT REACHED',
          message:
              'You have reached the maximum limit of 8 deposit requests in the last 24 hours. Please try again later.',
          icon: Icons.block,
          color: AppColors.red,
        );
        return;
      }

      String userName = 'Warrior';
      String userPhone = '';
      try {
        final userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .get();
        if (userDoc.exists) {
          final d = userDoc.data()!;
          userName = d['name'] ?? 'Warrior';
          userPhone = d['phone'] ?? '';
        }
      } catch (_) {}

      await FirebaseFirestore.instance.collection('deposit_requests').add({
        'userId': user.uid,
        'userName': userName,
        'userPhone': userPhone,
        'userEmail': user.email ?? '',
        'amount': amount,
        'utr': utr,
        'screenshotBase64': _screenshotBase64 ?? '',
        'hasScreenshot': true,
        'screenshotName': _screenshotName ?? 'Payment_Proof.jpg',
        'status': 'PENDING',
        'timestamp': FieldValue.serverTimestamp(),
        'createdAt': FieldValue.serverTimestamp(),
      }).timeout(const Duration(seconds: 10));

      await FirebaseFirestore.instance.collection('deposits').add({
        'userId': user.uid,
        'userEmail': user.email,
        'amount': amount,
        'utr': utr,
        'status': 'PENDING',
        'createdAt': FieldValue.serverTimestamp(),
      }).timeout(const Duration(seconds: 10));

      _utrCtrl.clear();
      setState(() {
        _screenshotBytes = null;
        _screenshotBase64 = null;
        _screenshotName = null;
      });

      if (mounted) {
        showCustomDialog(
          context: context,
          title: 'DEPOSIT DISPATCHED! 🚀',
          message:
              'Your deposit request of $amount Coins with UTR: $utr has been sent to Admin.',
          icon: Icons.verified,
          color: AppColors.green,
          btnText: 'OK',
        );
      }
    } catch (e) {
      if (mounted) {
        showCustomDialog(
          context: context,
          title: 'SUBMISSION FAILED',
          message: 'Network issue: $e',
          icon: Icons.error,
          color: AppColors.red,
        );
      }
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  Future<void> _submitWithdrawal(double winningBalance) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    final upi = _withdrawUpiCtrl.text.trim();
    final amount = int.tryParse(_withdrawAmountCtrl.text.trim()) ?? 0;

    if (amount < 11 || amount > 1000) {
      showCustomDialog(
        context: context,
        title: 'INVALID AMOUNT',
        message: 'Withdrawal amount must be between 11 and 1,000 Coins only.',
        icon: Icons.error_outline,
        color: AppColors.red,
      );
      return;
    }
    if (amount > winningBalance) {
      showCustomDialog(
        context: context,
        title: 'INSUFFICIENT WINNINGS',
        message:
            'You can only withdraw from your Winning Coins. Current: ${winningBalance.toStringAsFixed(0)} Coins',
        icon: Icons.account_balance_wallet,
        color: AppColors.orange,
      );
      return;
    }
    if (upi.isEmpty) {
      showCustomDialog(
        context: context,
        title: 'UPI REQUIRED',
        message: 'Please enter your registered UPI ID.',
        icon: Icons.phone_android,
        color: AppColors.orange,
      );
      return;
    }

    setState(() => _isSubmitting = true);
    try {
      final twentyFourHoursAgo =
          DateTime.now().subtract(const Duration(hours: 24));
      final recentWithdrawals = await FirebaseFirestore.instance
          .collection('withdrawals')
          .where('userId', isEqualTo: user.uid)
          .where('createdAt', isGreaterThan: Timestamp.fromDate(twentyFourHoursAgo))
          .get();

      if (recentWithdrawals.docs.length >= 5) {
        setState(() => _isSubmitting = false);
        showCustomDialog(
          context: context,
          title: 'DAILY LIMIT REACHED',
          message:
              'You have reached the maximum limit of 5 withdrawal requests in the last 24 hours. Please try again later.',
          icon: Icons.block,
          color: AppColors.red,
        );
        return;
      }

      await FirebaseFirestore.instance.collection('withdrawals').add({
        'userId': user.uid,
        'userEmail': user.email,
        'amount': amount,
        'upiId': upi,
        'status': 'PENDING',
        'createdAt': FieldValue.serverTimestamp(),
      });

      await FirebaseFirestore.instance.collection('users').doc(user.uid).update({
        'winningBalance': winningBalance - amount,
      });

      await FirebaseFirestore.instance.collection('passbook').add({
        'userId': user.uid,
        'type': 'WITHDRAWAL_REQUEST',
        'amount': amount,
        'title': 'Payout Request to $upi',
        'createdAt': FieldValue.serverTimestamp(),
      });

      _withdrawAmountCtrl.clear();
      _withdrawUpiCtrl.clear();

      if (mounted) {
        showCustomDialog(
          context: context,
          title: 'WITHDRAWAL INITIATED 💸',
          message: '$amount Coins payout request submitted to $upi.',
          icon: Icons.account_balance,
          color: AppColors.green,
        );
      }
    } catch (e) {
      if (mounted) {
        showCustomDialog(
          context: context,
          title: 'WITHDRAWAL ERROR',
          message: '$e',
          icon: Icons.error,
          color: AppColors.red,
        );
      }
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text(
          'MY WALLET',
          style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2),
        ),
        backgroundColor: AppColors.surface,
        actions: [
          IconButton(
            icon: const Icon(Icons.history, color: AppColors.cyan),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const PassbookScreen()),
            ),
            tooltip: 'Coin History',
          ),
        ],
      ),
      body: StreamBuilder<DocumentSnapshot>(
        stream: user == null
            ? null
            : FirebaseFirestore.instance.collection('users').doc(user.uid).snapshots(),
        builder: (context, snapshot) {
          double deposit = 0.0;
          double winning = 0.0;
          double system = 0.0;
          
          if (snapshot.hasData && snapshot.data!.exists) {
            final data = snapshot.data!.data() as Map<String, dynamic>;
            deposit = ((data['depositBalance'] ?? 0) as num).toDouble();
            winning = ((data['winningBalance'] ?? 0) as num).toDouble();
            system = ((data['systemBalance'] ?? 0) as num).toDouble();
          }
          final total = deposit + winning + system;

          return SingleChildScrollView(
            padding: EdgeInsets.only(
              left: 16,
              right: 16,
              top: 16,
              bottom: MediaQuery.of(context).viewInsets.bottom + 16,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF1E293B), Color(0xFF0F172A)],
                    ),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.cyan.withOpacity(0.5)),
                  ),
                  child: Column(
                    children: [
                      const Text(
                        'TOTAL WALLET BALANCE',
                        style: TextStyle(
                          color: AppColors.textSecondary,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        '${total.toStringAsFixed(2)} Coins',
                        style: GoogleFonts.orbitron(
                          fontSize: 28,
                          fontWeight: FontWeight.w900,
                         color: AppColors.cyan,
                        ),
                      ),
                      const SizedBox(height: 16),
                      const Divider(color: AppColors.cardBorder),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          _buildSubBal('DEPOSIT', '${deposit.toStringAsFixed(0)}', AppColors.gold),
                          Container(width: 1, height: 30, color: AppColors.cardBorder),
                          _buildSubBal('WINNING', '${winning.toStringAsFixed(0)}', AppColors.green),
                          Container(width: 1, height: 30, color: AppColors.cardBorder),
                          _buildSubBal('SYSTEM', '${system.toStringAsFixed(0)}', AppColors.orange),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                Container(
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: TabBar(
                    controller: _tabController,
                    indicator: BoxDecoration(
                      color: AppColors.cyan,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    labelColor: Colors.black,
                    unselectedLabelColor: AppColors.textSecondary,
                    tabs: const [
                      Tab(text: 'ADD COINS'),
                      Tab(text: 'WITHDRAW'),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                AnimatedBuilder(
                  animation: _tabController,
                  builder: (context, _) {
                    if (_tabController.index == 0) {
                      final currentAmt = int.tryParse(_customAmountCtrl.text.trim()) ?? _selectedAmount;
                      final upiPayload = 'upi://pay?pa=${AppConfig.upiId}&pn=Battle%20Arena&am=$currentAmt&cu=INR';
                      
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          const Text(
                            'Select Deposit Amount (Min 11 - Max 1000 Coins):',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 10),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: _presets.map((amt) {
                              final isSel = _selectedAmount == amt;
                              return ChoiceChip(
                                label: Text('$amt'),
                                selected: isSel,
                                selectedColor: AppColors.cyan,
                                backgroundColor: AppColors.surfaceLight,
                                labelStyle: TextStyle(
                                  color: isSel ? Colors.black : AppColors.textPrimary,
                                  fontWeight: FontWeight.bold,
                                ),
                                onSelected: (_) {
                                  setState(() {
                                    _selectedAmount = amt;
                                    _customAmountCtrl.text = amt.toString();
                                  });
                                },
                              );
                            }).toList(),
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            controller: _customAmountCtrl,
                            keyboardType: TextInputType.number,
                            inputFormatters: [
                              FilteringTextInputFormatter.digitsOnly,
                              LengthLimitingTextInputFormatter(4),
                            ],
                            style: const TextStyle(color: AppColors.textPrimary),
                            decoration: InputDecoration(
                              labelText: 'Or Enter Custom Amount (11 - 1,000 Coins)',
                              labelStyle: const TextStyle(color: AppColors.textMuted),
                              filled: true,
                              fillColor: AppColors.surfaceLight,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                              errorText: (currentAmt < 11 || currentAmt > 1000)
                                  ? 'Amount must be between 11 and 1,000'
                                  : null,
                            ),
                            onChanged: (v) {
                              final val = int.tryParse(v);
                              if (val != null) setState(() => _selectedAmount = val);
                            },
                          ),
                          const SizedBox(height: 16),
                          Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: AppColors.surface,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: AppColors.cardBorder),
                            ),
                            child: Column(
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Scan to Pay $currentAmt',
                                      style: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w900,
                                        color: AppColors.gold,
                                      ),
                                    ),
                                    ElevatedButton.icon(
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: AppColors.surfaceLight,
                                        foregroundColor: AppColors.cyan,
                                        elevation: 0,
                                        side: const BorderSide(color: AppColors.cyan, width: 1),
                                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                      ),
                                      icon: const Icon(Icons.download, size: 16),
                                      label: const Text(
                                        'Save QR',
                                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11),
                                      ),
                                      onPressed: () => _downloadQrCode(upiPayload, currentAmt),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 12),
                                Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(12),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withOpacity(0.3),
                                        blurRadius: 10,
                                        spreadRadius: 2,
                                      )
                                    ],
                                  ),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(8),
                                    child: Image.network(
                                      'https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${Uri.encodeComponent(upiPayload)}',
                                      width: 180,
                                      height: 180,
                                      fit: BoxFit.contain,
                                      errorBuilder: (context, error, stackTrace) => Container(
                                        width: 180,
                                        height: 180,
                                        color: Colors.white,
                                        padding: const EdgeInsets.all(8),
                                        child: Column(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            const Icon(Icons.qr_code_2, size: 80, color: Colors.black87),
                                            const SizedBox(height: 4),
                                            Text(
                                              'SCAN TO PAY $currentAmt',
                                              style: const TextStyle(
                                                color: Colors.black,
                                                fontSize: 10,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 14),
                                OutlinedButton.icon(
                                  style: OutlinedButton.styleFrom(
                                    side: const BorderSide(color: AppColors.cyan),
                                    foregroundColor: AppColors.cyan,
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                  ),
                                  icon: const Icon(Icons.open_in_new, size: 16),
                                  label: const Text(
                                    'PAY DIRECT VIA UPI APP',
                                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
                                  ),
                                  onPressed: () => openExternalUrl(context, upiPayload),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 16),
                          TextField(
                            controller: _utrCtrl,
                            keyboardType: TextInputType.number,
                            style: const TextStyle(color: AppColors.textPrimary),
                            decoration: InputDecoration(
                              labelText: 'Enter 12-Digit UPI Ref / UTR No.',
                              labelStyle: const TextStyle(color: AppColors.textMuted),
                              filled: true,
                              fillColor: AppColors.surfaceLight,
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                          ),
                          const SizedBox(height: 14),
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: AppColors.surfaceLight,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color: _screenshotBytes != null ? AppColors.green : AppColors.cardBorder,
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      children: [
                                        Icon(
                                          _screenshotBytes != null ? Icons.check_circle : Icons.add_photo_alternate,
                                          color: _screenshotBytes != null ? AppColors.green : AppColors.cyan,
                                          size: 22,
                                        ),
                                        const SizedBox(width: 8),
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              _screenshotBytes != null ? 'Screenshot Attached' : 'Attach Payment Screenshot',
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 13,
                                                color: _screenshotBytes != null ? AppColors.green : AppColors.textPrimary,
                                              ),
                                            ),
                                            if (_screenshotName != null)
                                              Text(
                                                _screenshotName!,
                                                style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                                              ),
                                          ],
                                        ),
                                      ],
                                    ),
                                    ElevatedButton.icon(
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: _screenshotBytes != null ? AppColors.surface : AppColors.cyan,
                                        foregroundColor: _screenshotBytes != null ? AppColors.cyan : Colors.black,
                                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                        minimumSize: Size.zero,
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                      ),
                                      icon: Icon(_screenshotBytes != null ? Icons.change_circle : Icons.photo_library, size: 16),
                                      label: Text(
                                        _screenshotBytes != null ? 'Change' : 'Open Gallery',
                                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11),
                                      ),
                                      onPressed: _pickScreenshot,
                                    ),
                                  ],
                                ),
                                if (_screenshotBytes != null) ...[
                                  const SizedBox(height: 10),
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(8),
                                    child: SizedBox(
                                      height: 140,
                                      width: double.infinity,
                                      child: Stack(
                                        fit: StackFit.expand,
                                        children: [
                                          Image.memory(_screenshotBytes!, fit: BoxFit.cover),
                                          Positioned(
                                            top: 6,
                                            right: 6,
                                            child: InkWell(
                                              onTap: () => setState(() {
                                                _screenshotBytes = null;
                                                _screenshotBase64 = null;
                                                _screenshotName = null;
                                              }),
                                              child: Container(
                                                padding: const EdgeInsets.all(4),
                                                decoration: const BoxDecoration(
                                                  color: Colors.black87,
                                                  shape: BoxShape.circle,
                                                ),
                                                child: const Icon(Icons.close, color: Colors.white, size: 16),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          ),
                          const SizedBox(height: 16),
                          SizedBox(
                            height: 48,
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.cyan,
                                foregroundColor: Colors.black,
                              ),
                              onPressed: _isSubmitting ? null : _submitDeposit,
                              child: _isSubmitting
                                  ? const CircularProgressIndicator(color: Colors.black)
                                  : const Text(
                                      'SUBMIT PAYMENT FOR VERIFICATION',
                                      style: TextStyle(fontWeight: FontWeight.w900),
                                    ),
                            ),
                          ),
                        ],
                      );
                    } else {
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: AppColors.surfaceLight,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text(
                                  'Available to Withdraw:',
                                  style: TextStyle(color: AppColors.textSecondary),
                                ),
                                Text(
                                  '${winning.toStringAsFixed(2)} Coins',
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.green,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 14),
                          TextField(
                            controller: _withdrawUpiCtrl,
                            style: const TextStyle(color: AppColors.textPrimary),
                            decoration: InputDecoration(
                              labelText: 'Enter UPI ID (e.g. yourname@upi)',
                              labelStyle: const TextStyle(color: AppColors.textMuted),
                              filled: true,
                              fillColor: AppColors.surfaceLight,
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            controller: _withdrawAmountCtrl,
                            keyboardType: TextInputType.number,
                            style: const TextStyle(color: AppColors.textPrimary),
                            decoration: InputDecoration(
                              labelText: 'Withdrawal Amount (11 - 1000 Coins)',
                              labelStyle: const TextStyle(color: AppColors.textMuted),
                              filled: true,
                              fillColor: AppColors.surfaceLight,
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                          ),
                          const SizedBox(height: 16),
                          SizedBox(
                            height: 48,
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.green,
                                foregroundColor: Colors.black,
                              ),
                              onPressed: _isSubmitting ? null : () => _submitWithdrawal(winning),
                              child: _isSubmitting
                                  ? const CircularProgressIndicator(color: Colors.black)
                                  : const Text(
                                      'SUBMIT WITHDRAWAL REQUEST',
                                      style: TextStyle(fontWeight: FontWeight.w900),
                                    ),
                            ),
                          ),
                        ],
                      );
                    }
                  },
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildSubBal(String title, String val, Color c) {
    return Column(
      children: [
        Text(
          title,
          style: const TextStyle(fontSize: 10, color: AppColors.textMuted, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 2),
        Text(
          val,
          style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: c),
        ),
      ],
    );
  }
}

class PassbookScreen extends StatelessWidget {
  const PassbookScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('COIN HISTORY'),
        backgroundColor: AppColors.surface,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('passbook')
            .where('userId', isEqualTo: user?.uid)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator(color: AppColors.cyan));
          }
          
          final docs = snapshot.data!.docs.toList()
            ..sort((a, b) => (b['createdAt'] as Timestamp).compareTo(a['createdAt'] as Timestamp));
            
          if (docs.isEmpty) {
            return const Center(
              child: Text('No transactions yet.', style: TextStyle(color: AppColors.textSecondary)),
            );
          }
          
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: docs.length,
            itemBuilder: (ctx, i) {
              final d = docs[i].data() as Map<String, dynamic>;
              final type = d['type'] ?? '';
              final amount = (d['amount'] as num?)?.toDouble() ?? 0.0;
              final isDebit = type == 'MATCH_ENTRY' || type == 'WITHDRAWAL_REQUEST' || type == 'ADMIN_DEBIT';
              final reason = d['reason'] != null ? '\nReason: ${d['reason']}' : '';
              
              return Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppColors.cardBorder),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            d['title'] ?? '',
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                          ),
                          Text(
                            '$type$reason',
                            style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
                          ),
                        ],
                      ),
                    ),
                    Text(
                      '${isDebit ? '-' : '+'}${amount.toStringAsFixed(0)} Coins',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: isDebit ? AppColors.red : AppColors.green,
                      ),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});
  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _searchCtrl = TextEditingController();
  String _searchQuery = "";
  String? _selectedCreateMode;
  final _createTimeCtrl = TextEditingController();
  final _createTitleCtrl = TextEditingController();
  final _createMapCtrl = TextEditingController();
  final _createEntryCtrl = TextEditingController();
  final _createPrizeCtrl = TextEditingController();
  final _createPerKillCtrl = TextEditingController();
  final _createSlotsCtrl = TextEditingController();
  final _maintenanceTimeCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 9, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchCtrl.dispose();
    _createTimeCtrl.dispose();
    _createTitleCtrl.dispose();
    _createMapCtrl.dispose();
    _createEntryCtrl.dispose();
    _createPrizeCtrl.dispose();
    _createPerKillCtrl.dispose();
    _createSlotsCtrl.dispose();
    _maintenanceTimeCtrl.dispose();
    super.dispose();
  }

  void _logAdminAction(String action) {
    FirebaseFirestore.instance.collection('admin_logs').add({
      'action': action,
      'adminEmail': FirebaseAuth.instance.currentUser?.email,
      'timestamp': FieldValue.serverTimestamp(),
    });
  }

  void _sendNotify(String title, String desc) async {
    await FirebaseFirestore.instance.collection('notifications').add({
      'title': title,
      'desc': desc,
      'userId': 'ALL',
      'read': false,
      'createdAt': FieldValue.serverTimestamp(),
    });
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Notification Sent to All Users!')),
      );
    }
  }

  void _showAdjustCoinsDialog(DocumentSnapshot doc) {
    final amountCtrl = TextEditingController();
    final reasonCtrl = TextEditingController();
    String selectedBal = 'winningBalance';

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('ADJUST COINS', style: TextStyle(color: AppColors.gold, fontWeight: FontWeight.bold)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            DropdownButtonFormField<String>(
              value: selectedBal,
              decoration: InputDecoration(
                labelText: 'Select Balance Type',
                filled: true,
                fillColor: AppColors.surfaceLight,
                border: const OutlineInputBorder(),
              ),
              items: const [
                DropdownMenuItem(value: 'depositBalance', child: Text('Deposit Coins')),
                DropdownMenuItem(value: 'winningBalance', child: Text('Winning Coins')),
                DropdownMenuItem(value: 'systemBalance', child: Text('System Coins')),
              ],
              onChanged: (v) => selectedBal = v!,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: amountCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Amount (e.g. 50 or -50)',
                filled: true,
                fillColor: AppColors.surfaceLight,
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: reasonCtrl,
              decoration: const InputDecoration(
                labelText: 'Reason (e.g. Bonus, Penalty)',
                filled: true,
                fillColor: AppColors.surfaceLight,
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('CANCEL')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.cyan, foregroundColor: Colors.black),
            onPressed: () async {
              final amt = int.tryParse(amountCtrl.text) ?? 0;
              final reason = reasonCtrl.text.trim();
              if (amt != 0 && reason.isNotEmpty) {
                showDialog(
                  context: context,
                  builder: (c) => AlertDialog(
                    backgroundColor: AppColors.surface,
                    title: const Text('Are you sure?'),
                    content: Text('Do you want to ${amt > 0 ? "ADD" : "DEDUCT"} $amt Coins to this user?'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(c), child: const Text('NO')),
                      ElevatedButton(
                        onPressed: () async {
                          Navigator.pop(c);
                          await doc.reference.update({selectedBal: FieldValue.increment(amt)});
                          await FirebaseFirestore.instance.collection('passbook').add({
                            'userId': doc.id,
                            'type': amt > 0 ? 'ADMIN_CREDIT' : 'ADMIN_DEBIT',
                            'amount': amt.abs().toDouble(),
                            'title': 'Admin Adjustment',
                            'reason': reason,
                            'createdAt': FieldValue.serverTimestamp(),
                          });
                          if (context.mounted) {
                            Navigator.pop(ctx);
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(backgroundColor: AppColors.green, content: Text('Coins Adjusted!')),
                            );
                          }
                        },
                        child: const Text('YES'),
                      ),
                    ],
                  ),
                );
              }
            },
            child: const Text('CONFIRM'),
          ),
        ],
      ),
    );
  }

  void _editMatchDialog(BuildContext context, TournamentMatch match) {
    final titleCtrl = TextEditingController(text: match.title);
    final mapCtrl = TextEditingController(text: match.map);
    final entryCtrl = TextEditingController(text: match.entryFee.toString());
    final prizeCtrl = TextEditingController(text: match.prizePool.toString());
    final perKillCtrl = TextEditingController(text: match.perKill.toString());
    final timeCtrl = TextEditingController(text: match.matchTime);
    final roomCtrl = TextEditingController(text: match.roomId);
    final passCtrl = TextEditingController(text: match.roomPassword);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(
            left: 20,
            right: 20,
            top: 20,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('EDIT MATCH: ${match.id}', style: GoogleFonts.orbitron(fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.cyan)),
                    IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(ctx)),
                  ],
                ),
                TextField(controller: titleCtrl, style: const TextStyle(color: AppColors.textPrimary), decoration: InputDecoration(labelText: 'Match Title', filled: true, fillColor: AppColors.surfaceLight, border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)))),
                const SizedBox(height: 10),
                TextField(controller: mapCtrl, style: const TextStyle(color: AppColors.textPrimary), decoration: InputDecoration(labelText: 'Map', filled: true, fillColor: AppColors.surfaceLight, border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)))),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(child: TextField(controller: entryCtrl, keyboardType: TextInputType.number, style: const TextStyle(color: AppColors.textPrimary), decoration: InputDecoration(labelText: 'Entry Fee (Coins)', filled: true, fillColor: AppColors.surfaceLight, border: OutlineInputBorder(borderRadius: BorderRadius.circular(8))))),
                    const SizedBox(width: 12),
                    Expanded(child: TextField(controller: prizeCtrl, keyboardType: TextInputType.number, style: const TextStyle(color: AppColors.textPrimary), decoration: InputDecoration(labelText: 'Prize Pool (Coins)', filled: true, fillColor: AppColors.surfaceLight, border: OutlineInputBorder(borderRadius: BorderRadius.circular(8))))),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(child: TextField(controller: perKillCtrl, keyboardType: TextInputType.number, style: const TextStyle(color: AppColors.textPrimary), decoration: InputDecoration(labelText: 'Per Kill (Coins)', filled: true, fillColor: AppColors.surfaceLight, border: OutlineInputBorder(borderRadius: BorderRadius.circular(8))))),
                    const SizedBox(width: 12),
                    Expanded(child: TextField(controller: timeCtrl, style: const TextStyle(color: AppColors.textPrimary), decoration: InputDecoration(labelText: 'Match Time', filled: true, fillColor: AppColors.surfaceLight, border: OutlineInputBorder(borderRadius: BorderRadius.circular(8))))),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(child: TextField(controller: roomCtrl, style: const TextStyle(color: AppColors.textPrimary), decoration: InputDecoration(labelText: 'Room ID', filled: true, fillColor: AppColors.surfaceLight, border: OutlineInputBorder(borderRadius: BorderRadius.circular(8))))),
                    const SizedBox(width: 12),
                    Expanded(child: TextField(controller: passCtrl, style: const TextStyle(color: AppColors.textPrimary), decoration: InputDecoration(labelText: 'Room Password', filled: true, fillColor: AppColors.surfaceLight, border: OutlineInputBorder(borderRadius: BorderRadius.circular(8))))),
                  ],
                ),
                const SizedBox(height: 20),
                SizedBox(
                  height: 48,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: AppColors.cyan, foregroundColor: Colors.black),
                    onPressed: () async {
                      final newTitle = titleCtrl.text.trim().isEmpty ? match.title : titleCtrl.text.trim();
                      final newMap = mapCtrl.text.trim().isEmpty ? match.map : mapCtrl.text.trim();
                      final newEntry = int.tryParse(entryCtrl.text.trim()) ?? match.entryFee;
                      final newPrize = int.tryParse(prizeCtrl.text.trim()) ?? match.prizePool;
                      final newKill = int.tryParse(perKillCtrl.text.trim()) ?? match.perKill;
                      final newTime = timeCtrl.text.trim().isEmpty ? match.matchTime : timeCtrl.text.trim();
                      final newRoom = roomCtrl.text.trim().isEmpty ? match.roomId : roomCtrl.text.trim();
                      final newPass = passCtrl.text.trim().isEmpty ? match.roomPassword : passCtrl.text.trim();
                      
                      try {
                        await FirebaseFirestore.instance.collection('matches').doc(match.id).set({
                          'title': newTitle,
                          'map': newMap,
                          'entryFee': newEntry,
                          'prizePool': newPrize,
                          'perKill': newKill,
                          'matchTime': newTime,
                          'roomId': newRoom,
                          'roomPassword': newPass,
                          'updatedAt': FieldValue.serverTimestamp(),
                        }, SetOptions(merge: true));
                        
                        if (context.mounted) {
                          Navigator.pop(ctx);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(backgroundColor: AppColors.green, content: Text('✅ ${match.id} updated live!')),
                          );
                        }
                      } catch (e) {
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
                        }
                      }
                    },
                    child: const Text('SAVE LIVE CHANGES', style: TextStyle(fontWeight: FontWeight.w900)),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

    void _viewScreenshotDialog(BuildContext context, String? base64String, String utr, String amount, String userName) {
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('PAYMENT SCREENSHOT', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppColors.gold)),
                  IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(ctx)),
                ],
              ),
              const Divider(color: AppColors.cardBorder),
              const SizedBox(height: 8),
              if (base64String != null && base64String.isNotEmpty)
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: InteractiveViewer(
                    child: Container(
                      constraints: const BoxConstraints(maxHeight: 350),
                      child: Image.memory(base64Decode(base64String), fit: BoxFit.contain),
                    ),
                  ),
                )
              else
                const Padding(
                  padding: EdgeInsets.all(20),
                  child: Text('No screenshot uploaded by user', style: TextStyle(color: AppColors.textSecondary)),
                ),
              const SizedBox(height: 12),
              Text('UTR: $utr • $amount Coins', style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.cyan, fontSize: 14)),
              Text('Sender: $userName', style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
              const SizedBox(height: 16),
              
              // 🔥 NAYA BUTTON: Screenshot Download Karne Ke Liye
              if (base64String != null && base64String.isNotEmpty)
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.gold, 
                      foregroundColor: Colors.black,
                    ),
                    icon: const Icon(Icons.download),
                    label: const Text('DOWNLOAD SCREENSHOT', style: TextStyle(fontWeight: FontWeight.bold)),
                    onPressed: () {
                      // Browser/Phone mein image download karne ka tareeka
                      final bytes = base64Decode(base64String);
                      // Note: Flutter Web mein download karne ke liye direct html anchor use hota hai,
                      // par hum yahan simple prompt de rahe hain.
                      showCustomDialog(
                        context: context, 
                        title: 'DOWNLOAD INFO', 
                        message: 'Screenshot ko save karne ke liye image par long-press (2 second) karein aur "Save Image" par click karein. (Mobile App mein yeh direct gallery mein save hoga).', 
                        icon: Icons.info, 
                        color: AppColors.cyan
                      );
                    },
                  ),
                ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: AppColors.cyan, foregroundColor: Colors.black),
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text('CLOSE PREVIEW'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _promptAdminPassword(String type, VoidCallback onSuccess) {
    final pwdCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: Text('SECURITY CHECK', style: TextStyle(color: AppColors.gold, fontWeight: FontWeight.bold)),
        content: TextField(
          controller: pwdCtrl,
          obscureText: true,
          style: const TextStyle(color: AppColors.textPrimary),
          decoration: InputDecoration(
            labelText: 'Enter $type Password',
            filled: true,
            fillColor: AppColors.surfaceLight,
            border: const OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('CANCEL')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.green, foregroundColor: Colors.black),
            onPressed: () {
              final pwd = pwdCtrl.text.trim();
              if (type == 'Deposit' && pwd == AppConfig.depositAdminPassword) {
                Navigator.pop(ctx);
                onSuccess();
              } else if (type == 'Withdrawal' && pwd == AppConfig.withdrawAdminPassword) {
                Navigator.pop(ctx);
                onSuccess();
              } else {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(backgroundColor: AppColors.red, content: Text('Incorrect Password!')));
              }
            },
            child: const Text('VERIFY'),
          ),
        ],
      ),
    );
  }

  void _showRejectReasonDialog(String type, DocumentSnapshot doc) {
    final reasonCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: Text('REJECT $type', style: TextStyle(color: AppColors.red, fontWeight: FontWeight.bold)),
        content: TextField(
          controller: reasonCtrl,
          maxLines: 3,
          style: const TextStyle(color: AppColors.textPrimary),
          decoration: InputDecoration(
            labelText: 'Reason for Rejection',
            filled: true,
            fillColor: AppColors.surfaceLight,
            border: const OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('CANCEL')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.red, foregroundColor: Colors.white),
            onPressed: () async {
              final reason = reasonCtrl.text.trim();
              if (reason.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please enter a reason.')));
                return;
              }
              Navigator.pop(ctx);
              try {
                if (type == 'Deposit') {
                  await doc.reference.update({'status': 'REJECTED', 'rejectReason': reason, 'rejectedAt': FieldValue.serverTimestamp()});
                  await FirebaseFirestore.instance.collection('notifications').add({
                    'userId': doc['userId'],
                    'title': 'Deposit Rejected',
                    'desc': 'Your deposit of ${doc['amount']} Coins was rejected. Reason: $reason',
                    'cat': 'WALLET',
                    'color': 'red',
                    'createdAt': FieldValue.serverTimestamp(),
                  });
                } else {
                  final uRef = FirebaseFirestore.instance.collection('users').doc(doc['userId']);
                  final uSnap = await uRef.get();
                  if (uSnap.exists) {
                    final curWin = ((uSnap.data()!['winningBalance'] ?? 0) as num).toDouble();
                    final refund = ((doc['amount'] as num)).toDouble();
                    await uRef.update({'winningBalance': curWin + refund});
                  }
                  await doc.reference.update({'status': 'REJECTED', 'rejectReason': reason, 'rejectedAt': FieldValue.serverTimestamp()});
                  await FirebaseFirestore.instance.collection('notifications').add({
                    'userId': doc['userId'],
                    'title': 'Withdrawal Rejected',
                    'desc': 'Your withdrawal of ${doc['amount']} Coins was rejected & refunded. Reason: $reason',
                    'cat': 'WALLET',
                    'color': 'red',
                    'createdAt': FieldValue.serverTimestamp(),
                  });
                }
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(backgroundColor: AppColors.green, content: Text('Request Rejected Successfully')));
                }
              } catch (e) {
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
                }
              }
            },
            child: const Text('REJECT'),
          ),
        ],
      ),
    );
  }

  Future<void> _approveDeposit(BuildContext context, DocumentSnapshot doc) async {
    final data = doc.data() as Map<String, dynamic>;
    if (data['status'] == 'APPROVED') {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(backgroundColor: AppColors.red, content: Text('This deposit is already approved!')));
      }
      return;
    }
    final userId = data['userId'] as String;
    final amount = (data['amount'] as num).toDouble();
    final utr = data['utr'] ?? '---';

    try {
      final userRef = FirebaseFirestore.instance.collection('users').doc(userId);
      final requestRef = doc.reference;

      await FirebaseFirestore.instance.runTransaction((transaction) async {
        DocumentSnapshot requestSnap = await transaction.get(requestRef);
        if (requestSnap.get('status') == 'APPROVED') {
          throw Exception('This deposit is already approved!');
        }
        transaction.set(userRef, {'depositBalance': FieldValue.increment(amount), 'totalBalance': FieldValue.increment(amount)}, SetOptions(merge: true));
        final passRef = FirebaseFirestore.instance.collection('passbook').doc();
        transaction.set(passRef, {'userId': userId, 'type': 'DEPOSIT_APPROVED', 'amount': amount, 'title': 'Deposit Approved (UTR: $utr)', 'createdAt': FieldValue.serverTimestamp()});
        final notifRef = FirebaseFirestore.instance.collection('notifications').doc();
        transaction.set(notifRef, {'title': 'Deposit Approved: $amount Coins', 'desc': 'Your UTR $utr has been approved and $amount Coins credited.', 'cat': 'WALLET', 'color': 'gold', 'createdAt': FieldValue.serverTimestamp(), 'userId': userId});
        transaction.update(requestRef, {'status': 'APPROVED', 'approvedAt': FieldValue.serverTimestamp()});
      });

      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: AppColors.green, content: Text('✅ Deposit of $amount Coins approved!')));
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: AppColors.red, content: Text('Error approving: ${e.toString().replaceAll('Exception: ', '')}')));
      }
    }
  }

  void _approveWithdrawal(BuildContext context, DocumentSnapshot doc) async {
    try {
      await doc.reference.update({'status': 'COMPLETED', 'completedAt': FieldValue.serverTimestamp()});
      await FirebaseFirestore.instance.collection('notifications').add({
        'userId': doc['userId'],
        'title': 'Withdrawal Approved 💸',
        'desc': 'Your withdrawal of ${doc['amount']} Coins has been processed to your UPI ID.',
        'cat': 'WALLET',
        'color': 'green',
        'createdAt': FieldValue.serverTimestamp(),
      });
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(backgroundColor: AppColors.green, content: Text('✅ Withdrawal Marked as PAID!')));
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    }
  }

  void _showReplyDialog(BuildContext context, DocumentSnapshot doc) {
    final remarkCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Reply to Ticket', style: TextStyle(color: AppColors.cyan)),
        content: TextField(
          controller: remarkCtrl,
          maxLines: 3,
          decoration: const InputDecoration(
            labelText: 'Admin Remark / Resolution',
            filled: true,
            fillColor: AppColors.surfaceLight,
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              await doc.reference.update({'status': 'Resolved', 'adminRemark': remarkCtrl.text.trim()});
              if (context.mounted) Navigator.pop(ctx);
            },
            child: const Text('Submit Reply'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('ADMIN PANEL', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)),
        backgroundColor: AppColors.surface,
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppColors.gold,
          labelColor: AppColors.gold,
          unselectedLabelColor: AppColors.textSecondary,
          isScrollable: true,
          tabs: [
            const Tab(icon: Icon(Icons.sports_esports), text: 'MATCHES'),
            const Tab(icon: Icon(Icons.notifications_active), text: 'ALERTS'),
            Tab(icon: StreamBuilder<QuerySnapshot>(stream: FirebaseFirestore.instance.collection('deposit_requests').where('status', isEqualTo: 'PENDING').snapshots(), builder: (ctx, snap) { int c = snap.data?.docs.length ?? 0; return Badge(isLabelVisible: c > 0, label: Text('$c'), backgroundColor: AppColors.red, child: const Icon(Icons.arrow_downward)); }), text: 'DEPOSITS'),
            Tab(icon: StreamBuilder<QuerySnapshot>(stream: FirebaseFirestore.instance.collection('withdrawals').where('status', isEqualTo: 'PENDING').snapshots(), builder: (ctx, snap) { int c = snap.data?.docs.length ?? 0; return Badge(isLabelVisible: c > 0, label: Text('$c'), backgroundColor: AppColors.red, child: const Icon(Icons.arrow_upward)); }), text: 'WITHDRAWALS'),
            const Tab(icon: Icon(Icons.emoji_events), text: 'RESULTS'),
            const Tab(icon: Icon(Icons.support_agent), text: 'SUPPORT'),
            const Tab(icon: Icon(Icons.add_box), text: 'CREATE MATCH'),
            const Tab(icon: Icon(Icons.people), text: 'USERS'),
            const Tab(icon: Icon(Icons.settings), text: 'SETTINGS'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [


          // TAB 1: MATCHES
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance.collection('matches').snapshots(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) return const Center(child: CircularProgressIndicator(color: AppColors.cyan));
              
              // 🔥 Filter out deleted matches
              final activeMatches = snapshot.data!.docs.where((doc) {
                final d = doc.data() as Map<String, dynamic>;
                return d['isDeleted'] != true;
              }).toList();

              return ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: activeMatches.length,
                itemBuilder: (ctx, i) {
                  final doc = activeMatches[i];
                  final d = doc.data() as Map<String, dynamic>;
                  
                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.cardBorder),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // 🔥 TITLE & BUTTONS (Overflow Fix)
                        Row(
  crossAxisAlignment: CrossAxisAlignment.start,
  children: [
    Expanded(
      child: Text(
        d['title'] ?? 'Match',
        style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.w900, fontSize: 14),
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
      ),
    ),
    const SizedBox(width: 8),
    Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        ElevatedButton.icon(
          style: ElevatedButton.styleFrom(backgroundColor: AppColors.gold, foregroundColor: Colors.black, padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), minimumSize: Size.zero), 
          icon: const Icon(Icons.notifications, size: 14), 
          label: const Text('NOTIFY', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 10)), 
          onPressed: () => _sendNotify('🔥 MATCH ALERT: ${doc.id}', 'Time: ${d['matchTime']}\nJoin fast & win Coins.')
        ),
        ElevatedButton.icon(
          style: ElevatedButton.styleFrom(backgroundColor: AppColors.cyan, foregroundColor: Colors.black, padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), minimumSize: Size.zero), 
          icon: const Icon(Icons.copy, size: 14), 
          label: const Text('CLONE', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 10)), 
          onPressed: () {
            final newId = 'BA-${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}';
            FirebaseFirestore.instance.collection('matches').doc(newId).set({...d, 'status': 'UPCOMING', 'filledSlots': 0, 'matchTime': 'TBD', 'createdAt': FieldValue.serverTimestamp(), 'isDeleted': false});
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Match Cloned! Please edit the time.')));
          }
        ),
      ],
    ),
  ],
),
                        const SizedBox(height: 8),
                        // 🔥 STATUS & SLOTS
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('Status: ${d['status']}', style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.cyan)),
                            Text('Slots: ${d['filledSlots'] ?? 0}/${d['totalSlots']}', style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.orange)),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text('Time: ${d['matchTime']}', style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                        const Divider(color: AppColors.cardBorder, height: 20),
                        
                        // 🔥 ACTION BUTTONS
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(backgroundColor: AppColors.red, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(horizontal: 10)), 
                              onPressed: () async {
  try {
    await doc.reference.update({'isDeleted': true});
    _logAdminAction('Deleted Match ${doc.id}');
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(backgroundColor: AppColors.green, content: Text('Match Deleted from Admin Panel!')));
  } catch (e) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
  }
},
                              child: const Text('DELETE', style: TextStyle(fontSize: 11))
                            ),
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(backgroundColor: Colors.orange, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(horizontal: 10)), 
                              onPressed: () {
                                final reasonCtrl = TextEditingController();
                                showDialog(context: context, builder: (c) => AlertDialog(
                                  backgroundColor: AppColors.surface,
                                  title: const Text('CANCEL MATCH & REFUND'),
                                  content: TextField(controller: reasonCtrl, decoration: const InputDecoration(labelText: 'Reason for cancellation')),
                                  actions: [
                                    TextButton(onPressed: () => Navigator.pop(c), child: const Text('BACK')),
                                    ElevatedButton(onPressed: () async {
                                      final reason = reasonCtrl.text.trim();
                                      if (reason.isEmpty) return;
                                      Navigator.pop(c);
                                      final entries = await FirebaseFirestore.instance.collection('match_entries').where('matchId', isEqualTo: doc.id).get();
                                      for (var e in entries.docs) {
                                        final uId = e['userId'];
                                        await FirebaseFirestore.instance.collection('users').doc(uId).update({'depositBalance': FieldValue.increment(d['entryFee'])}); 
                                        await FirebaseFirestore.instance.collection('passbook').add({'userId': uId, 'type': 'MATCH_CANCELLED', 'amount': d['entryFee'], 'title': 'Refund: Match Cancelled', 'reason': reason, 'createdAt': FieldValue.serverTimestamp()});
                                        await FirebaseFirestore.instance.collection('notifications').add({'userId': uId, 'title': 'Match Cancelled', 'desc': 'Match ${doc.id} was cancelled. Reason: $reason. ${d['entryFee']} Coins refunded.', 'createdAt': FieldValue.serverTimestamp()});
                                      }
                                      await doc.reference.update({'status': 'CANCELLED', 'cancelReason': reason});
                                      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(backgroundColor: AppColors.green, content: Text('Match Cancelled & Coins Refunded!')));
                                    }, child: const Text('CANCEL & REFUND'))
                                  ]
                                ));
                              }, 
                              child: const Text('CANCEL', style: TextStyle(fontSize: 11))
                            ),
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(backgroundColor: AppColors.orange, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(horizontal: 10)), 
                              onPressed: d['status'] == 'UPCOMING' ? () => doc.reference.update({'status': 'ONGOING'}) : () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Match already live or completed!'))), 
                              child: const Text('SET LIVE', style: TextStyle(fontSize: 11))
                            ),
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(backgroundColor: AppColors.green, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(horizontal: 10)), 
                              onPressed: () {
                                final m = TournamentMatch(id: doc.id, title: d['title'] ?? '', mode: d['mode'] ?? '', map: d['map'] ?? '', version: 'FF MAX', banner: d['banner'] ?? 'assets/banner_01.png', prizePool: (d['prizePool'] as num?)?.toInt() ?? 0, perKill: (d['perKill'] as num?)?.toInt() ?? 0, entryFee: (d['entryFee'] as num?)?.toInt() ?? 0, totalSlots: (d['totalSlots'] as num?)?.toInt() ?? 48, filledSlots: (d['filledSlots'] as num?)?.toInt() ?? 0, matchTime: d['matchTime'] ?? '', status: d['status'] ?? 'UPCOMING', roomId: d['roomId'] ?? 'TBD', roomPassword: d['roomPassword'] ?? 'TBD');
                                Navigator.push(context, MaterialPageRoute(builder: (_) => ManageMatchResultScreen(match: m)));
                              }, 
                              child: const Text('RESULT', style: TextStyle(fontSize: 11))
                            ),
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(backgroundColor: AppColors.cyan, foregroundColor: Colors.black, padding: const EdgeInsets.symmetric(horizontal: 10)), 
                              onPressed: () {
                                final m = TournamentMatch(id: doc.id, title: d['title'] ?? '', mode: d['mode'] ?? '', map: d['map'] ?? '', version: 'FF MAX', banner: d['banner'] ?? 'assets/banner_01.png', prizePool: (d['prizePool'] as num?)?.toInt() ?? 0, perKill: (d['perKill'] as num?)?.toInt() ?? 0, entryFee: (d['entryFee'] as num?)?.toInt() ?? 0, totalSlots: (d['totalSlots'] as num?)?.toInt() ?? 48, filledSlots: (d['filledSlots'] as num?)?.toInt() ?? 0, matchTime: d['matchTime'] ?? '', status: d['status'] ?? 'UPCOMING', roomId: d['roomId'] ?? 'TBD', roomPassword: d['roomPassword'] ?? 'TBD');
                                _editMatchDialog(context, m);
                              }, 
                              child: const Text('EDIT', style: TextStyle(fontSize: 11))
                            ),
                          ],
                        ),
                      ],
                    ),
                  );
                },
              );
            },
          ),
          
          // TAB 2: ALERTS
          ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const Text('PENDING OVERVIEW', style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.gold, fontSize: 16)),
              const SizedBox(height: 10),
              StreamBuilder<QuerySnapshot>(stream: FirebaseFirestore.instance.collection('deposit_requests').where('status', isEqualTo: 'PENDING').snapshots(), builder: (ctx, snap) {
                return ListTile(leading: const Icon(Icons.arrow_downward, color: AppColors.cyan), title: Text('${snap.data?.docs.length ?? 0} Pending Deposits'), trailing: ElevatedButton(onPressed: () => _tabController.animateTo(2), child: const Text('VIEW')));
              }),
              StreamBuilder<QuerySnapshot>(stream: FirebaseFirestore.instance.collection('withdrawals').where('status', isEqualTo: 'PENDING').snapshots(), builder: (ctx, snap) {
                return ListTile(leading: const Icon(Icons.arrow_upward, color: AppColors.red), title: Text('${snap.data?.docs.length ?? 0} Pending Withdrawals'), trailing: ElevatedButton(onPressed: () => _tabController.animateTo(3), child: const Text('VIEW')));
              }),
              StreamBuilder<QuerySnapshot>(stream: FirebaseFirestore.instance.collection('support_tickets').where('status', isEqualTo: 'Submitted').snapshots(), builder: (ctx, snap) {
                return ListTile(leading: const Icon(Icons.support_agent, color: AppColors.orange), title: Text('${snap.data?.docs.length ?? 0} New Support Tickets'), trailing: ElevatedButton(onPressed: () => _tabController.animateTo(5), child: const Text('VIEW')));
              }),
            ],
          ),

          // TAB 3: DEPOSITS
          DefaultTabController(
            length: 3,
            child: Column(
              children: [
                const TabBar(indicatorColor: AppColors.cyan, labelColor: AppColors.cyan, unselectedLabelColor: AppColors.textSecondary, tabs: [Tab(text: 'PENDING'), Tab(text: 'APPROVED'), Tab(text: 'REJECTED')]),
                Expanded(child: TabBarView(children: [_buildDepositList('PENDING'), _buildDepositList('APPROVED'), _buildDepositList('REJECTED')])),
              ],
            ),
          ),

          // TAB 4: WITHDRAWALS
          DefaultTabController(
            length: 3,
            child: Column(
              children: [
                const TabBar(indicatorColor: AppColors.cyan, labelColor: AppColors.cyan, unselectedLabelColor: AppColors.textSecondary, tabs: [Tab(text: 'PENDING'), Tab(text: 'COMPLETED'), Tab(text: 'REJECTED')]),
                Expanded(child: TabBarView(children: [_buildWithdrawList('PENDING'), _buildWithdrawList('COMPLETED'), _buildWithdrawList('REJECTED')])),
              ],
            ),
          ),

          // TAB 5: RESULTS
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance.collection('matches').snapshots(),
            builder: (context, snapshot) {
              final pendingMatches = <TournamentMatch>[];
              if (snapshot.hasData) {
                for (var doc in snapshot.data!.docs) {
                  final data = doc.data() as Map<String, dynamic>;
                  if (data['status'] == 'ONGOING' || data['status'] == 'UPCOMING') {
                    final modeData = kGameModes.firstWhere((m) => m.title == data['mode'], orElse: () => kGameModes.first);
                    pendingMatches.add(TournamentMatch(id: doc.id, title: data['title'] ?? '', mode: data['mode'] ?? '', map: data['map'] ?? '', version: 'FF MAX', banner: data['banner'] ?? modeData.banner, prizePool: (data['prizePool'] as num?)?.toInt() ?? 0, perKill: (data['perKill'] as num?)?.toInt() ?? 0, entryFee: (data['entryFee'] as num?)?.toInt() ?? 0, totalSlots: (data['totalSlots'] as num?)?.toInt() ?? 48, filledSlots: (data['filledSlots'] as num?)?.toInt() ?? 0, matchTime: data['matchTime'] ?? '', status: data['status'] ?? 'UPCOMING', roomId: data['roomId'] ?? 'TBD', roomPassword: data['roomPassword'] ?? 'TBD'));
                  }
                }
              }

              if (pendingMatches.isEmpty) return const Center(child: Text('No matches pending result.', style: TextStyle(color: AppColors.textSecondary)));

              return ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: pendingMatches.length,
                itemBuilder: (ctx, i) {
                  final m = pendingMatches[i];
                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.gold.withOpacity(0.5))),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(m.id, style: const TextStyle(color: AppColors.cyan, fontWeight: FontWeight.w900, fontSize: 16)), Text('Prize Pool: ${m.prizePool} Coins', style: const TextStyle(fontSize: 11, color: AppColors.gold))])),
                        ElevatedButton.icon(style: ElevatedButton.styleFrom(backgroundColor: AppColors.gold, foregroundColor: Colors.black), icon: const Icon(Icons.manage_accounts, size: 16), label: const Text('MANAGE RESULT', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11)), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ManageMatchResultScreen(match: m)))),
                      ],
                    ),
                  );
                },
              );
            },
          ),

          // TAB 6: SUPPORT
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance.collection('support_tickets').orderBy('createdAt', descending: true).snapshots(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
              if (snapshot.data!.docs.isEmpty) return const Center(child: Text('No support tickets found.'));
              return ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: snapshot.data!.docs.length,
                itemBuilder: (ctx, i) {
                  final doc = snapshot.data!.docs[i];
                  final d = doc.data() as Map<String, dynamic>;
                  final status = d['status'] ?? 'Submitted';
                  final isResolved = status == 'Resolved' || status == 'Rejected';
                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.cardBorder)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(d['ticketId'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.cyan)), Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2), decoration: BoxDecoration(color: isResolved ? AppColors.green.withOpacity(0.2) : AppColors.orange.withOpacity(0.2), borderRadius: BorderRadius.circular(4)), child: Text(status, style: TextStyle(color: isResolved ? AppColors.green : AppColors.orange, fontSize: 10, fontWeight: FontWeight.bold)))]),
                        const SizedBox(height: 6),
                        Text('Subject: ${d['subject']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                        Text('Desc: ${d['description']}', style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                        if (!isResolved) ...[
                          const SizedBox(height: 10),
                          Row(children: [Expanded(child: ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: AppColors.green, foregroundColor: Colors.black), onPressed: () => _showReplyDialog(ctx, doc), child: const Text('Resolve & Reply', style: TextStyle(fontSize: 12))))]),
                        ],
                      ],
                    ),
                  );
                },
              );
            },
          ),

          // TAB 7: CREATE MATCH
          SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text('CREATE NEW TOURNAMENT', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.gold)),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(value: _selectedCreateMode, decoration: InputDecoration(labelText: 'Select Game Mode', filled: true, fillColor: AppColors.surfaceLight, border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))), items: kGameModes.map((m) => DropdownMenuItem(value: m.title, child: Text(m.title))).toList(), onChanged: (val) => setState(() => _selectedCreateMode = val)),
                const SizedBox(height: 12),
                TextField(controller: _createTimeCtrl, style: const TextStyle(color: AppColors.textPrimary), decoration: const InputDecoration(labelText: 'Match Time (e.g. Today, 09:00 PM)', filled: true, fillColor: AppColors.surfaceLight, border: OutlineInputBorder())),
                const SizedBox(height: 12),
                TextField(controller: _createTitleCtrl, style: const TextStyle(color: AppColors.textPrimary), decoration: const InputDecoration(labelText: 'Match Title (e.g. Mega Bermuda Cup)', filled: true, fillColor: AppColors.surfaceLight, border: OutlineInputBorder())),
                const SizedBox(height: 12),
                TextField(controller: _createMapCtrl, style: const TextStyle(color: AppColors.textPrimary), decoration: const InputDecoration(labelText: 'Map (e.g. Bermuda Full Map, CS Kalahari)', filled: true, fillColor: AppColors.surfaceLight, border: OutlineInputBorder())),
                const SizedBox(height: 12),
                Row(children: [Expanded(child: TextField(controller: _createEntryCtrl, keyboardType: TextInputType.number, style: const TextStyle(color: AppColors.textPrimary), decoration: const InputDecoration(labelText: 'Entry Fee (Coins)', filled: true, fillColor: AppColors.surfaceLight, border: OutlineInputBorder()))), const SizedBox(width: 12), Expanded(child: TextField(controller: _createPrizeCtrl, keyboardType: TextInputType.number, style: const TextStyle(color: AppColors.textPrimary), decoration: const InputDecoration(labelText: 'Prize Pool (Coins)', filled: true, fillColor: AppColors.surfaceLight, border: OutlineInputBorder())))]),
                const SizedBox(height: 12),
                Row(children: [Expanded(child: TextField(controller: _createPerKillCtrl, keyboardType: TextInputType.number, style: const TextStyle(color: AppColors.textPrimary), decoration: const InputDecoration(labelText: 'Per Kill (Coins)', filled: true, fillColor: AppColors.surfaceLight, border: OutlineInputBorder()))), const SizedBox(width: 12), Expanded(child: TextField(controller: _createSlotsCtrl, keyboardType: TextInputType.number, style: const TextStyle(color: AppColors.textPrimary), decoration: const InputDecoration(labelText: 'Total Slots (e.g. 48)', filled: true, fillColor: AppColors.surfaceLight, border: OutlineInputBorder())))]),
                const SizedBox(height: 24),
                SizedBox(height: 50, child: ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: AppColors.cyan, foregroundColor: Colors.black), onPressed: () async {
                  if (_selectedCreateMode == null || _createTimeCtrl.text.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please fill Mode and Time'))); return; }
                  try {
                    final newId = 'BA-${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}';
                    final modeData = kGameModes.firstWhere((m) => m.title == _selectedCreateMode);
                    await FirebaseFirestore.instance.collection('matches').doc(newId).set({
                      'title': _createTitleCtrl.text.trim().isEmpty ? '$_selectedCreateMode #$newId' : _createTitleCtrl.text.trim(), 
                      'mode': _selectedCreateMode!.toUpperCase(), 
                      'map': _createMapCtrl.text.trim().isEmpty ? 'Bermuda Full Map' : _createMapCtrl.text.trim(), 
                      'version': 'FF MAX', 'banner': modeData.banner,
                      'prizePool': int.tryParse(_createPrizeCtrl.text) ?? 100, 'perKill': int.tryParse(_createPerKillCtrl.text) ?? 10, 'entryFee': int.tryParse(_createEntryCtrl.text) ?? 20,
                      'totalSlots': int.tryParse(_createSlotsCtrl.text) ?? 48, 'matchTime': _createTimeCtrl.text.trim(), 'status': 'UPCOMING', 'roomId': 'TBD', 'roomPassword': 'TBD', 'createdAt': FieldValue.serverTimestamp(), 'filledSlots': 0,
                    });
                    _createTimeCtrl.clear(); _createTitleCtrl.clear(); _createMapCtrl.clear(); _createEntryCtrl.clear(); _createPrizeCtrl.clear(); _createPerKillCtrl.clear(); _createSlotsCtrl.clear();
                    _logAdminAction('Created Match $newId');
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(backgroundColor: AppColors.green, content: Text('✅ Match Created Successfully!')));
                  } catch (e) { ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: AppColors.red, content: Text('Error: $e'))); }
                }, child: const Text('CREATE MATCH & PUBLISH LIVE', style: TextStyle(fontWeight: FontWeight.w900)))),
              ],
            ),
          ),

          // TAB 8: USERS
          Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: TextField(controller: _searchCtrl, onChanged: (val) => setState(() => _searchQuery = val.toLowerCase()), style: const TextStyle(color: AppColors.textPrimary), decoration: InputDecoration(hintText: 'Search by Name, Email or Phone...', hintStyle: const TextStyle(color: AppColors.textMuted), prefixIcon: const Icon(Icons.search, color: AppColors.cyan), filled: true, fillColor: AppColors.surfaceLight, border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none))),
              ),
              Expanded(
                child: StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance.collection('users').snapshots(),
                  builder: (context, snapshot) {
                    if (!snapshot.hasData) return const Center(child: CircularProgressIndicator(color: AppColors.cyan));
                    final users = snapshot.data!.docs.where((doc) { final d = doc.data() as Map<String, dynamic>; if (d['role'] == 'admin') return false; final name = (d['name'] ?? '').toString().toLowerCase(); final email = (d['email'] ?? '').toString().toLowerCase(); final phone = (d['phone'] ?? '').toString().toLowerCase(); return name.contains(_searchQuery) || email.contains(_searchQuery) || phone.contains(_searchQuery); }).toList();
                    if (users.isEmpty) return const Center(child: Text('No users found.', style: TextStyle(color: AppColors.textSecondary)));

                    return ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: users.length,
                      itemBuilder: (context, i) {
                        final doc = users[i];
                        final d = doc.data() as Map<String, dynamic>;
                        bool isBlocked = d['isBlocked'] ?? false;
                        return Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(10), border: Border.all(color: isBlocked ? AppColors.red : AppColors.cardBorder)),
                          child: Row(
                            children: [
                              CircleAvatar(backgroundColor: isBlocked ? AppColors.red : AppColors.cyan, child: Icon(isBlocked ? Icons.block : Icons.person, color: Colors.black)),
                              const SizedBox(width: 12),
                              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(d['name'] ?? 'Warrior', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)), Text(d['email'] ?? '', style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)), Text('Phone: ${d['phone'] ?? 'N/A'}', style: const TextStyle(fontSize: 11, color: AppColors.textMuted)), if (isBlocked && d['blockReason'] != null) Text('Reason: ${d['blockReason']}', style: const TextStyle(fontSize: 10, color: AppColors.red, fontWeight: FontWeight.bold))])),
                              IconButton(icon: const Icon(Icons.info_outline, color: AppColors.gold), onPressed: () => _showUserDetailsDialog(doc)),
                              Switch(value: isBlocked, activeColor: AppColors.red, onChanged: (val) { if (val) { _showBlockReasonDialog(doc); } else { doc.reference.update({'isBlocked': false, 'blockReason': FieldValue.delete()}); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(backgroundColor: AppColors.green, content: Text('User Unblocked!'))); } }),
                            ],
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ],
          ),

          // TAB 9: SETTINGS
          StreamBuilder<DocumentSnapshot>(
            stream: FirebaseFirestore.instance.collection('settings').doc('app').snapshots(),
            builder: (context, snapshot) {
              bool isMaintenance = snapshot.hasData && snapshot.data!.exists && (snapshot.data!.data() as Map)['isMaintenance'] == true;
              return ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  const Text('APP SETTINGS', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.gold)),
                  const SizedBox(height: 20),
                  Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.cardBorder)), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Maintenance Mode', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), const SizedBox(height: 4), Text(isMaintenance ? 'App is LOCKED for users.' : 'App is LIVE for everyone.', style: TextStyle(color: isMaintenance ? AppColors.red : AppColors.green, fontSize: 12))]), Switch(value: isMaintenance, activeColor: AppColors.red, onChanged: (val) async { await FirebaseFirestore.instance.collection('settings').doc('app').set({'isMaintenance': val}, SetOptions(merge: true)); })])),
                  const SizedBox(height: 16),
                  if (isMaintenance) ...[
                    const Text('Set Maintenance End Time (Timestamp)', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    TextField(controller: _maintenanceTimeCtrl, keyboardType: TextInputType.number, style: const TextStyle(color: AppColors.textPrimary), decoration: InputDecoration(hintText: 'e.g. 1735644000000', filled: true, fillColor: AppColors.surfaceLight, border: OutlineInputBorder())),
                    const SizedBox(height: 8),
                    ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: AppColors.cyan), onPressed: () async {
                      final time = int.tryParse(_maintenanceTimeCtrl.text) ?? 0;
                      await FirebaseFirestore.instance.collection('settings').doc('app').set({'maintenanceEndTime': time}, SetOptions(merge: true));
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('End time updated!')));
                    }, child: const Text('SAVE END TIME', style: TextStyle(color: Colors.black))),
                  ],
                ],
              );
            },
          ),
        ],
      ),
    );
  }

    Widget _buildDepositList(String status) {
    return StreamBuilder<QuerySnapshot>(
      // 🔥 orderBy hata diya taaki purane documents bhi dikhein
      stream: FirebaseFirestore.instance.collection('deposit_requests').where('status', isEqualTo: status).snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) return const Center(child: Text('No requests found.', style: TextStyle(color: AppColors.textSecondary)));
        
        // 🔥 Local Sorting
        final docs = snapshot.data!.docs.toList()..sort((a, b) {
          Timestamp t1 = (a.data() as Map)['timestamp'] ?? (a.data() as Map)['createdAt'] ?? Timestamp.now();
          Timestamp t2 = (b.data() as Map)['timestamp'] ?? (b.data() as Map)['createdAt'] ?? Timestamp.now();
          return t2.compareTo(t1);
        });

        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: docs.length,
          itemBuilder: (ctx, i) {
            final doc = docs[i];
            final data = doc.data() as Map<String, dynamic>;
            final amount = data['amount'] ?? 0;
            final utr = data['utr'] ?? '---';
            final userName = data['userName'] ?? 'Warrior';
            final userPhone = data['userPhone'] ?? '---';
            final base64Img = data['screenshotBase64'] as String?;
            
            return Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: status == 'APPROVED' ? AppColors.green : (status == 'REJECTED' ? AppColors.red : AppColors.gold))),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(userName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)), Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3), decoration: BoxDecoration(color: (status == 'APPROVED' ? AppColors.green : (status == 'REJECTED' ? AppColors.red : AppColors.gold)).withOpacity(0.2), borderRadius: BorderRadius.circular(6)), child: Text(status, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 10, color: status == 'APPROVED' ? AppColors.green : (status == 'REJECTED' ? AppColors.red : AppColors.gold))))]),
                  const SizedBox(height: 4),
                  Text('Phone: $userPhone • Amount: $amount Coins', style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.bold)),
                  Text('UTR Ref: $utr', style: const TextStyle(fontSize: 12, color: AppColors.cyan)),
                  const SizedBox(height: 10),
                  Row(children: [
                    OutlinedButton.icon(style: OutlinedButton.styleFrom(foregroundColor: AppColors.cyan, side: const BorderSide(color: AppColors.cyan)), icon: const Icon(Icons.image, size: 16), label: const Text('View Screenshot', style: TextStyle(fontSize: 12)), onPressed: () => _viewScreenshotDialog(context, base64Img, utr, amount.toString(), userName)),
                    const Spacer(),
                    if (status == 'PENDING') ...[
                      ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: AppColors.green, foregroundColor: Colors.black), onPressed: () => _promptAdminPassword('Deposit', () => _approveDeposit(context, doc)), child: const Text('APPROVE', style: TextStyle(fontWeight: FontWeight.w900))),
                      const SizedBox(width: 8),
                      ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: AppColors.red, foregroundColor: Colors.white), onPressed: () => _showRejectReasonDialog('Deposit', doc), child: const Text('REJECT', style: TextStyle(fontWeight: FontWeight.w900))),
                    ],
                  ]),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildWithdrawList(String status) {
    return StreamBuilder<QuerySnapshot>(
      // 🔥 orderBy hata diya
      stream: FirebaseFirestore.instance.collection('withdrawals').where('status', isEqualTo: status).snapshots(),
      builder: (ctx, snap) {
        if (!snap.hasData || snap.data!.docs.isEmpty) return const Center(child: Text('No requests found.', style: TextStyle(color: AppColors.textSecondary)));
        
        // 🔥 Local Sorting
        final docs = snap.data!.docs.toList()..sort((a, b) {
          Timestamp t1 = (a.data() as Map)['createdAt'] ?? Timestamp.now();
          Timestamp t2 = (b.data() as Map)['createdAt'] ?? Timestamp.now();
          return t2.compareTo(t1);
        });

        return ListView(
          padding: const EdgeInsets.all(16),
          children: docs.map((doc) {
            final d = doc.data() as Map<String, dynamic>;
            final upiId = d['upiId'] ?? '---';
            final amount = d['amount'] ?? 0;
            return Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: status == 'COMPLETED' ? AppColors.green : (status == 'REJECTED' ? AppColors.red : AppColors.gold))),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Payout: $amount Coins', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppColors.gold)), Text(status, style: TextStyle(color: status == 'COMPLETED' ? AppColors.green : (status == 'REJECTED' ? AppColors.red : AppColors.cyan), fontWeight: FontWeight.bold))]),
                  const SizedBox(height: 4),
                  Text('User Email: ${d['userEmail']}', style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                  const SizedBox(height: 6),
                  Row(children: [Text('Send to UPI: $upiId', style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.cyan)), IconButton(icon: const Icon(Icons.copy, size: 16, color: AppColors.cyan), onPressed: () { Clipboard.setData(ClipboardData(text: upiId)); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('UPI ID Copied!'))); })]),
                  const SizedBox(height: 8),
                  if (status == 'PENDING')
                    Row(children: [
                      ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: AppColors.green, foregroundColor: Colors.black), onPressed: () => _promptAdminPassword('Withdrawal', () => _approveWithdrawal(context, doc)), child: const Text('MARK AS PAID')),
                      const SizedBox(width: 8),
                      ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: AppColors.red, foregroundColor: Colors.white), onPressed: () => _showRejectReasonDialog('Withdrawal', doc), child: const Text('REJECT & REFUND')),
                    ]),
                ],
              ),
            );
          }).toList(),
        );
      },
    );
  }

  void _showBlockReasonDialog(DocumentSnapshot doc) {
    final reasonCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('BLOCK USER', style: TextStyle(color: AppColors.red, fontWeight: FontWeight.bold)),
        content: TextField(controller: reasonCtrl, maxLines: 3, style: const TextStyle(color: AppColors.textPrimary), decoration: const InputDecoration(labelText: 'Reason for Blocking', filled: true, fillColor: AppColors.surfaceLight, border: OutlineInputBorder())),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('CANCEL')),
          ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: AppColors.red, foregroundColor: Colors.white), onPressed: () async { final reason = reasonCtrl.text.trim(); if (reason.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please enter a reason.'))); return; } await doc.reference.update({'isBlocked': true, 'blockReason': reason}); if (ctx.mounted) { Navigator.pop(ctx); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(backgroundColor: AppColors.red, content: Text('User Blocked!'))); } }, child: const Text('BLOCK USER')),
        ],
      ),
    );
  }

  void _showUserDetailsDialog(DocumentSnapshot doc) {
    final d = doc.data() as Map<String, dynamic>;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: Text('USER DETAILS', style: TextStyle(color: AppColors.gold)),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Name: ${d['name']}'), Text('Email: ${d['email']}'),
          Text('Deposit: ${d['depositBalance'] ?? 0} Coins', style: const TextStyle(color: AppColors.gold)),
          Text('Winning: ${d['winningBalance'] ?? 0} Coins', style: const TextStyle(color: AppColors.green)),
          Text('System: ${d['systemBalance'] ?? 0} Coins', style: const TextStyle(color: AppColors.orange)),
          Text('Matches: ${d['totalMatches'] ?? 0}'), Text('Kills: ${d['totalKills'] ?? 0}'),
        ]),
        actions: [
          TextButton(onPressed: () => _showAdjustCoinsDialog(doc), child: const Text('ADJUST COINS')),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('CLOSE')),
        ]
      )
    );
  }
}

class ManageMatchResultScreen extends StatefulWidget {
  final TournamentMatch match;
  const ManageMatchResultScreen({super.key, required this.match});
  @override
  State<ManageMatchResultScreen> createState() => _ManageMatchResultScreenState();
}

class _ManageMatchResultScreenState extends State<ManageMatchResultScreen> {
  bool _isProcessing = false;

  void _submitResults(List<QueryDocumentSnapshot> entries, Map<String, TextEditingController> killsCtrl, Map<String, TextEditingController> prizeCtrl, Map<String, TextEditingController> rankCtrl) async {
    setState(() => _isProcessing = true);
    final batch = FirebaseFirestore.instance.batch();
    try {
      for (var doc in entries) {
        final data = doc.data() as Map<String, dynamic>;
        final userId = data['userId'];
        final kills = int.tryParse(killsCtrl[doc.id]!.text) ?? 0;
        final prize = double.tryParse(prizeCtrl[doc.id]!.text) ?? 0.0;
        final rank = int.tryParse(rankCtrl[doc.id]!.text) ?? 0; // 🔥 Manual Rank

        if (kills > 0 || prize > 0 || rank > 0) {
          batch.update(doc.reference, {'kills': kills, 'prizeWon': prize, 'result': prize > 0 ? 'WIN' : 'LOSS', 'rank': rank});
          final userRef = FirebaseFirestore.instance.collection('users').doc(userId);
          batch.set(userRef, {'winningBalance': FieldValue.increment(prize), 'totalBalance': FieldValue.increment(prize), 'totalKills': FieldValue.increment(kills), 'totalWins': prize > 0 ? FieldValue.increment(1) : FieldValue.increment(0)}, SetOptions(merge: true));
          
          if (prize > 0) {
            final passRef = FirebaseFirestore.instance.collection('passbook').doc();
            batch.set(passRef, {'userId': userId, 'type': 'MATCH_WON', 'amount': prize, 'title': 'Prize Won: ${widget.match.title}', 'createdAt': FieldValue.serverTimestamp()});
            final notifRef = FirebaseFirestore.instance.collection('notifications').doc();
            batch.set(notifRef, {'userId': userId, 'title': 'Match Result Published!', 'desc': 'You won $prize Coins in ${widget.match.title}.', 'cat': 'RESULT', 'color': 'green', 'createdAt': FieldValue.serverTimestamp()});
          }
        }
      }
      final matchRef = FirebaseFirestore.instance.collection('matches').doc(widget.match.id);
      
      // 🔥 Result Time Save karne ka logic
      final now = DateTime.now();
      final formattedTime = '${now.day}/${now.month}/${now.year} at ${now.hour}:${now.minute.toString().padLeft(2, '0')} ${now.hour >= 12 ? 'PM' : 'AM'}';
      
      batch.set(matchRef, {'status': 'RESULTED', 'resultTime': formattedTime, 'updatedAt': FieldValue.serverTimestamp()}, SetOptions(merge: true));

      await batch.commit();
      if (mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(backgroundColor: AppColors.green, content: Text('✅ All Results Submitted & Coins Distributed!'))); Navigator.pop(context); }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(backgroundColor: AppColors.red, content: Text('Error: $e')));
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('MANAGE RESULT'), backgroundColor: AppColors.surface),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('match_entries').where('matchId', isEqualTo: widget.match.id).snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator(color: AppColors.cyan));
          final entries = snapshot.data!.docs;
          if (entries.isEmpty) return const Center(child: Text('No players joined this match.'));

          final Map<String, TextEditingController> killsCtrl = {};
          final Map<String, TextEditingController> prizeCtrl = {};
          final Map<String, TextEditingController> rankCtrl = {};
          for (var doc in entries) { 
            if (!killsCtrl.containsKey(doc.id)) { 
              final data = doc.data() as Map<String, dynamic>; 
              killsCtrl[doc.id] = TextEditingController(text: (data['kills'] ?? 0).toString()); 
              prizeCtrl[doc.id] = TextEditingController(text: (data['prizeWon'] ?? 0).toString()); 
              rankCtrl[doc.id] = TextEditingController(text: (data['rank'] ?? 0).toString());
            } 
          }

          return Column(
            children: [
              Container(padding: const EdgeInsets.all(16), color: AppColors.surfaceLight, child: const Row(children: [Icon(Icons.info_outline, color: AppColors.gold), SizedBox(width: 8), Expanded(child: Text('Enter Kills, Prize Coins, and Rank for players.', style: TextStyle(fontSize: 12)))])),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.all(16), itemCount: entries.length,
                  itemBuilder: (ctx, i) {
                    final doc = entries[i]; final d = doc.data() as Map<String, dynamic>;
                    return Container(
                      margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.cardBorder)),
                      child: Column(children: [
                        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(d['ign'] ?? 'Unknown', style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.cyan)), Text('Slot: ${d['slot']}', style: const TextStyle(fontSize: 12, color: AppColors.textMuted))]),
                        const SizedBox(height: 10),
                        Row(children: [
                          Expanded(child: TextField(controller: rankCtrl[doc.id], keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Rank', isDense: true, border: OutlineInputBorder()))),
                          const SizedBox(width: 8),
                          Expanded(child: TextField(controller: killsCtrl[doc.id], keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Kills', isDense: true, border: OutlineInputBorder()))),
                          const SizedBox(width: 8),
                          Expanded(child: TextField(controller: prizeCtrl[doc.id], keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Prize Coins', isDense: true, border: OutlineInputBorder()))),
                        ]),
                      ]),
                    );
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: SizedBox(width: double.infinity, height: 50, child: ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: AppColors.green, foregroundColor: Colors.black), onPressed: _isProcessing ? null : () => _submitResults(entries, killsCtrl, prizeCtrl, rankCtrl), child: _isProcessing ? const CircularProgressIndicator(color: Colors.black) : const Text('FINALIZE & DISTRIBUTE COINS', style: TextStyle(fontWeight: FontWeight.w900)))),
              ),
            ],
          );
        },
      ),
    );
  }
}

class LeaderboardScreen extends StatefulWidget {
  const LeaderboardScreen({super.key});
  @override
  State<LeaderboardScreen> createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends State<LeaderboardScreen> {
  int _selectedFilter = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('TOP PLAYERS LEADERBOARD', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)), backgroundColor: AppColors.surface),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            color: AppColors.surface,
            child: Row(children: [_buildFilterPill('MOST KILLS', 0), const SizedBox(width: 8), _buildFilterPill('TOP EARNERS', 1)]),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance.collection('users').where('isAdmin', isEqualTo: false).snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return const Center(child: CircularProgressIndicator(color: AppColors.cyan));
                
                List<LeaderboardEntry> realList = [];
                for (var doc in snapshot.data!.docs) {
                  final data = doc.data() as Map<String, dynamic>;
                  realList.add(LeaderboardEntry(rank: 0, name: data['name'] ?? 'Warrior', kills: (data['totalKills'] as num?)?.toInt() ?? 0, won: ((data['winningBalance'] as num?)?.toDouble() ?? 0).toInt(), avatar: '⚡'));
                }

                if (_selectedFilter == 0) realList.sort((a, b) => b.kills.compareTo(a.kills)); 
                else realList.sort((a, b) => b.won.compareTo(a.won));

                for (int i = 0; i < realList.length; i++) { 
                  realList[i] = LeaderboardEntry(rank: i + 1, name: realList[i].name, kills: realList[i].kills, won: realList[i].won, avatar: i == 0 ? '👑' : (i == 1 ? '🥈' : (i == 2 ? '🥉' : '⚡'))); 
                }

                if (realList.isEmpty) return const Center(child: Text('No players data available yet.', style: TextStyle(color: AppColors.textSecondary)));

                final top1 = realList.isNotEmpty ? realList[0] : null; 
                final top2 = realList.length > 1 ? realList[1] : null; 
                final top3 = realList.length > 2 ? realList[2] : null; 
                final rest = realList.length > 3 ? realList.sublist(3) : <LeaderboardEntry>[];

                return ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    if (top1 != null && top2 != null && top3 != null)
                      Container(
                        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 10), 
                        margin: const EdgeInsets.only(bottom: 20), 
                        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1E293B), Color(0xFF0F172A)]), borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.cardBorder)),
                        child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, crossAxisAlignment: CrossAxisAlignment.end, children: [
                          _buildPodiumItem(top2, '🥈 Rank 2', const Color(0xFFCBD5E1), 80), 
                          _buildPodiumItem(top1, '👑 Rank 1', AppColors.gold, 110, isFirst: true), 
                          _buildPodiumItem(top3, '🥉 Rank 3', const Color(0xFFD97706), 75),
                        ]),
                      ),
                    ...rest.map((p) => Container(
                      margin: const EdgeInsets.only(bottom: 8), 
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12), 
                      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.cardBorder)),
                      child: Row(children: [
                        Container(width: 28, height: 28, decoration: BoxDecoration(color: AppColors.surfaceLight, borderRadius: BorderRadius.circular(6)), child: Center(child: Text('#${p.rank}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: AppColors.textSecondary)))),
                        const SizedBox(width: 12), 
                        Text(p.avatar, style: const TextStyle(fontSize: 22)), 
                        const SizedBox(width: 12),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(p.name, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)), 
                          Text('${p.kills} Kills', style: const TextStyle(color: AppColors.textMuted, fontSize: 11))
                        ])),
                        Text('${p.won} Coins', style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.w900, fontSize: 15)),
                      ]),
                    )),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterPill(String title, int idx) { 
    final sel = _selectedFilter == idx; 
    return Expanded(child: GestureDetector(onTap: () => setState(() => _selectedFilter = idx), child: Container(padding: const EdgeInsets.symmetric(vertical: 8), decoration: BoxDecoration(color: sel ? AppColors.cyan : AppColors.surfaceLight, borderRadius: BorderRadius.circular(8)), child: Center(child: Text(title, style: TextStyle(color: sel ? Colors.black : AppColors.textSecondary, fontWeight: FontWeight.bold, fontSize: 12)))))); 
  }

  Widget _buildPodiumItem(LeaderboardEntry p, String rankLabel, Color color, double height, {bool isFirst = false}) {
    return Column(children: [
      if (isFirst) const Icon(Icons.military_tech, color: AppColors.gold, size: 28), 
      Text(p.avatar, style: TextStyle(fontSize: isFirst ? 36 : 28)), 
      const SizedBox(height: 4), 
      Text(p.name, style: TextStyle(fontWeight: FontWeight.w900, fontSize: isFirst ? 14 : 12, color: isFirst ? AppColors.gold : AppColors.textPrimary), maxLines: 1, overflow: TextOverflow.ellipsis), 
      Text('${p.won} C', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: color)), 
      const SizedBox(height: 8), 
      Container(width: isFirst ? 90 : 75, height: height, decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: const BorderRadius.vertical(top: Radius.circular(8)), border: Border.all(color: color)), child: Center(child: Text(rankLabel, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 11))))
    ]);
  }
}

class EarnScreen extends StatelessWidget {
  const EarnScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('REFER & EARN', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)), backgroundColor: AppColors.surface),
      body: StreamBuilder<DocumentSnapshot>(
        stream: user == null ? null : FirebaseFirestore.instance.collection('users').doc(user.uid).snapshots(),
        builder: (context, snapshot) {
          String referralCode = 'ARENA2026';
          if (snapshot.hasData && snapshot.data!.exists) {
            final data = snapshot.data!.data() as Map<String, dynamic>;
            if (data['myReferralCode'] != null && data['myReferralCode'].toString().isNotEmpty) referralCode = data['myReferralCode'].toString().toUpperCase();
          }

          return SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(22), 
                  decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1E293B), Color(0xFF0F172A)], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.gold.withOpacity(0.6)), boxShadow: [BoxShadow(color: AppColors.gold.withOpacity(0.15), blurRadius: 22, spreadRadius: 2)]),
                  child: Column(children: [
                    const Icon(Icons.emoji_events, size: 64, color: AppColors.gold), 
                    const SizedBox(height: 12), 
                    Text('INVITE YOUR SQUAD', textAlign: TextAlign.center, style: GoogleFonts.orbitron(fontSize: 17, fontWeight: FontWeight.w900, color: AppColors.gold)), 
                    const SizedBox(height: 8), 
                    const Text('Share your unique referral code with your friends. Play together and dominate the arena!', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textSecondary, fontSize: 13, height: 1.4)),
                    const SizedBox(height: 20),
                    Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.cyan)), child: Row(children: [Expanded(child: Text(referralCode, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppColors.cyan, letterSpacing: 3), overflow: TextOverflow.ellipsis)), const SizedBox(width: 8), ElevatedButton.icon(style: ElevatedButton.styleFrom(backgroundColor: AppColors.cyan, foregroundColor: Colors.black), icon: const Icon(Icons.copy, size: 16), label: const Text('COPY', style: TextStyle(fontWeight: FontWeight.bold)), onPressed: () { Clipboard.setData(ClipboardData(text: referralCode)); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Referral Code Copied!'))); })])),
                  ]),
                ),
                const SizedBox(height: 16),
                Row(children: [
                  Expanded(child: ElevatedButton.icon(style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF25D366), foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)), padding: const EdgeInsets.symmetric(vertical: 12)), icon: const Icon(Icons.share, size: 18), label: const Text('WhatsApp Share', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)), onPressed: () { Clipboard.setData(ClipboardData(text: 'Join Battle Arena Esports with code: $referralCode and compete for cash prizes!')); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('WhatsApp invite message copied!'))); })),
                  const SizedBox(width: 10),
                  Expanded(child: ElevatedButton.icon(style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF0088CC), foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)), padding: const EdgeInsets.symmetric(vertical: 12)), icon: const Icon(Icons.send, size: 18), label: const Text('Telegram Share', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)), onPressed: () { Clipboard.setData(ClipboardData(text: 'Battle Arena Tournament referral code: $referralCode')); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Telegram invite link copied!'))); })),
                ]),
                const SizedBox(height: 24),
                Align(alignment: Alignment.centerLeft, child: Text('HOW TO INVITE', style: GoogleFonts.orbitron(fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.textPrimary))),
                const SizedBox(height: 12),
                _buildStepCard('1', 'Share Your Code', 'Invite your squad friends by sharing your unique code $referralCode.'),
                _buildStepCard('2', 'Friend Registers', 'Your friend installs Battle Arena and enters your referral code during sign up.'),
                _buildStepCard('3', 'Play Together', 'Team up with your squad and dominate the tournaments together!'),
                const SizedBox(height: 30),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildStepCard(String step, String title, String desc) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10), 
      padding: const EdgeInsets.all(14), 
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(10)),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(width: 28, height: 28, decoration: BoxDecoration(color: AppColors.cyan.withOpacity(0.2), shape: BoxShape.circle), child: Center(child: Text(step, style: const TextStyle(color: AppColors.cyan, fontWeight: FontWeight.w900)))), 
        const SizedBox(width: 12), 
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)), 
          const SizedBox(height: 4), 
          Text(desc, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12, height: 1.3))
        ]))
      ]),
    );
  }
}

class MenuScreen extends StatelessWidget {
  const MenuScreen({super.key});

  void _showAdminPasswordDialog(BuildContext context) {
    final pwdCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface, 
        title: const Text('ADMIN SECURITY', style: TextStyle(color: AppColors.gold, fontWeight: FontWeight.bold)),
        content: TextField(controller: pwdCtrl, obscureText: true, style: const TextStyle(color: AppColors.textPrimary), decoration: const InputDecoration(labelText: 'Enter Admin Panel Password', filled: true, fillColor: AppColors.surfaceLight, border: OutlineInputBorder())),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('CANCEL')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.gold, foregroundColor: Colors.black), 
            onPressed: () { 
              if (pwdCtrl.text.trim() == AppConfig.adminPanelPassword) { 
                Navigator.pop(ctx); 
                Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminScreen())); 
              } else { 
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(backgroundColor: AppColors.red, content: Text('Incorrect Password!'))); 
              } 
            }, 
            child: const Text('VERIFY')
          ),
        ],
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: AppColors.red.withOpacity(0.8), width: 1.5), boxShadow: [BoxShadow(color: AppColors.red.withOpacity(0.25), blurRadius: 25, spreadRadius: 2)]),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: AppColors.red.withOpacity(0.15), shape: BoxShape.circle, border: Border.all(color: AppColors.red)), child: const Icon(Icons.logout, color: AppColors.red, size: 36)),
              const SizedBox(height: 16),
              Text('CONFIRM LOGOUT', textAlign: TextAlign.center, style: GoogleFonts.orbitron(fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.red, letterSpacing: 1)),
              const SizedBox(height: 10),
              const Text('Are you sure you want to logout from Battle Arena?', textAlign: TextAlign.center, style: TextStyle(fontSize: 13, color: AppColors.textPrimary, height: 1.4)),
              const SizedBox(height: 20),
              Row(children: [
                Expanded(child: OutlinedButton(style: OutlinedButton.styleFrom(side: const BorderSide(color: AppColors.cardBorder), foregroundColor: AppColors.textPrimary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)), padding: const EdgeInsets.symmetric(vertical: 12)), onPressed: () => Navigator.pop(ctx), child: const Text('NO, STAY', style: TextStyle(fontWeight: FontWeight.bold)))),
                const SizedBox(width: 12),
                Expanded(child: ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: AppColors.red, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)), padding: const EdgeInsets.symmetric(vertical: 12)), onPressed: () async { Navigator.pop(ctx); await FirebaseAuth.instance.signOut(); appNavigatorKey.currentState?.pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginScreen()), (route) => false); }, child: const Text('YES, LOGOUT', style: TextStyle(fontWeight: FontWeight.bold)))),
              ]),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('SETTINGS & MENU', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)), backgroundColor: AppColors.surface),
      body: StreamBuilder<DocumentSnapshot>(
        stream: user == null ? null : FirebaseFirestore.instance.collection('users').doc(user.uid).snapshots(),
        builder: (context, snapshot) {
          String userName = 'Warrior';
          bool isAdmin = user?.email?.toLowerCase().trim() == AppConfig.adminEmail.toLowerCase().trim();
          if (snapshot.hasData && snapshot.data!.exists) {
            final data = snapshot.data!.data() as Map<String, dynamic>;
            userName = data['name'] ?? user?.email?.split('@').first ?? 'Warrior';
            if (data['role'] == 'admin' || data['isAdmin'] == true) isAdmin = true;
          }

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Container(
                padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: isAdmin ? AppColors.gold : AppColors.cardBorder)),
                child: Row(children: [CircleAvatar(radius: 26, backgroundColor: isAdmin ? AppColors.gold : AppColors.cyan, child: Icon(isAdmin ? Icons.admin_panel_settings : Icons.person, color: Colors.black, size: 30)), const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Text(userName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)), if (isAdmin) ...[const SizedBox(width: 6), Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(color: AppColors.gold, borderRadius: BorderRadius.circular(4)), child: const Text('ADMIN', style: TextStyle(color: Colors.black, fontWeight: FontWeight.w900, fontSize: 9)))]]), Text(user?.email ?? '', style: const TextStyle(color: AppColors.textMuted, fontSize: 12)), Text('UID: ${user?.uid.substring(0, 8) ?? '---'}', style: const TextStyle(color: AppColors.cyan, fontSize: 11))])),]),
              ),
              const SizedBox(height: 16),
              if (isAdmin) ...[Container(margin: const EdgeInsets.only(bottom: 12), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF2E1065), Color(0xFF1E1B4B)]), borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.gold, width: 1.5), boxShadow: [BoxShadow(color: AppColors.gold.withOpacity(0.2), blurRadius: 10, spreadRadius: 1)]), child: ListTile(leading: const Icon(Icons.admin_panel_settings, color: AppColors.gold, size: 28), title: const Text('ADMIN CONTROL PANEL', style: TextStyle(color: AppColors.gold, fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 1.1)), subtitle: const Text('Manage Matches, Deposits & Prizes', style: TextStyle(color: AppColors.textSecondary, fontSize: 11)), trailing: const Icon(Icons.arrow_forward_ios, size: 14, color: AppColors.gold), onTap: () => _showAdminPasswordDialog(context)))],
              _buildTile(context, Icons.account_circle, 'My Profile', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileScreen()))),
              _buildTile(context, Icons.account_balance_wallet, 'My Wallet & Passbook', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WalletScreen()))),
              _buildTile(context, Icons.receipt_long, 'Deposit & Withdrawal Statement', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TransactionStatementScreen()))),
              _buildTile(context, Icons.sports_esports, 'My Matches', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MyMatchesScreen()))),
              _buildTile(context, Icons.query_stats, 'Game Statistics', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const StatisticsScreen()))),
              _buildTile(context, Icons.report_problem, 'Issue Report & Support Tickets', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const IssueReportScreen()))),
              _buildTile(context, Icons.warning_amber, 'Important Notice & Anti-Cheat', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NoticeScreen()))),
              _buildTile(context, Icons.info_outline, 'About Us & Mission', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AboutScreen()))),
              _buildTile(context, Icons.support_agent, 'Contact Us & Help Center', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ContactScreen()))),
              _buildTile(context, Icons.help_outline, 'Frequently Asked Questions (FAQ)', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FaqScreen()))),
              _buildTile(context, Icons.privacy_tip_outlined, 'Privacy Policy', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PrivacyScreen()))),
              _buildTile(context, Icons.gavel, 'Terms & Conditions', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TermsScreen()))),
              const SizedBox(height: 10),
              _buildTile(context, Icons.logout, 'Logout', () => _showLogoutDialog(context), color: AppColors.red),
            ],
          );
        },
      ),
    );
  }

  Widget _buildTile(BuildContext context, IconData icon, String title, VoidCallback onTap, {Color color = AppColors.textPrimary}) {
    return Container(margin: const EdgeInsets.only(bottom: 8), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(10)), child: ListTile(leading: Icon(icon, color: color == AppColors.red ? AppColors.red : AppColors.cyan), title: Text(title, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 14)), trailing: const Icon(Icons.arrow_forward_ios, size: 14, color: AppColors.textMuted), onTap: onTap));
  }
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('MY PROFILE', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)), backgroundColor: AppColors.surface),
      body: StreamBuilder<DocumentSnapshot>(
        stream: user == null ? null : FirebaseFirestore.instance.collection('users').doc(user.uid).snapshots(),
        builder: (context, snapshot) {
          String name = 'Warrior', phone = 'Not provided', referralCode = 'ARENA2026';
          int totalMatches = 0, totalWins = 0;
          double system = 0, deposit = 0, winning = 0;

          if (snapshot.hasData && snapshot.data!.exists) {
            final data = snapshot.data!.data() as Map<String, dynamic>;
            name = data['name'] ?? user?.email?.split('@').first ?? 'Warrior';
            phone = data['phone'] ?? 'Not provided';
            referralCode = data['myReferralCode'] ?? 'ARENA2026';
            totalMatches = ((data['totalMatches'] ?? 0) as num).toInt();
            totalWins = ((data['totalWins'] ?? 0) as num).toInt();
            system = ((data['systemBalance'] ?? 0) as num).toDouble();
            deposit = ((data['depositBalance'] ?? 0) as num).toDouble();
            winning = ((data['winningBalance'] ?? 0) as num).toDouble();
          }
          final winRate = totalMatches > 0 ? ((totalWins / totalMatches) * 100).toStringAsFixed(1) : '0.0';

          return SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Center(
                  child: Stack(alignment: Alignment.bottomRight, children: [
                    Container(width: 90, height: 90, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: AppColors.cyan, width: 2), color: AppColors.surface), child: const Center(child: Icon(Icons.person, size: 54, color: AppColors.cyan))),
                    Container(padding: const EdgeInsets.all(4), decoration: const BoxDecoration(color: AppColors.gold, shape: BoxShape.circle), child: const Icon(Icons.verified, size: 18, color: Colors.black)),
                  ]),
                ),
                const SizedBox(height: 10),
                Text(name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3), decoration: BoxDecoration(color: AppColors.cyan.withOpacity(0.15), borderRadius: BorderRadius.circular(12)), child: const Text('VERIFIED WARRIOR • FAIR PLAY ACTIVE', style: TextStyle(color: AppColors.cyan, fontWeight: FontWeight.bold, fontSize: 11))),
                const SizedBox(height: 24),
                
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.cardBorder)),
                  child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                    _buildMiniStat('${deposit.toStringAsFixed(0)}', 'Deposit', AppColors.gold),
                    _buildMiniStat('${winning.toStringAsFixed(0)}', 'Winning', AppColors.green),
                    _buildMiniStat('${system.toStringAsFixed(0)}', 'System', AppColors.orange),
                  ]),
                ),
                const SizedBox(height: 16),

                _buildLockedField('In-Game Nickname', name, Icons.sports_esports),
                _buildLockedField('Registered Email', user?.email ?? 'Not available', Icons.email),
                _buildLockedField('Mobile Number', phone, Icons.phone_android),
                _buildLockedField('Battle Arena UID', user?.uid ?? 'BA-000000', Icons.fingerprint),
                _buildLockedField('My Referral Code', referralCode, Icons.card_giftcard),
                const SizedBox(height: 14),
                Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: AppColors.surfaceLight, borderRadius: BorderRadius.circular(10)), child: const Row(children: [Icon(Icons.lock, size: 18, color: AppColors.gold), SizedBox(width: 8), Expanded(child: Text('Profile details are permanently verified & locked to prevent multi-accounting. Contact support to update.', style: TextStyle(color: AppColors.textMuted, fontSize: 11, height: 1.3)))])),
                const SizedBox(height: 24),
                Align(alignment: Alignment.centerLeft, child: Text('CAREER HIGHLIGHTS', style: GoogleFonts.orbitron(fontSize: 14, fontWeight: FontWeight.bold))),
                const SizedBox(height: 10),
                Row(children: [_buildMiniStat(totalMatches.toString(), 'Matches Played', AppColors.cyan), const SizedBox(width: 10), _buildMiniStat(totalWins.toString(), 'Wins', AppColors.gold), const SizedBox(width: 10), _buildMiniStat('$winRate%', 'Win Rate', AppColors.green)]),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildLockedField(String label, String value, IconData icon) {
    return Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.cardBorder)), child: Row(children: [Icon(icon, size: 20, color: AppColors.textMuted), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: const TextStyle(fontSize: 11, color: AppColors.textMuted)), const SizedBox(height: 2), Text(value, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.textPrimary))])), const Icon(Icons.lock_outline, size: 16, color: AppColors.textMuted)]));
  }

  Widget _buildMiniStat(String val, String label, Color c) {
    return Expanded(child: Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(10)), child: Column(children: [Text(val, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: c)), const SizedBox(height: 2), Text(label, style: const TextStyle(fontSize: 10, color: AppColors.textSecondary))])));
  }
}

class MyMatchesScreen extends StatelessWidget {
  const MyMatchesScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return const Scaffold(body: Center(child: Text('Login Required')));
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: AppColors.background,
        appBar: AppBar(title: const Text('MY MATCHES', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)), backgroundColor: AppColors.surface, bottom: const TabBar(indicatorColor: AppColors.cyan, labelColor: AppColors.cyan, unselectedLabelColor: AppColors.textSecondary, tabs: [Tab(text: 'UPCOMING'), Tab(text: 'LIVE'), Tab(text: 'HISTORY')])),
        body: StreamBuilder<DocumentSnapshot>(
          stream: FirebaseFirestore.instance.collection('users').doc(user.uid).snapshots(),
          builder: (context, userSnap) {
            List<String> joinedIds = [];
            if (userSnap.hasData && userSnap.data!.exists) { joinedIds = List<String>.from((userSnap.data!.data() as Map)['joinedMatches'] ?? []); }
            if (joinedIds.isEmpty) return const Center(child: Text('No matches joined yet.', style: TextStyle(color: AppColors.textSecondary)));

            return StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance.collection('matches').snapshots(),
              builder: (context, matchSnap) {
                final Map<String, Map<String, dynamic>> fsMatches = {};
                if (matchSnap.hasData) { 
                  for (var doc in matchSnap.data!.docs) { 
                    fsMatches[doc.id] = doc.data() as Map<String, dynamic>; 
                  } 
                }
                
                final myMatches = <TournamentMatch>[];
                for(var id in joinedIds) {
                  if(fsMatches.containsKey(id)) {
                    final data = fsMatches[id]!;
                    final mData = kGameModes.firstWhere((g) => g.title == data['mode'], orElse: () => kGameModes.first);
                    
                    // 🔥 Yahan isDeleted filter nahi lagaya taaki result tab se match delete na ho
                    myMatches.add(TournamentMatch(
                      id: id, title: data['title'] ?? '', mode: data['mode'] ?? '', map: data['map'] ?? '', version: 'FF MAX', banner: data['banner'] ?? mData.banner, 
                      prizePool: (data['prizePool'] as num?)?.toInt() ?? 0, perKill: (data['perKill'] as num?)?.toInt() ?? 0, entryFee: (data['entryFee'] as num?)?.toInt() ?? 0, 
                      totalSlots: (data['totalSlots'] as num?)?.toInt() ?? 48, filledSlots: (data['filledSlots'] as num?)?.toInt() ?? 0, matchTime: data['matchTime'] ?? '', 
                      status: data['status'] ?? 'UPCOMING', roomId: data['roomId'] ?? 'TBD', roomPassword: data['roomPassword'] ?? 'TBD', rejectReason: data['cancelReason'], resultTime: data['resultTime']
                    ));
                  }
                }

                return TabBarView(children: [
                  _buildMatchList(myMatches.where((m) => m.status == 'UPCOMING').toList(), 'No upcoming matches.'),
                  _buildMatchList(myMatches.where((m) => m.status == 'ONGOING').toList(), 'No live matches currently.'),
                  _buildMatchHistory(context, myMatches.where((m) => m.status == 'RESULTED' || m.status == 'CANCELLED').toList()),
                ]);
              },
            );
          },
        ),
      ),
    );
  }

  Widget _buildMatchList(List<TournamentMatch> matches, String emptyMsg) {
    if (matches.isEmpty) return Center(child: Text(emptyMsg, style: const TextStyle(color: AppColors.textSecondary)));
    return ListView.builder(padding: const EdgeInsets.all(16), itemCount: matches.length, itemBuilder: (ctx, i) => TournamentMatchCard(match: matches[i]));
  }

  Widget _buildMatchHistory(BuildContext context, List<TournamentMatch> matches) {
    if (matches.isEmpty) return const Center(child: Text('No match history available.', style: TextStyle(color: AppColors.textSecondary)));
    return ListView.builder(padding: const EdgeInsets.all(16), itemCount: matches.length, itemBuilder: (ctx, i) => _MatchHistoryCard(match: matches[i], index: i + 1));
  }
}

class _MatchHistoryCard extends StatelessWidget {
  final TournamentMatch match;
  final int index;
  const _MatchHistoryCard({required this.match, required this.index});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('match_entries').where('matchId', isEqualTo: match.id).where('userId', isEqualTo: user?.uid).limit(1).snapshots(),
      builder: (context, snap) {
        bool isWin = false; int kills = 0; int rank = 0; double prizeWon = 0;
        if (snap.hasData && snap.data!.docs.isNotEmpty) {
          final data = snap.data!.docs.first.data() as Map<String, dynamic>;
          isWin = data['result'] == 'WIN'; kills = (data['kills'] as num?)?.toInt() ?? 0; rank = (data['rank'] as num?)?.toInt() ?? 0; prizeWon = (data['prizeWon'] as num?)?.toDouble() ?? 0;
        }

        return InkWell(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MatchResultDetailScreen(match: match))),
          child: Container(
            margin: const EdgeInsets.only(bottom: 12), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.cardBorder)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), decoration: BoxDecoration(color: AppColors.surfaceLight, borderRadius: const BorderRadius.vertical(top: Radius.circular(12))), child: Row(children: [Text('$index', style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.textMuted)), const SizedBox(width: 12), Expanded(child: Text(match.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: AppColors.cyan))), Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2), decoration: BoxDecoration(color: match.status == 'CANCELLED' ? AppColors.orange.withOpacity(0.2) : (isWin ? AppColors.green.withOpacity(0.2) : AppColors.red.withOpacity(0.2)), borderRadius: BorderRadius.circular(4)), child: Text(match.status == 'CANCELLED' ? 'CANCELLED' : (isWin ? 'WIN' : 'LOSS'), style: TextStyle(color: match.status == 'CANCELLED' ? AppColors.orange : (isWin ? AppColors.green : AppColors.red), fontWeight: FontWeight.bold, fontSize: 10)))])),
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(match.matchTime, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)), const SizedBox(height: 4), Row(children: [const Icon(Icons.gps_fixed, size: 12, color: AppColors.textMuted), const SizedBox(width: 4), Text('${kills > 0 ? kills : "-"} Kills', style: const TextStyle(fontSize: 11, color: AppColors.gold)), const SizedBox(width: 12), const Icon(Icons.emoji_events, size: 12, color: AppColors.textMuted), const SizedBox(width: 4), Text('Rank ${rank > 0 ? rank : "-"}', style: const TextStyle(fontSize: 11, color: AppColors.cyan))])]),
                    Row(children: [Column(children: [const Text('Paid', style: TextStyle(fontSize: 10, color: AppColors.textMuted)), Text('${match.entryFee} C', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppColors.textPrimary))]), const SizedBox(width: 20), Column(children: [const Text('Won', style: TextStyle(fontSize: 10, color: AppColors.textMuted)), Text('${prizeWon > 0 ? prizeWon.toStringAsFixed(0) : 0} C', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: isWin ? AppColors.green : AppColors.textSecondary))])]),
                  ]),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class MatchResultDetailScreen extends StatelessWidget {
  final TournamentMatch match;
  const MatchResultDetailScreen({super.key, required this.match});
  
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    
    if (match.status == 'CANCELLED') {
      return Scaffold(
        backgroundColor: AppColors.background,
        appBar: AppBar(title: const Text('MATCH CANCELLED'), backgroundColor: AppColors.surface),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.cancel, color: AppColors.red, size: 80),
              const SizedBox(height: 20),
              Text('MATCH CANCELLED', style: GoogleFonts.orbitron(fontSize: 22, color: AppColors.red, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              Text('Reason: ${match.rejectReason ?? 'Server Issue'}', textAlign: TextAlign.center, style: const TextStyle(color: AppColors.textPrimary, fontSize: 16)),
              const SizedBox(height: 10),
              const Text('All entry fees have been refunded to your Deposit Balance.', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textSecondary)),
            ]),
          ),
        )
      );
    }

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('MATCH RESULT', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)), backgroundColor: AppColors.surface, elevation: 0),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('match_entries').where('matchId', isEqualTo: match.id).snapshots(),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: AppColors.cyan));
          
          final allEntries = snap.data!.docs.map((d) => d.data() as Map<String, dynamic>).toList();
          if (allEntries.isEmpty) return const Center(child: Text('Result data not found.', style: TextStyle(color: AppColors.textSecondary)));

          final myEntry = allEntries.firstWhere((e) => e['userId'] == user?.uid, orElse: () => {});
          final bool isWin = myEntry['result'] == 'WIN'; final int myKills = (myEntry['kills'] as num?)?.toInt() ?? 0; final int myRank = (myEntry['rank'] as num?)?.toInt() ?? 0; final double myPrize = (myEntry['prizeWon'] as num?)?.toDouble() ?? 0.0;

          allEntries.sort((a, b) {
            final rA = (a['rank'] as num?)?.toInt() ?? 999; final rB = (b['rank'] as num?)?.toInt() ?? 999;
            if (rA != rB) return rA.compareTo(rB);
            final kA = (a['kills'] as num?)?.toInt() ?? 0; final kB = (b['kills'] as num?)?.toInt() ?? 0;
            return kB.compareTo(kA);
          });

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // 1. MATCH DETAILS CARD
                Container(
                  decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.cardBorder)),
                  child: Column(
                    children: [
                      // 🔥 Banner Fix (16/9 size)
                      ClipRRect(
                        borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
                        child: AspectRatio(
                          aspectRatio: 16 / 9,
                          child: Image.asset(
                            match.banner,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(color: AppColors.surfaceLight),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            Text(match.title, textAlign: TextAlign.center, style: GoogleFonts.orbitron(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.gold)),
                            const SizedBox(height: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(color: AppColors.surfaceLight, borderRadius: BorderRadius.circular(8), border: Border.all(color: AppColors.cardBorder)),
                              child: Text(match.resultTime != null ? 'Result on: ${match.resultTime}' : 'Organized on ${match.matchTime}', style: const TextStyle(fontSize: 12, color: AppColors.textPrimary, fontWeight: FontWeight.bold)),
                            ),
                            const SizedBox(height: 16),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                _buildMatchStat('Prize Pool', '${match.prizePool}', AppColors.gold),
                                _buildMatchStat('Per Kill', '${match.perKill}', AppColors.cyan),
                                _buildMatchStat('Entry Fee', '${match.entryFee}', AppColors.green),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // 2. USER'S PERSONAL RESULT HIGHLIGHT
                if (myEntry.isNotEmpty) ...[
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: isWin ? [AppColors.green.withOpacity(0.2), AppColors.surface] : [AppColors.red.withOpacity(0.2), AppColors.surface]),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: isWin ? AppColors.green : AppColors.red),
                    ),
                    child: Column(
                      children: [
                        Text(isWin ? 'BOOYAH! YOU WON 🏆' : 'BETTER LUCK NEXT TIME 💔', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: isWin ? AppColors.green : AppColors.red, letterSpacing: 1)),
                        const SizedBox(height: 20),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            _buildUserStat('YOUR RANK', myRank > 0 ? '#$myRank' : '-', AppColors.gold),
                            _buildUserStat('KILLS', myKills.toString(), AppColors.cyan),
                            _buildUserStat('PRIZE', '${myPrize.toStringAsFixed(0)} C', AppColors.green),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                ],

                // 3. REST RESULT TABLE (GameX Style)
                Container(
                  decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.cardBorder)),
                  child: Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
                        decoration: const BoxDecoration(color: Color(0xFF1E3A8A), borderRadius: BorderRadius.vertical(top: Radius.circular(12))),
                        child: const Row(
                          children: [
                            SizedBox(width: 30, child: Text('#', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12), textAlign: TextAlign.center)),
                            Expanded(flex: 3, child: Text('PLAYER NAME', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12))),
                            Expanded(flex: 1, child: Text('KILLS', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12), textAlign: TextAlign.center)),
                            Expanded(flex: 1, child: Text('PRIZE', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12), textAlign: TextAlign.right)),
                          ],
                        ),
                      ),
                      ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: allEntries.length,
                        itemBuilder: (context, index) {
                          final player = allEntries[index];
                          final pRank = (player['rank'] as num?)?.toInt() ?? 0;
                          final pKills = (player['kills'] as num?)?.toInt() ?? 0;
                          final pPrize = (player['prizeWon'] as num?)?.toDouble() ?? 0.0;
                          final isMe = player['userId'] == user?.uid;
                          final pUid = player['gameUid'] ?? '---';
                          final pIgn = player['ign'] ?? 'Unknown';

                          return Container(
                            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
                            decoration: BoxDecoration(
                              color: isMe ? AppColors.cyan.withOpacity(0.1) : (index % 2 == 0 ? AppColors.surface : AppColors.surfaceLight.withOpacity(0.3)),
                              border: const Border(bottom: BorderSide(color: AppColors.cardBorder, width: 0.5)),
                            ),
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 30,
                                  child: Text(
                                    '$pRank',
                                    style: TextStyle(color: pRank == 1 ? AppColors.gold : (isMe ? AppColors.cyan : AppColors.textPrimary), fontWeight: FontWeight.bold, fontSize: 13),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                                Expanded(
                                  flex: 3,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Expanded(
                                            child: Text(
                                              pIgn,
                                              style: TextStyle(color: isMe ? AppColors.cyan : AppColors.textPrimary, fontWeight: FontWeight.bold, fontSize: 13),
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                          if (isMe)
                                            Container(
                                              margin: const EdgeInsets.only(left: 4),
                                              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                                              decoration: BoxDecoration(color: AppColors.cyan, borderRadius: BorderRadius.circular(4)),
                                              child: const Text('YOU', style: TextStyle(color: Colors.black, fontSize: 8, fontWeight: FontWeight.w900)),
                                            ),
                                        ],
                                      ),
                                      Text('UID: $pUid', style: const TextStyle(color: AppColors.textMuted, fontSize: 10)),
                                    ],
                                  ),
                                ),
                                Expanded(
                                  flex: 1,
                                  child: Text(
                                    '$pKills',
                                    style: const TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.bold, fontSize: 13),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                                Expanded(
                                  flex: 1,
                                  child: Text(
                                    pPrize > 0 ? '${pPrize.toStringAsFixed(0)}' : '0',
                                    style: TextStyle(color: pPrize > 0 ? AppColors.green : AppColors.textMuted, fontWeight: FontWeight.bold, fontSize: 13),
                                    textAlign: TextAlign.right,
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 30),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildMatchStat(String title, String val, Color c) {
    return Column(
      children: [
        Text(title, style: const TextStyle(color: AppColors.textMuted, fontSize: 11, fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Text(val, style: TextStyle(color: c, fontSize: 16, fontWeight: FontWeight.w900)),
      ],
    );
  }

  Widget _buildUserStat(String title, String value, Color color) {
    return Column(
      children: [
        Text(title, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: color)),
      ],
    );
  }
}

class TransactionStatementScreen extends StatefulWidget {
  const TransactionStatementScreen({super.key});
  @override
  State<TransactionStatementScreen> createState() => _TransactionStatementScreenState();
}

class _TransactionStatementScreenState extends State<TransactionStatementScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  @override
  void initState() { super.initState(); _tabController = TabController(length: 2, vsync: this); }
  @override
  void dispose() { _tabController.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('TRANSACTION STATEMENT', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)), backgroundColor: AppColors.surface, bottom: TabBar(controller: _tabController, indicatorColor: AppColors.cyan, labelColor: AppColors.cyan, unselectedLabelColor: AppColors.textSecondary, tabs: const [Tab(text: 'DEPOSITS'), Tab(text: 'WITHDRAWALS')])),
      body: TabBarView(controller: _tabController, children: [_buildList(user, 'deposit_requests', 'DEP'), _buildList(user, 'withdrawals', 'WTH')]),
    );
  }

  Widget _buildList(User? user, String collection, String prefix) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection(collection).where('userId', isEqualTo: user?.uid).snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator(color: AppColors.cyan));
        final docs = snapshot.data!.docs.toList();
        docs.sort((a, b) { Timestamp t1 = (a.data() as Map)['timestamp'] ?? (a.data() as Map)['createdAt'] ?? Timestamp.now(); Timestamp t2 = (b.data() as Map)['timestamp'] ?? (b.data() as Map)['createdAt'] ?? Timestamp.now(); return t2.compareTo(t1); });
        if (docs.isEmpty) return const Center(child: Text('No transactions found.', style: TextStyle(color: AppColors.textSecondary)));
        
        return ListView.builder(
          padding: const EdgeInsets.all(16), itemCount: docs.length,
          itemBuilder: (ctx, i) {
            final d = docs[i].data() as Map<String, dynamic>;
            final status = (d['status'] ?? 'PENDING').toString().toUpperCase();
            final amount = (d['amount'] as num?)?.toDouble() ?? 0.0;
            final txnId = '$prefix-${docs[i].id.substring(0, 6).toUpperCase()}';
            final rejectReason = d['rejectReason'] as String?;

            return Container(
              margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.cardBorder)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(txnId, style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.cyan, fontSize: 12)), const SizedBox(height: 4), Text(collection == 'deposit_requests' ? 'Deposit' : 'Withdrawal', style: const TextStyle(fontWeight: FontWeight.bold)), Text('${amount.toStringAsFixed(0)} Coins', style: const TextStyle(fontSize: 16, color: AppColors.gold, fontWeight: FontWeight.w900))]),
                    Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: status == 'APPROVED' || status == 'COMPLETED' ? AppColors.green : (status == 'REJECTED' ? AppColors.red : AppColors.orange), borderRadius: BorderRadius.circular(20)), child: Text(status == 'APPROVED' || status == 'COMPLETED' ? 'SUCCESS' : status, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold))),
                  ]),
                  if (status == 'REJECTED' && rejectReason != null && rejectReason.isNotEmpty)
                    Padding(padding: const EdgeInsets.only(top: 10), child: Container(width: double.infinity, padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: AppColors.red.withOpacity(0.1), borderRadius: BorderRadius.circular(6), border: Border.all(color: AppColors.red.withOpacity(0.3))), child: Text('Reason: $rejectReason', style: const TextStyle(color: AppColors.red, fontSize: 11, fontStyle: FontStyle.italic)))),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

class IssueReportScreen extends StatefulWidget {
  const IssueReportScreen({super.key});
  @override
  State<IssueReportScreen> createState() => _IssueReportScreenState();
}

class _IssueReportScreenState extends State<IssueReportScreen> {
  final _subjectCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  String _selectedCategory = 'Payment Issue';
  bool _isSubmitting = false;
  final List<String> _categories = ['Payment Issue', 'Withdrawal Issue', 'Match/Game Issue', 'Technical Bug', 'Account Issue', 'Other'];

  Future<void> _submitTicket() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    if (_subjectCtrl.text.isEmpty || _descCtrl.text.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please fill all fields'))); return; }
    setState(() => _isSubmitting = true);
    try {
      final ticketId = 'BA-TKT-${DateTime.now().millisecondsSinceEpoch.toString().substring(5)}';
      await FirebaseFirestore.instance.collection('support_tickets').doc(ticketId).set({'ticketId': ticketId, 'userId': user.uid, 'userEmail': user.email, 'category': _selectedCategory, 'subject': _subjectCtrl.text.trim(), 'description': _descCtrl.text.trim(), 'status': 'Submitted', 'createdAt': FieldValue.serverTimestamp(), 'adminRemark': ''});
      _subjectCtrl.clear(); _descCtrl.clear();
      if (mounted) showCustomDialog(context: context, title: 'TICKET SUBMITTED 🎟️', message: 'Your support ticket $ticketId has been submitted successfully.', icon: Icons.support_agent, color: AppColors.green);
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e'))); } finally { if (mounted) setState(() => _isSubmitting = false); }
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('ISSUE REPORT & SUPPORT', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)), backgroundColor: AppColors.surface),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('Submit a New Ticket', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.cyan)),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(value: _selectedCategory, decoration: InputDecoration(labelText: 'Issue Category', filled: true, fillColor: AppColors.surfaceLight, border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))), items: _categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(), onChanged: (val) => setState(() => _selectedCategory = val!)),
            const SizedBox(height: 12),
            TextField(controller: _subjectCtrl, decoration: InputDecoration(labelText: 'Subject', filled: true, fillColor: AppColors.surfaceLight, border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)))),
            const SizedBox(height: 12),
            TextField(controller: _descCtrl, maxLines: 4, decoration: InputDecoration(labelText: 'Describe your problem', filled: true, fillColor: AppColors.surfaceLight, border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)))),
            const SizedBox(height: 16),
            ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: AppColors.cyan, foregroundColor: Colors.black, padding: const EdgeInsets.symmetric(vertical: 14)), onPressed: _isSubmitting ? null : _submitTicket, child: _isSubmitting ? const CircularProgressIndicator(color: Colors.black) : const Text('SUBMIT TICKET', style: TextStyle(fontWeight: FontWeight.w900))),
            const SizedBox(height: 30),
            const Text('My Submitted Tickets', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.gold)),
            const SizedBox(height: 12),
            StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance.collection('support_tickets').where('userId', isEqualTo: user?.uid).snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return const SizedBox();
                if (snapshot.data!.docs.isEmpty) return const Text('No tickets submitted yet.', style: TextStyle(color: AppColors.textSecondary));
                final docs = snapshot.data!.docs.toList();
                docs.sort((a, b) { Timestamp t1 = (a.data() as Map)['createdAt'] ?? Timestamp.now(); Timestamp t2 = (b.data() as Map)['createdAt'] ?? Timestamp.now(); return t2.compareTo(t1); });
                
                return Column(
                  children: docs.map((doc) {
                    final d = doc.data() as Map<String, dynamic>; final status = d['status'] ?? 'Submitted'; Color statusColor = status == 'Resolved' ? AppColors.green : (status == 'Rejected' ? AppColors.red : AppColors.orange);
                    return Container(
                      margin: const EdgeInsets.only(bottom: 8), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(8), border: Border.all(color: AppColors.cardBorder)),
                      child: ExpansionTile(
                        title: Text(d['subject'] ?? '', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)), subtitle: Text('Ticket: ${d['ticketId']}', style: const TextStyle(fontSize: 11, color: AppColors.cyan)), trailing: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: statusColor.withOpacity(0.2), borderRadius: BorderRadius.circular(4)), child: Text(status, style: TextStyle(color: statusColor, fontSize: 10, fontWeight: FontWeight.bold))),
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(14),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              const Text('Description:', style: TextStyle(fontSize: 12, color: AppColors.textSecondary)), Text(d['description'] ?? '', style: const TextStyle(fontSize: 13)),
                              if (d['adminRemark'] != null && d['adminRemark'].toString().isNotEmpty) ...[
                                const SizedBox(height: 12), Container(padding: const EdgeInsets.all(10), width: double.infinity, decoration: BoxDecoration(color: AppColors.surfaceLight, borderRadius: BorderRadius.circular(8), border: Border.all(color: AppColors.green.withOpacity(0.5))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Admin Reply:', style: TextStyle(fontSize: 11, color: AppColors.green, fontWeight: FontWeight.bold)), Text(d['adminRemark'], style: const TextStyle(fontSize: 12))])),
                              ],
                            ]),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class StatisticsScreen extends StatelessWidget {
  const StatisticsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('GAME STATISTICS', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)), backgroundColor: AppColors.surface),
      body: StreamBuilder<DocumentSnapshot>(
        stream: user == null ? null : FirebaseFirestore.instance.collection('users').doc(user.uid).snapshots(),
        builder: (context, snapshot) {
          int matches = 0; int wins = 0; int kills = 0; double wonPrize = 0.0;
          if (snapshot.hasData && snapshot.data!.exists) { final data = snapshot.data!.data() as Map<String, dynamic>; matches = ((data['totalMatches'] ?? 0) as num).toInt(); wins = ((data['totalWins'] ?? 0) as num).toInt(); kills = ((data['totalKills'] ?? 0) as num).toInt(); wonPrize = ((data['winningBalance'] ?? 0) as num).toDouble(); }
          final avgKills = matches > 0 ? (kills / matches).toStringAsFixed(2) : '0.00';
          final winRate = matches > 0 ? ((wins / matches) * 100).toStringAsFixed(1) : '0.0';
          
          return SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(
                  padding: const EdgeInsets.all(18), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1E293B), Color(0xFF0F172A)]), borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.cyan.withOpacity(0.4))),
                  child: Column(children: [
                    const Text('TOTAL PRIZE WON', style: TextStyle(color: AppColors.textSecondary, fontSize: 12, fontWeight: FontWeight.bold)), const SizedBox(height: 6), Text('${wonPrize.toStringAsFixed(2)} Coins', style: GoogleFonts.orbitron(fontSize: 28, fontWeight: FontWeight.w900, color: AppColors.gold)), const SizedBox(height: 14),
                    Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [_buildHeaderCol('Matches', matches.toString()), _buildHeaderCol('Victories', wins.toString()), _buildHeaderCol('Total Kills', kills.toString())]),
                  ]),
                ),
                const SizedBox(height: 20),
                _buildStatCard('Total Matches Played', matches.toString(), Icons.gamepad, AppColors.cyan),
                _buildStatCard('Match Wins (Booyah)', wins.toString(), Icons.emoji_events, AppColors.gold),
                _buildStatCard('Total Eliminations (Kills)', kills.toString(), Icons.whatshot, AppColors.red),
                _buildStatCard('Average Kills / Match', avgKills, Icons.gps_fixed, AppColors.green),
                _buildStatCard('Win Rate Ratio', '$winRate%', Icons.pie_chart, AppColors.cyan),
                _buildStatCard('Favorite Mode', 'Clash Squad 4v4', Icons.shield, AppColors.gold),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildHeaderCol(String label, String val) { return Column(children: [Text(val, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppColors.cyan)), Text(label, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary))]); }

  Widget _buildStatCard(String label, String val, IconData icon, Color c) {
    return Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.cardBorder)), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Row(children: [Icon(icon, color: c, size: 20), const SizedBox(width: 12), Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold))]), Text(val, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: c))]));
  }
}

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('NOTIFICATIONS', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)), backgroundColor: AppColors.surface),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('notifications').snapshots(),
        builder: (ctx, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: AppColors.cyan));
          final docs = snap.data!.docs.where((d) { final target = (d.data() as Map)['userId'] ?? 'ALL'; return target == 'ALL' || target == user?.uid; }).toList();
          docs.sort((a, b) { Timestamp t1 = (a.data() as Map)['createdAt'] ?? Timestamp.now(); Timestamp t2 = (b.data() as Map)['createdAt'] ?? Timestamp.now(); return t2.compareTo(t1); });
          if (docs.isEmpty) return const Center(child: Text('No notifications yet.', style: TextStyle(color: AppColors.textSecondary)));
          
          return ListView.builder(
            padding: const EdgeInsets.all(16), itemCount: docs.length,
            itemBuilder: (ctx, i) {
              final data = docs[i].data() as Map<String, dynamic>;
              final catColor = data['color'] == 'gold' ? AppColors.gold : (data['color'] == 'green' ? AppColors.green : (data['color'] == 'red' ? AppColors.red : AppColors.cyan));
              final time = (data['createdAt'] as Timestamp?)?.toDate();
              return Container(
                margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.cardBorder)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3), decoration: BoxDecoration(color: catColor.withOpacity(0.15), borderRadius: BorderRadius.circular(6)), child: Text(data['cat'] ?? 'SYSTEM', style: TextStyle(color: catColor, fontWeight: FontWeight.w900, fontSize: 10))),
                    Text(time != null ? '${time.hour}:${time.minute.toString().padLeft(2, '0')}' : 'Just now', style: const TextStyle(color: AppColors.textMuted, fontSize: 11)),
                  ]),
                  const SizedBox(height: 8),
                  Text(data['title'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  const SizedBox(height: 4),
                  Text(data['desc'] ?? '', style: const TextStyle(color: AppColors.textSecondary, fontSize: 12, height: 1.4)),
                ]),
              );
            },
          );
        },
      ),
    );
  }
}

class NoticeScreen extends StatelessWidget {
  const NoticeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final rules = [
      {'title': '⚠️ HACKERS & POV RULES UPDATE ⚠️', 'desc': 'har player ko apna POV / Screen Recording match ke baad kam se kam 24 HOURS tak rakhna zaruri hai.\n\nmanagement aapse 24 hours ke andar kabhi bhi POV Ban karke maang sakte hain, isliye usse delete karna allowed nahi hoga agar us match ka pov nhi hua toh ban.\n\nKabhi-kabhi host turant POV nahi maangte, lekin phir bhi aapko apni recording 24 hours tak safe rakhni hogi.\n\nAgar kisi player ko DEVICE CHECK ke liye bulaya jata hai, toh usse SAME PHONE me aana hoga jisme usne match khela tha.'},
      {'title': '✅ Rules for Safe Environment', 'desc': 'Replay mobile me available hona chahiye.\nSirf Free Fire MAX se khelna h free fire normal allowed nahi hoga.\n\nJo bhi player hacks ya unfair files use karte hue pakda gaya, usse DIRECT BAN kiya jayega. No Unban Chance.\n\nAgar kisi normal match me aapse 2 baar POV manga ja chuka hai, toh 3rd baar POV maangne par agar aap provide nahi karte ho, toh DIRECT BAN hoga.\n\nPOV sirf proper SCREEN RECORDING hona chahiye, replay not allow.\n\nPrize tabhi milega jab aap clip aur POV me FAIR gameplay dikhaoge. Otherwise – NO PRIZE.'},
      {'title': '📌 IMPORTANT RULES', 'desc': 'Every Player Of FreeFire Game Name (Not User) Per Day Match Join Limit Is 10 in LW/CS ONLY (Whether You Play Or Match is Cancel Doesn\'t Matter). IF YOU EXCEED IT THEN ₹50 PENALTY + Every Extra 5 Match Again -50 Penalty.\n\nAND RECORDING IS MANDATORY FOR EVIDENCE PURPOSE, ATLEAST YOU SHOULD HAVE RECORDING OF LAST 24 HOURS.\n\nAND IF SOMEONE PLAYED WITH SAME GAME ID WITH MULTIPLE ACCOUNT THEN THAT ACCOUNT WILL BE BANNED ... WITHOUT ANY WARNING!! ⚠️\n\nRegistering with Multiple Names while Joining like user1/user2 will NOT be accepted. Random / Random By not accepted. ONLY 1 NAME AT A TIME. PENALTY = 50'},
    ];

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('NOTICE & RULES', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)), backgroundColor: AppColors.surface),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.cardBorder)),
            child: const Row(children: [Icon(Icons.warning, color: AppColors.red, size: 28), SizedBox(width: 12), Expanded(child: Text('OFFICIAL BATTLE ARENA ANTI-CHEAT & ESPORTS CODE OF CONDUCT', style: TextStyle(color: AppColors.red, fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 0.5)))]),
          ),
          const SizedBox(height: 16),
          ...rules.map((r) => Container(
            margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.cardBorder)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(r['title']!, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: AppColors.cyan)), const SizedBox(height: 8), Text(r['desc']!, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12, height: 1.5))]),
          )),
        ],
      ),
    );
  }
}

class TermsScreen extends StatelessWidget {
  const TermsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final terms = [
      {'icon': Icons.person, 'color': Colors.blue, 'title': 'Eligibility (18+ Age Requirement)', 'rule': 'Rule #1', 'desc': 'By registering on and using this platform, you confirm that you are at least 18 years of age. Participation in any match, contest, or paid activity is strictly restricted to users who meet this minimum age requirement. The platform reserves the right to suspend or terminate accounts found to be in violation of this condition without prior notice.'},
      {'icon': Icons.block, 'color': Colors.red, 'title': 'No Cancellation After Entry', 'rule': 'Rule #2', 'desc': 'User can not cancel their entry once joined any paid match.'},
      {'icon': Icons.access_time, 'color': Colors.orange, 'title': 'Late Entry Policy', 'rule': 'Rule #3', 'desc': 'If you are failed to enter the match before the given match start time, then you will not be eligible for a refund.'},
      {'icon': Icons.gavel, 'color': Colors.purple, 'title': 'Anti-Cheat Policy', 'rule': 'Rule #4', 'desc': 'If you are found using any kind of hack or team up technique then your account will be blocked and you will not get any kind of withdrawal or refund.'},
      {'icon': Icons.warning, 'color': Colors.amber, 'title': 'Multiple Account Policy', 'rule': 'Rule #5', 'desc': 'Using multiple IDs on our app is prohibited. If found using multiple IDs then we will ban your ID from our app.'},
      {'icon': Icons.currency_exchange, 'color': Colors.green, 'title': 'Match Cancellation & Refund Policy', 'rule': 'Rule #6', 'desc': 'If any match is cancelled due to any reason from our side, then users will get their match fee refunded in their account.'},
    ];
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Terms & Conditions', style: TextStyle(fontWeight: FontWeight.w900)), backgroundColor: AppColors.surface),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Please read these terms carefully before participating', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
          const SizedBox(height: 16),
          ...terms.map((t) => Container(
            margin: const EdgeInsets.only(bottom: 16), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.cardBorder)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(children: [
                    CircleAvatar(backgroundColor: (t['color'] as Color).withOpacity(0.2), child: Icon(t['icon'] as IconData, color: t['color'] as Color)),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(t['title'] as String, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)), Text(t['rule'] as String, style: const TextStyle(color: AppColors.textMuted, fontSize: 11))])),
                  ]),
                ),
                const Divider(color: AppColors.cardBorder, height: 1),
                Padding(padding: const EdgeInsets.all(16), child: Text(t['desc'] as String, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13, height: 1.5))),
              ],
            ),
          )),
          Container(
            padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xFF1E1B4B), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.blueAccent)),
            child: Column(children: [const Icon(Icons.info, color: Colors.blueAccent, size: 28), const SizedBox(height: 8), const Text('📋 Important Notice', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), const SizedBox(height: 8), const Text('By participating in any match or contest on our platform, you agree to abide by these terms and conditions. Violation of any of these rules may result in account suspension or permanent ban.', textAlign: TextAlign.center, style: TextStyle(color: AppColors.textSecondary, fontSize: 12, height: 1.5))]),
          ),
          const SizedBox(height: 30),
          const Center(child: Text('Last updated: 11/11/2026', style: TextStyle(color: AppColors.textMuted, fontSize: 11))),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

class PrivacyScreen extends StatelessWidget {
  const PrivacyScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final policies = <Map<String, dynamic>>[
      {'title': 'Match Cancellation Policy', 'desc': 'Battle Arena reserves the right to cancel any match at any time without any reason.', 'isRed': false},
      {'title': 'Age Requirement', 'desc': 'By participating in Battle Arena Matches, you accept and agree that you are above 18 years in age.', 'isRed': false},
      {'title': 'Suspicious Activity', 'desc': 'In case the investigators or spectators find any suspicious player in the gameplay, Battle Arena reserves the right to disqualify, suspend or put the doer\'s account on hold and also cancel their Prize prizes or amount.', 'isRed': false},
      {'title': 'Multiple Account Policy', 'desc': 'IF WE FOUND USING MULTIPLE ID THEN YOU WILL BE BANNED FROM OUR APP', 'isRed': true},
      {'title': 'Technical Issues', 'desc': 'In case of any technical glitch, the match may get cancelled and in such cases the entry fees will be refunded to the participants or re-match may take place.\n\nIn case any player fails to submit correct details while participating in any match then the reward/prize amount will be cancelled for that player and no refund will be processed.', 'isRed': false},
      {'title': 'Prohibited Activities', 'desc': 'Players are not allowed to use any Mod or Hack in the Gameplay. If anyone is found suspicious, immediate action will be taken, the account will be suspended, all the pending withdrawals will be cancelled and wallet balance will become useless.\n\nMis-using any in-game glitches or errors will result in disqualification of that player from the match and no reward for the same match will be considered.', 'isRed': false},
      {'title': 'Emulator Usage', 'desc': 'Do not use any Emulator to Play in non-emulator matches. Such players will be kicked and if remains un-kicked then they may not get the match rewards/prizes.', 'isRed': false},
      {'title': 'Match Participation Guidelines', 'desc': '• Participants need to make sure to grab Match Details such as Room ID and Password before the match start time. The Room Id and Password are shared in the app and also through SMS. Grab them and join the room quickly. In case the participants fail to join the room before the match start time, they won\'t be able to join the match later on and no refund will be processed for the same.\n\n• In case participants fail to join the room due to any external issues from participants end (incl. Slow internet, multi-tasking, minimizing game, Receiving Calls or SMS, etc.) then no refund will be processed.\n\n• If the participants are kicked or auto-kicked from the room without any reasons then the refund will be issued upon submitting proper valid evidences such as a Screenshot of the Error Screen or Message.\n\n• Any of the policies mentioned here can change, get updates or removed at any time, so keep checking here for the latest policies and rules.', 'isRed': false},
      {'title': 'Fair Play Policy', 'desc': 'Before participating in any match at Battle Arena, you agree to the Fair Play Policy and accept it.', 'isRed': false},
    ];
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Privacy Policy', style: TextStyle(fontWeight: FontWeight.w900)), backgroundColor: AppColors.surface),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: policies.map((p) {
          final bool isRed = p['isRed'] as bool? ?? false;
          return Container(
            margin: const EdgeInsets.only(bottom: 16), padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.cardBorder)),
            child: Column(children: [Text(p['title'] as String, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)), const SizedBox(height: 8), Container(width: 40, height: 3, color: AppColors.red), const SizedBox(height: 12), Text(p['desc'] as String, textAlign: TextAlign.center, style: TextStyle(color: isRed ? AppColors.red : AppColors.textSecondary, fontSize: 13, height: 1.5, fontWeight: isRed ? FontWeight.bold : FontWeight.normal))]),
          );
        }).toList(),
      ),
    );
  }
}

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('About Us', style: TextStyle(fontWeight: FontWeight.w900)), backgroundColor: AppColors.surface),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(padding: const EdgeInsets.all(24), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFFE53935), Color(0xFFF4511E)]), borderRadius: BorderRadius.circular(12)), child: Column(children: [Text('Welcome to Battle Arena', style: GoogleFonts.orbitron(fontSize: 20, fontWeight: FontWeight.w900, color: Colors.white)), const SizedBox(height: 8), const Text('Your Premier Free Fire Esports Platform', style: TextStyle(color: Colors.white, fontSize: 13))])),
          const SizedBox(height: 16),
          _buildAboutCard(Icons.bolt, Colors.red, 'Premier Esports Platform', 'Battle Arena is a premier esports platform dedicated to Free Fire tournaments, bringing competitive gaming and exciting rewards to players across the community.'),
          _buildAboutCard(Icons.groups, Colors.orange, 'For All Skill Levels', 'Join Battle Arena to compete in professionally organized Free Fire tournaments and earn real rewards based on your in-game performance. Whether you\'re a casual player or a competitive gamer, our platform offers tournaments for all skill levels.'),
          _buildAboutCard(Icons.monetization_on, Colors.amber, 'Daily Tournaments & Rewards', 'Transform your passion for Free Fire into rewards and recognition. Battle Arena hosts daily tournaments where you can compete against other skilled players, showcase your abilities, and climb the leaderboards to win amazing prizes.'),
          _buildAboutCard(Icons.verified, Colors.green, 'Fair & Secure', 'Participate in custom room tournaments, earn rewards for each kill, and compete for victory royales. With secure registration, fair gameplay monitoring, and instant prize distribution, Battle Arena provides the ultimate Free Fire esports experience.'),
          const SizedBox(height: 16),
          Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFFE53935), Color(0xFFF4511E)]), borderRadius: BorderRadius.circular(12)), child: const Text('Ready to compete? Join tournaments and start Prize today! 🏆', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15))),
        ],
      ),
    );
  }
  Widget _buildAboutCard(IconData icon, Color color, String title, String desc) { return Container(margin: const EdgeInsets.only(bottom: 16), padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.cardBorder)), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: color.withOpacity(0.2), borderRadius: BorderRadius.circular(8)), child: Icon(icon, color: color, size: 24)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)), const SizedBox(height: 6), Text(desc, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12, height: 1.5))]))])); }
}

class FaqScreen extends StatelessWidget {
  const FaqScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final faqs = [
      {'icon': Icons.emoji_events, 'color': Colors.amber, 'title': 'Why didn\'t I receive my prizes?', 'tag': 'Prizes', 'tagColor': Colors.green, 'ans': 'If you didn\'t receive your prize, it might be due to pending verification. Please ensure you submitted valid POV/screen recording. Contact support if the issue persists.'},
      {'icon': Icons.gamepad, 'color': Colors.blue, 'title': 'When Should I Start Recording?', 'tag': 'Gameplay', 'tagColor': Colors.blue, 'ans': 'You must start recording from the lobby/spawn island until the match ends (Booyah or elimination).'},
      {'icon': Icons.shuffle, 'color': Colors.purple, 'title': 'Can I know the custom room settings of matches?', 'tag': 'Matches', 'tagColor': Colors.purple, 'ans': 'Custom room settings vary by match mode. You can check the "Match Rules" section on the match details page.'},
      {'icon': Icons.monetization_on, 'color': Colors.amber, 'title': 'How can I earn and use bonus coins?', 'tag': 'Coins', 'tagColor': Colors.amber, 'ans': 'You can earn bonus coins through referrals, special events, and daily rewards. They can be used to join matches or withdraw as per rules.'},
      {'icon': Icons.shuffle, 'color': Colors.purple, 'title': 'Can I know when matches are added?', 'tag': 'Matches', 'tagColor': Colors.purple, 'ans': 'Matches are usually added 24 hours in advance. Keep an eye on the Upcoming tab or turn on notifications.'},
      {'icon': Icons.sos, 'color': Colors.red, 'title': 'What should I do if my prizes are not credited to my account within the given time?', 'tag': 'Support', 'tagColor': Colors.red, 'ans': 'Please raise a support ticket from the app menu. Our team will resolve it within 24 hours.'},
      {'icon': Icons.monetization_on, 'color': Colors.amber, 'title': 'When will I receive my purchased coins?', 'tag': 'Coins', 'tagColor': Colors.amber, 'ans': 'Coins are credited within 10-15 minutes after admin verifies your UTR and payment screenshot.'},
      {'icon': Icons.shuffle, 'color': Colors.purple, 'title': 'How do I join a match?', 'tag': 'Matches', 'tagColor': Colors.purple, 'ans': 'Go to Home, select a match, click Join, select an empty slot, enter your IGN & UID, and pay the entry fee.'},
      {'icon': Icons.monetization_on, 'color': Colors.amber, 'title': 'How do I withdraw my earnings?', 'tag': 'Coins', 'tagColor': Colors.amber, 'ans': 'Go to Wallet -> Withdraw Coins. Enter your UPI ID and amount (Min 11, Max 1000). It will be processed within 2-4 hours.'},
    ];

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Frequently Asked Questions', style: TextStyle(fontWeight: FontWeight.w900)), backgroundColor: AppColors.surface),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(children: [
              _buildFilterChip('All', true), const SizedBox(width: 8),
              _buildFilterChip('🏆 Prizes', false), const SizedBox(width: 8),
              _buildFilterChip('🎮 Gameplay', false), const SizedBox(width: 8),
              _buildFilterChip('💰 Coins', false), const SizedBox(width: 8),
              _buildFilterChip('⚔️ Matches', false), const SizedBox(width: 8),
              _buildFilterChip('🆘 Support', false),
            ]),
          ),
          const SizedBox(height: 20),
          ...faqs.map((f) => Container(
            margin: const EdgeInsets.only(bottom: 12), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.cardBorder)),
            child: Theme(data: ThemeData().copyWith(dividerColor: Colors.transparent), child: ExpansionTile(
              leading: Icon(f['icon'] as IconData, color: f['color'] as Color, size: 28),
              title: Text(f['title'] as String, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
              subtitle: Container(margin: const EdgeInsets.only(top: 6), padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2), decoration: BoxDecoration(color: (f['tagColor'] as Color).withOpacity(0.2), borderRadius: BorderRadius.circular(12)), child: Text(f['tag'] as String, style: TextStyle(color: f['tagColor'] as Color, fontSize: 10, fontWeight: FontWeight.bold))),
              children: [Padding(padding: const EdgeInsets.all(16), child: Text(f['ans'] as String, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13, height: 1.5)))],
            )),
          )),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(20), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF6366F1), Color(0xFF8B5CF6)]), borderRadius: BorderRadius.circular(16)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Still need help?', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18)),
              const SizedBox(height: 8),
              const Text('If you couldn\'t find the answer you\'re looking for, our support team is here to help!', style: TextStyle(color: Colors.white70, fontSize: 13)),
              const SizedBox(height: 16),
              ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: Colors.black, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))), onPressed: () => openExternalUrl(context, AppConfig.telegramUrl), child: const Text('Contact Support', style: TextStyle(fontWeight: FontWeight.bold))),
            ]),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildFilterChip(String label, bool isSelected) {
    return Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8), decoration: BoxDecoration(color: isSelected ? AppColors.cyan : AppColors.surfaceLight, borderRadius: BorderRadius.circular(20)), child: Text(label, style: TextStyle(color: isSelected ? Colors.black : AppColors.textPrimary, fontWeight: FontWeight.bold, fontSize: 12)));
  }
}

class ContactScreen extends StatelessWidget {
  const ContactScreen({super.key});

  Widget _buildSocialCard({required BuildContext context, required String title, required String subtitle, required String link, required Color color, required IconData icon, required String actionLabel}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: color.withOpacity(0.5)), boxShadow: [BoxShadow(color: color.withOpacity(0.12), blurRadius: 12, spreadRadius: 1)]),
      child: Material(color: Colors.transparent, child: InkWell(
        borderRadius: BorderRadius.circular(14), onTap: () => openExternalUrl(context, link),
        child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [
          Container(width: 48, height: 48, decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(12), border: Border.all(color: color)), child: Center(child: Icon(icon, color: color, size: 26))),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14, color: AppColors.textPrimary)), const SizedBox(height: 3), Text(subtitle, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)), const SizedBox(height: 4), Text(link, style: TextStyle(fontSize: 10, color: color, fontWeight: FontWeight.bold), maxLines: 1, overflow: TextOverflow.ellipsis)])),
          const SizedBox(width: 8),
          Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(8)), child: Text(actionLabel, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 11))),
        ])),
      )),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('OFFICIAL COMMUNITY & SUPPORT', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)), backgroundColor: AppColors.surface),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1E293B), Color(0xFF0F172A)]), borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.cyan.withOpacity(0.6))), child: Row(children: [buildAppLogo(size: 56, radius: 14), const SizedBox(width: 14), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('BATTLE ARENA OFFICIAL', style: TextStyle(fontFamily: 'Orbitron', fontSize: 15, fontWeight: FontWeight.w900, color: AppColors.cyan)), SizedBox(height: 4), Text('Connect on all official platforms for room schedules, stream highlights & 24/7 helpdesk.', style: TextStyle(fontSize: 11, color: AppColors.textSecondary, height: 1.3))]))])),
            const SizedBox(height: 18),
            Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.cardBorder)), child: Row(children: [const Icon(Icons.email, color: AppColors.cyan, size: 24), const SizedBox(width: 12), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Official Support Email:', style: TextStyle(fontSize: 11, color: AppColors.textSecondary, fontWeight: FontWeight.bold)), SizedBox(height: 2), Text(AppConfig.supportEmail, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w900, color: AppColors.cyan))])), IconButton(icon: const Icon(Icons.copy, color: AppColors.cyan, size: 20), onPressed: () { Clipboard.setData(const ClipboardData(text: AppConfig.supportEmail)); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Support email copied!'))); })])),
            const SizedBox(height: 20),
            Row(children: [Container(width: 4, height: 16, color: AppColors.gold), const SizedBox(width: 8), const Text('OFFICIAL SOCIAL MEDIA HUBS', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 1))]),
            const SizedBox(height: 12),
            _buildSocialCard(context: context, title: 'YouTube Channel', subtitle: 'Daily Tournament Livestreams & Top Highlights', link: AppConfig.youtubeUrl, color: const Color(0xFFFF0000), icon: Icons.play_circle_fill, actionLabel: 'SUBSCRIBE'),
            _buildSocialCard(context: context, title: 'Telegram Channel', subtitle: 'Room IDs, Match Alerts & Instant Notices', link: AppConfig.telegramUrl, color: const Color(0xFF0088CC), icon: Icons.send_rounded, actionLabel: 'JOIN NOW'),
            _buildSocialCard(context: context, title: 'Instagram Handle', subtitle: 'Winner Showcases, Clips & Esports Community', link: AppConfig.instagramUrl, color: const Color(0xFFE1306C), icon: Icons.camera_alt, actionLabel: 'FOLLOW'),
            _buildSocialCard(context: context, title: 'Discord Server', subtitle: 'Voice Scrim Rooms, Clan LFG & Support Tickets', link: AppConfig.discordUrl, color: const Color(0xFF5865F2), icon: Icons.forum, actionLabel: 'CONNECT'),
            _buildSocialCard(context: context, title: 'WhatsApp Official Channel', subtitle: 'Latest Announcements & Community Hub', link: AppConfig.whatsappChannelUrl, color: const Color(0xFF25D366), icon: Icons.chat, actionLabel: 'JOIN CHANNEL'),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}